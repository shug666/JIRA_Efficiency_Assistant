/**
 * version-gate.js — 版本门控（Content Script，第 2 个注入）
 *
 * 职责：
 *   1. 缓存后台 checkUpdate()/ffCheckUpdate() 写入的 jsaVersionState 到 window.__jsaVersion
 *   2. 监听 chrome.storage.onChanged 实时刷新缓存（保持长会话新鲜度）
 *   3. 暴露同步检查接口 check()/isOutdated() 供其他脚本调用
 *   4. 暴露 jsaRequireLatestVersion({silent?, grey?}) 门控函数 + showUpdateRequiredDialog()
 *   5. 受控功能触发时 fire-and-forget 主动刷新（60s 节流）
 *
 * 注入顺序：feishu-auth.js → version-gate.js → jsa-assistant.js → contentScript.js
 * 镜像 feishu-auth.js 的"缓存 + storage.onChanged 订阅 + 同步检查"模式。
 *
 * fail-open 原则：status='unknown'（含网络不可达、获取不到版本、存储无数据）时一律放行，
 * 绝不锁死用户。仅 status='outdated' 时拦截并弹窗。
 */
(function () {
  'use strict';

  // ---- 版本状态缓存 ----
  // { status:'outdated'|'up-to-date'|'unknown', latestVersion, currentVersion,
  //   checkedAt, lastReachableAt, updateInstructionsUrl }
  var versionState = undefined;

  // ---- 默认中转页 URL（jsaVersionState.updateInstructionsUrl 缺失时降级） ----
  var DEFAULT_UPDATE_URL = 'http://10.24.137.80/jsa-dist/update-instructions.html';

  // ---- 主动刷新节流时间戳 ----
  var _lastRefreshTs = 0;
  var REFRESH_THROTTLE_MS = 60 * 1000; // 60 秒

  // ---- 弹窗节流时间戳 ----
  var _lastDialogTs = 0;
  var DIALOG_THROTTLE_MS = 3 * 1000; // 3 秒

  // ---- 读取版本状态 ----
  function getVersionState() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get('jsaVersionState', function (r) {
          resolve(r && r.jsaVersionState);
        });
      } catch (e) {
        resolve(undefined);
      }
    });
}

  // ---- 暴露全局版本接口 ----
  window.__jsaVersion = {
    /**
     * 同步检查当前版本状态字符串
     * @returns {'outdated'|'up-to-date'|'unknown'}
     */
    check: function () {
      if (!versionState || !versionState.status) return 'unknown';
      return versionState.status;
    },

    /**
     * 同步检查当前版本是否落后（仅 outdated 为 true）
     * @returns {boolean}
     */
    isOutdated: function () {
      return !!(versionState && versionState.status === 'outdated');
    },

    /**
     * 异步刷新版本状态缓存
     * @returns {Promise<string>} status
     */
    refresh: function () {
      return getVersionState().then(function (s) {
        versionState = s || undefined;
        return window.__jsaVersion.check();
      });
    }
  };

  // ---- 初始化：读取一次版本状态 ----
  window.__jsaVersion.refresh().then(function () {
    // 缺失或 checkedAt 超过 30 分钟 → fire-and-forget 触发一次主动刷新填充缓存
    var now = Date.now();
    var stale = !versionState
      || !versionState.checkedAt
      || (now - versionState.checkedAt > 30 * 60 * 1000);
    if (stale) {
      try {
        chrome.runtime.sendMessage({ type: 'CHECK_UPDATE_MANUAL' });
        _lastRefreshTs = now;
      } catch (e) { /* ignore */ }
    }
  });

  // ---- 监听 storage 变化，实时刷新版本状态 ----
  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== 'local') return;
    if (changes.jsaVersionState) {
      versionState = changes.jsaVersionState.newValue || undefined;
    }
  });

  // ---- fire-and-forget 主动刷新（60s 节流） ----
  function maybeRefresh() {
    var now = Date.now();
    if (now - _lastRefreshTs > REFRESH_THROTTLE_MS) {
      _lastRefreshTs = now;
      try {
        chrome.runtime.sendMessage({ type: 'CHECK_UPDATE_MANUAL' });
      } catch (e) { /* ignore */ }
    }
  }

  // ---- 版本门控检查 ----
  /**
   * 版本门控检查
   * @param {object} [opts] - { silent: true } 时不弹窗（被动绑定场景）
   * @returns {boolean} true=版本满足可继续，false=版本落后已处理
   */
  function jsaRequireLatestVersion(opts) {
    opts = opts || {};
    var silent = opts.silent;
    var outdated = false;
    try {
      outdated = window.__jsaVersion.isOutdated();
    } catch (e) {
      // window.__jsaVersion 未定义 → fail-open 放行
      console.warn('[JSA] 版本门控: __jsaVersion 未定义，fail-open 放行');
      return true;
    }
    // 受控触发即主动刷新（fire-and-forget，60s 节流），当前判定不等待
    maybeRefresh();
    if (!outdated) {
      return true; // 最新或未知 → 放行
    }
    // outdated → 拦截
    if (!silent) {
      var now = Date.now();
      if (now - _lastDialogTs > DIALOG_THROTTLE_MS) {
        _lastDialogTs = now;
        showUpdateRequiredDialog();
      }
    }
    return false;
  }

  // ---- 统一更新引导弹窗 ----
  function showUpdateRequiredDialog() {
    // 防重入：已存在弹窗则不重复创建（避免 observer 高频回调导致 DOM 无限膨胀）
    if (document.querySelector('.jsa-ver-overlay')) return;
    var styleTag = document.createElement('style');
    styleTag.id = 'jsa-version-guide-styles';
    if (!document.getElementById('jsa-version-guide-styles')) {
      styleTag.textContent = `
			@keyframes jsaVerFadeIn { from { opacity: 0; } to { opacity: 1; } }
			@keyframes jsaVerSlideUp { from { opacity: 0; transform: translate(-50%, -48%); } to { opacity: 1; transform: translate(-50%, -50%); } }
			.jsa-ver-overlay { position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;animation:jsaVerFadeIn .2s ease }
			.jsa-ver-dialog { position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.25),0 0 0 1px rgba(0,0,0,.06);z-index:10000;width:420px;max-width:90vw;overflow:hidden;animation:jsaVerSlideUp .3s ease;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif }
			.jsa-ver-header { display:flex;align-items:center;gap:12px;padding:20px 24px 0 }
			.jsa-ver-icon { width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#FEF3C7,#FDE68A);display:flex;align-items:center;justify-content:center;flex-shrink:0 }
			.jsa-ver-icon svg { width:22px;height:22px;color:#D97706 }
			.jsa-ver-title { font-size:17px;font-weight:600;color:#1F2937;line-height:1.3 }
			.jsa-ver-body { padding:16px 24px 0 }
			.jsa-ver-desc { font-size:14px;color:#6B7280;line-height:1.6;margin:0 0 14px }
			.jsa-ver-footer { padding:20px 24px;display:flex;justify-content:flex-end;gap:10px;margin-top:8px }
			.jsa-ver-btn { padding:9px 22px;border-radius:8px;font-size:14px;font-weight:500;cursor:pointer;transition:all .15s ease;border:none;outline:none }
			.jsa-ver-btn:active { transform:scale(.97) }
			.jsa-ver-btn-secondary { background:#F3F4F6;color:#374151 }
			.jsa-ver-btn-secondary:hover { background:#E5E7EB }
			.jsa-ver-btn-primary { background:linear-gradient(135deg,#3B82F6,#2563EB);color:#fff;box-shadow:0 1px 3px rgba(37,99,235,.3) }
			.jsa-ver-btn-primary:hover { background:linear-gradient(135deg,#2563EB,#1D4ED8);box-shadow:0 2px 6px rgba(37,99,235,.4) }
		`;
      document.head.appendChild(styleTag);
    }

    var overlay = document.createElement('div');
    overlay.className = 'jsa-ver-overlay';
    document.body.appendChild(overlay);

    var dialog = document.createElement('div');
    dialog.className = 'jsa-ver-dialog';
    dialog.innerHTML = `
		<div class="jsa-ver-header">
			<div class="jsa-ver-icon">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
					<line x1="12" y1="9" x2="12" y2="13"></line>
					<line x1="12" y1="17" x2="12.01" y2="17"></line>
				</svg>
			</div>
			<div class="jsa-ver-title">需要更新后使用</div>
		</div>
		<div class="jsa-ver-body">
			<p class="jsa-ver-desc">当前插件版本落后于最新版本，此功能暂不可用。请更新到最新版本后继续使用。</p>
		</div>
		<div class="jsa-ver-footer">
			<button class="jsa-ver-btn jsa-ver-btn-secondary" id="jsa_ver_cancel">稍后</button>
			<button class="jsa-ver-btn jsa-ver-btn-primary" id="jsa_ver_update">去更新</button>
		</div>
	`;
    document.body.appendChild(dialog);

    var closeDialog = function () {
      overlay.style.opacity = '0';
      dialog.style.opacity = '0';
      dialog.style.transform = 'translate(-50%, -48%)';
      setTimeout(function () {
        overlay.remove();
        dialog.remove();
      }, 200);
    };

    dialog.querySelector('#jsa_ver_cancel').addEventListener('click', closeDialog);
    dialog.querySelector('#jsa_ver_update').addEventListener('click', function () {
      closeDialog();
      var url = (versionState && versionState.updateInstructionsUrl) || DEFAULT_UPDATE_URL;
      try {
        window.open(url, '_blank');
      } catch (e) { /* ignore */ }
    });
    overlay.addEventListener('click', closeDialog);
  }

  // ---- 暴露到全局供 contentScript.js 调用 ----
  window.jsaRequireLatestVersion = jsaRequireLatestVersion;
  window.showUpdateRequiredDialog = showUpdateRequiredDialog;

  console.log('[JSA] version-gate.js 版本门控已加载, status=' + window.__jsaVersion.check());
})();
