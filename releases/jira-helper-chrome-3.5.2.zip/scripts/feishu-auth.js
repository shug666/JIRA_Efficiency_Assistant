/**
 * feishu-auth.js — 飞书认证门控（Content Script，最先注入）
 *
 * 职责：
 *   1. 劫持 chrome.runtime.sendMessage，拦截 CHECK_LICENSE action
 *   2. 优先校验飞书登录态（含黑名单 jsa_blacklist 检查）
 *   3. 飞书未登录时透传给原 sendMessage（回退到激活码校验）
 *   4. 暴露 window.__jsaAuth 供其他脚本调用
 *
 * 注入顺序：feishu-auth.js → jsa-assistant.js → contentScript.js
 * 详见 openspec/changes/merge-jira-smart-assistant/design.md §3
 */
(function () {
  'use strict';

  // ---- 认证状态缓存 ----
  var authState = { checked: false, authenticated: false, user: null };

  // ---- 读取飞书用户和黑名单 ----
  function getAuthData() {
    return new Promise(function (resolve) {
      chrome.storage.local.get(['jsa_feishu_user', 'jsa_blacklist'], function (r) {
        var u = r && r.jsa_feishu_user;
        var bl = (r && r.jsa_blacklist) || [];
        var isBlocked = u && bl.some(function (b) { return b.openId === u.openId; });
        resolve({ user: u, isBlocked: isBlocked });
      });
    });
  }

  // ---- 暴露全局认证接口 ----
  window.__jsaAuth = {
    /**
     * 同步检查当前是否已认证（基于缓存）
     * @returns {boolean}
     */
    check: function () {
      return authState.authenticated;
    },

    /**
     * 获取当前认证用户
     * @returns {object|null}
     */
    getUser: function () {
      return authState.user;
    },

    /**
     * 异步刷新认证状态
     * @returns {Promise<boolean>}
     */
    refresh: function () {
      return getAuthData().then(function (data) {
        var authenticated = !!(data.user && data.user.openId && !data.isBlocked);
        authState = { checked: true, authenticated: authenticated, user: authenticated ? data.user : null };
        return authenticated;
      });
    }
  };

  // ---- 初始化：读取一次认证状态 ----
  window.__jsaAuth.refresh();

  // ---- 劫持 chrome.runtime.sendMessage ----
  var _origSend = chrome.runtime.sendMessage.bind(chrome.runtime);
  chrome.runtime.sendMessage = function (msg, callback) {
    // 仅拦截 CHECK_LICENSE action
    if (msg && msg.action === 'CHECK_LICENSE') {
      getAuthData().then(function (data) {
        var u = data.user;
        var isBlocked = data.isBlocked;
        if (u && u.openId && !isBlocked) {
          // 飞书已登录且未封禁 → 直接放行
          authState = { checked: true, authenticated: true, user: u };
          if (typeof callback === 'function') {
            callback({
              success: true,
              data: { activated: true, user: u.name + ' (飞书)', expireDate: '飞书账号', expired: false }
            });
          }
        } else if (isBlocked) {
          // 被封禁 → 拒绝
          authState = { checked: true, authenticated: false, user: null };
          if (typeof callback === 'function') {
            callback({ success: false, data: { activated: false } });
          }
        } else {
          // 飞书未登录 → 透传给原 sendMessage（回退到激活码校验）
          _origSend(msg, function (resp) {
            // 根据激活码校验结果更新缓存
            if (resp && resp.success && resp.data && resp.data.activated) {
              authState = { checked: true, authenticated: true, user: { name: resp.data.user, authType: 'license' } };
            }
            if (typeof callback === 'function') callback(resp);
          });
        }
      });
      return;
    }
    // 其他 action 正常透传
    return _origSend(msg, callback);
  };

  // ---- 监听 storage 变化，实时更新认证状态 ----
  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== 'local') return;
    if (changes.jsa_feishu_user || changes.jsa_blacklist) {
      window.__jsaAuth.refresh();
    }
  });

  console.log('[JSA] feishu-auth.js 认证门控已加载');
})();
