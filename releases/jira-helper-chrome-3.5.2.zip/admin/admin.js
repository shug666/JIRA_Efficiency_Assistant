// ==========================================
// admin.js — 后台管理页面逻辑（外部脚本，MV3 兼容）
// ==========================================
(function () {
  'use strict';

  var ADMIN_PWD_HASH = 'jsa_admin_2026';

  var FEISHU_APP_ID = 'cli_a960ac9af7f81bb4';
  var FEISHU_APP_SECRET = 'aLOd0O4bnxUhKS3OvYLUBghzvuPWWJs0';
  var BITABLE_APP_TOKEN = 'OP58b7qwyaSCTOs66NzcyXTqnCf';
  var BITABLE_USERS_TBL = 'tblB1LAb9edbQ5hC';
  var BITABLE_EVENTS_TBL = 'tbltH9uBiKypQeJZ';

  // var FEISHU_APP_ID = 'cli_a95705aff738dbc9';
  // var FEISHU_APP_SECRET = '04FJIJNSz8ojRPtv358sbgf8ZJxMjaV1';
  // var BITABLE_APP_TOKEN = 'OP58b7qwyaSCTOs66NzcyXTqnCf';
  // var BITABLE_USERS_TBL = 'tblB1LAb9edbQ5hC';
  // var BITABLE_EVENTS_TBL = 'tbltH9uBiKypQeJZ';
  var BITABLE_BASE = 'https://open.feishu.cn/open-apis/bitable/v1/apps/' + BITABLE_APP_TOKEN;

  // 多维表格 API 必须使用 tenant_access_token（与 background-service-worker.js 保持一致）
  // 优先用 tenant_access_token/internal；失败则降级到 legacy app_access_token/internal
  async function getAdminAppToken() {
    var urls = [
      'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
      'https://open.feishu.cn/open-apis/auth/v3/app_access_token/internal'
    ];
    var lastErr;
    for (var i = 0; i < urls.length; i++) {
      try {
        var resp = await fetch(urls[i], {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ app_id: FEISHU_APP_ID, app_secret: FEISHU_APP_SECRET })
        });
        var data = await resp.json();
        var token = data.tenant_access_token || data.app_access_token;
        if (token) {
          console.log('[Admin] 获取飞书 token 成功 (url=' + urls[i] + ')');
          return token;
        }
        lastErr = new Error('获取 token 失败: ' + (data.msg || 'unknown') + ' (code=' + data.code + ')');
        console.error('[Admin]', lastErr.message, 'url=', urls[i]);
      } catch (e) {
        lastErr = e;
        console.error('[Admin] token 请求异常:', e, 'url=', urls[i]);
      }
    }
    throw lastErr || new Error('获取 token 失败: unknown');
  }

  async function fetchAllBitableRecords(appToken, tableId) {
    var headers = { 'Authorization': 'Bearer ' + appToken };
    var records = [];
    var pageToken = '';
    do {
      var url = BITABLE_BASE + '/tables/' + tableId + '/records?page_size=500&text_field_as_array=false' + (pageToken ? '&page_token=' + encodeURIComponent(pageToken) : '');
      var resp = await fetch(url, { headers: headers });
      var data = await resp.json();
      // 显式检查业务错误码，避免静默返回空数组
      if (data.code !== 0) {
        var msg = '飞书 API 错误 [table=' + tableId + ']: code=' + data.code + ' msg=' + (data.msg || '');
        console.error('[Admin]', msg);
        throw new Error(msg);
      }
      if (data.data && data.data.items) {
        records = records.concat(data.data.items);
        pageToken = data.data.has_more ? data.data.page_token : '';
      } else {
        // 空表或无更多数据
        pageToken = '';
      }
    } while (pageToken);
    console.log('[Admin] 读取飞书表格成功 [table=' + tableId + '] 记录数=' + records.length);
    return records;
  }

  // Bitable 文本字段返回富文本数组，需解析
  function getRichText(field) {
    if (Array.isArray(field)) {
      return field.map(function (item) { return item.text || ''; }).join('');
    }
    if (typeof field === 'string') return field;
    return field != null ? String(field) : '';
  }

  var allUsers = [];
  var allEvents = [];
  var allDaily = {};
  var allBlacklist = [];

  function checkAdminPwd() {
    var pwd = document.getElementById('admin-pwd').value;
    if (pwd === ADMIN_PWD_HASH) {
      document.getElementById('auth-guard').style.display = 'none';
      document.getElementById('app').style.display = 'block';
      loadData();
    } else {
      var el = document.getElementById('pwd-error');
      el.textContent = '密码错误，请重试';
      el.style.display = 'block';
    }
  }

  function switchTab(name) {
    document.querySelectorAll('.tab-btn').forEach(function (b, i) {
      b.classList.toggle('active', ['users', 'events', 'daily', 'blacklist'][i] === name);
    });
    document.querySelectorAll('.tab-panel').forEach(function (p) {
      p.classList.toggle('active', p.id === 'tab-' + name);
    });
  }

  function loadData() {
    if (!chrome || !chrome.storage) {
      alert('请在 Chrome 扩展环境中打开此页面');
      return;
    }
    // 黑名单保持本地
    chrome.storage.local.get(['jsa_blacklist'], function (r) {
      allBlacklist = r.jsa_blacklist || [];
      renderBlacklist();
    });
    var refreshEl = document.getElementById('last-refresh');
    if (refreshEl) refreshEl.textContent = '飞书数据加载中...';
    (async function () {
      try {
        var appToken = await getAdminAppToken();
        var userRecords = await fetchAllBitableRecords(appToken, BITABLE_USERS_TBL);
        var eventRecords = await fetchAllBitableRecords(appToken, BITABLE_EVENTS_TBL);
        allUsers = userRecords.map(function (item) {
          var f = item.fields;
          return {
            name: getRichText(f['文本']),
            openId: getRichText(f.openId),
            email: getRichText(f.email),
            authType: getRichText(f.authType) || 'feishu',
            firstSeen: f.firstSeen ? new Date(getRichText(f.firstSeen)).getTime() : 0,
            lastSeen: f.lastSeen ? new Date(getRichText(f.lastSeen)).getTime() : 0,
            _recordId: item.record_id
          };
        }).filter(function (u) { return u.name || u.openId; }); // 过滤空白行
        allEvents = eventRecords.map(function (item) {
          var f = item.fields;
          return {
            ts: typeof f.ts === 'number' ? f.ts : 0,
            date: getRichText(f.date),
            user: getRichText(f.user),
            type: getRichText(f.type),
            detail: getRichText(f.detail),
            openId: getRichText(f.openId)
          };
        }).sort(function (a, b) { return a.ts - b.ts; });
        // 重建 allDaily 从 events
        allDaily = {};
        allEvents.forEach(function (e) {
          if (!e.date) return;
          if (!allDaily[e.date]) allDaily[e.date] = { dau: 0, dauSet: [], submit: 0, dup: 0, grading: 0, submitForce: 0 };
          var d = allDaily[e.date];
          if (!d.dauSet.includes(e.user)) { d.dauSet.push(e.user); d.dau = d.dauSet.length; }
          if (e.type === 'submit_check') d.submit++;
          if (e.type === 'dup_check') d.dup++;
          if (e.type === 'grading_check') d.grading++;
          if (e.type === 'submit_force') d.submitForce++;
        });
        renderStats();
        renderUsers();
        renderEvents();
        renderDaily();
        renderBlacklist();
        document.getElementById('last-refresh').textContent = '最后刷新: ' + new Date().toLocaleTimeString() + ' ☁️飞书云端';
      } catch (err) {
        console.error('[Admin] 飞书数据加载失败:', err);
        // 降级：读本地缓存（本地仅含当前用户自己的数据，无法看到其他用户）
        chrome.storage.local.get(['jsa_usage_users', 'jsa_usage_events', 'jsa_usage_daily', 'jsa_blacklist'], function (result) {
          allUsers = result.jsa_usage_users || [];
          allEvents = result.jsa_usage_events || [];
          allDaily = result.jsa_usage_daily || {};
          allBlacklist = result.jsa_blacklist || [];
          renderStats(); renderUsers(); renderEvents(); renderDaily(); renderBlacklist();
          document.getElementById('last-refresh').textContent =
            '⚠️ 飞书云端读取失败，已降级显示本地数据（仅含当前用户）: ' + new Date().toLocaleTimeString();
          alert('⚠️ 飞书云端数据读取失败！\n\n错误: ' + err.message +
            '\n\n已降级显示本地缓存（仅含当前用户自己的数据，其他用户数据不可见）。\n\n请检查：' +
            '\n1. 飞书 App ID / App Secret 是否正确' +
            '\n2. 多维表格 App Token / Table ID 是否正确' +
            '\n3. 飞书应用是否已授权访问该多维表格');
        });
      }
    })();
  }

  function renderStats() {
    var today = new Date().toISOString().slice(0, 10);
    var todayUsers = new Set();
    allEvents.forEach(function (e) {
      if (e.date === today) todayUsers.add(e.user);
    });

    document.getElementById('stat-users').textContent = allUsers.length;
    document.getElementById('stat-dau').textContent = todayUsers.size;
    document.getElementById('stat-checks').textContent = allEvents.filter(function (e) { return e.type === 'submit_check'; }).length;
    document.getElementById('stat-dup').textContent = allEvents.filter(function (e) { return e.type === 'dup_check'; }).length;
    document.getElementById('stat-grading').textContent = allEvents.filter(function (e) { return e.type === 'grading_check'; }).length;

    // WAU: 迗30天内有记录的所有用户（当前第几天至上周同天）
    var sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    var wauUsers = new Set();
    allEvents.forEach(function (e) {
      if (e.date >= sevenDaysAgo) wauUsers.add(e.user);
    });
    document.getElementById('stat-wau').textContent = wauUsers.size;
    document.getElementById('stat-force').textContent = allEvents.filter(function (e) { return e.type === 'submit_force'; }).length;
  }

  function renderUsers() {
    var keyword = (document.getElementById('search-user').value || '').toLowerCase();
    var authFilter = document.getElementById('filter-auth').value;
    var filtered = allUsers.filter(function (u) {
      if (keyword && !(u.name || '').toLowerCase().includes(keyword)) return false;
      if (authFilter && u.authType !== authFilter) return false;
      return true;
    });

    var userStats = {};
    allUsers.forEach(function (u) { userStats[u.name] = { submit: 0, dup: 0, grading: 0 }; });
    allEvents.forEach(function (e) {
      if (!userStats[e.user]) userStats[e.user] = { submit: 0, dup: 0, grading: 0 };
      if (e.type === 'submit_check') userStats[e.user].submit++;
      if (e.type === 'dup_check') userStats[e.user].dup++;
      if (e.type === 'grading_check') userStats[e.user].grading++;
    });

    var tbody = document.getElementById('user-tbody');
    if (filtered.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="empty">暂无数据</td></tr>';
      return;
    }
    var blacklistIds = new Set(allBlacklist.map(function (b) { return b.openId; }));
    tbody.innerHTML = filtered.map(function (u) {
      var s = userStats[u.name] || { submit: 0, dup: 0, grading: 0 };
      var badgeClass = u.authType === 'feishu' ? 'badge-feishu' : 'badge-license';
      var badgeText = u.authType === 'feishu' ? '飞书' : '激活码';
      var isBlocked = u.openId && blacklistIds.has(u.openId);
      var rowAttr = isBlocked ? ' class="blocked-row"' : '';
      var blockBtn = isBlocked
        ? '<button class="btn btn-default btn-sm jsa-unblock-btn" data-openid="' + esc(u.openId || '') + '" data-name="' + esc(u.name || '') + '">解除封禁</button>'
        : '<button class="btn btn-danger btn-sm jsa-block-btn" data-openid="' + esc(u.openId || '') + '" data-name="' + esc(u.name || '') + '">🚫 拉黑</button>';
      return '<tr' + rowAttr + '>' +
        '<td>' + esc(u.name) + (isBlocked ? ' <span class="badge badge-blocked">已封禁</span>' : '') + '</td>' +
        '<td><span class="badge ' + badgeClass + '">' + badgeText + '</span></td>' +
        '<td>' + fmtTime(u.firstSeen) + '</td>' +
        '<td>' + fmtTime(u.lastSeen) + '</td>' +
        '<td>' + s.submit + '</td>' +
        '<td>' + s.dup + '</td>' +
        '<td>' + s.grading + '</td>' +
        '<td>' + blockBtn + '</td>' +
        '</tr>';
    }).join('');
  }

  function renderEvents() {
    var typeFilter = document.getElementById('filter-event').value;
    var startDate = document.getElementById('log-start').value;
    var endDate = document.getElementById('log-end').value;

    var filtered = allEvents.filter(function (e) {
      if (typeFilter && e.type !== typeFilter) return false;
      if (startDate && e.date < startDate) return false;
      if (endDate && e.date > endDate) return false;
      return true;
    });

    var tbody = document.getElementById('event-tbody');
    if (filtered.length === 0) {
      tbody.innerHTML = '<tr><td colspan="4" class="empty">暂无数据</td></tr>';
      return;
    }

    var typeNames = {
      submit_check: '提单检测',
      dup_check: '查重',
      grading_check: '定级检查',
      submit_force: '强制放行',
      feishu_login: '飞书登录',
      license_activate: '激活码激活',
    };

    var slice = filtered.slice().reverse().slice(0, 500);
    tbody.innerHTML = slice.map(function (e) {
      return '<tr>' +
        '<td>' + fmtTime(e.ts) + '</td>' +
        '<td>' + esc(e.user) + '</td>' +
        '<td>' + (typeNames[e.type] || e.type) + '</td>' +
        '<td style="color:#6B778C;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(e.detail || '') + '</td>' +
        '</tr>';
    }).join('');
  }

  function renderDaily() {
    var dates = Object.keys(allDaily).sort().reverse();
    var tbody = document.getElementById('daily-tbody');
    if (dates.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="empty">暂无数据</td></tr>';
      return;
    }
    tbody.innerHTML = dates.map(function (d) {
      var row = allDaily[d];
      return '<tr>' +
        '<td>' + d + '</td>' +
        '<td>' + (row.dau || 0) + '</td>' +
        '<td>' + (row.submit || 0) + '</td>' +
        '<td>' + (row.dup || 0) + '</td>' +
        '<td>' + (row.grading || 0) + '</td>' +
        '<td>' + (row.submitForce || 0) + '</td>' +
        '</tr>';
    }).join('');
  }

  function addToBlacklist(name, openId) {
    if (!openId) { alert('该用户没有飞书 OpenID，无法加入黑名单'); return; }
    if (allBlacklist.some(function (b) { return b.openId === openId; })) { alert('该用户已在黑名单中'); return; }
    if (!confirm('确定要封禁用户「' + name + '」吗？封禁后该用户将无法使用插件。')) return;
    allBlacklist.push({ name: name, openId: openId, blockedAt: Date.now() });
    chrome.storage.local.set({ jsa_blacklist: allBlacklist }, function () {
      renderUsers();
      renderBlacklist();
    });
  }

  function removeFromBlacklist(openId) {
    if (!confirm('确定要解除该账号的封禁吗？')) return;
    allBlacklist = allBlacklist.filter(function (b) { return b.openId !== openId; });
    chrome.storage.local.set({ jsa_blacklist: allBlacklist }, function () {
      renderUsers();
      renderBlacklist();
    });
  }

  function renderBlacklist() {
    var countEl = document.getElementById('blacklist-count');
    if (countEl) countEl.textContent = allBlacklist.length;
    var tbody = document.getElementById('blacklist-tbody');
    if (!tbody) return;
    if (allBlacklist.length === 0) {
      tbody.innerHTML = '<tr><td colspan="4" class="empty">暂无封禁账号</td></tr>';
      return;
    }
    tbody.innerHTML = allBlacklist.map(function (b) {
      return '<tr>' +
        '<td>' + esc(b.name || '-') + '</td>' +
        '<td style="font-family:monospace;font-size:12px;color:#6B778C">' + esc(b.openId || '-') + '</td>' +
        '<td>' + fmtTime(b.blockedAt) + '</td>' +
        '<td><button class="btn btn-default btn-sm jsa-unblock-btn" data-openid="' + esc(b.openId || '') + '" data-name="' + esc(b.name || '') + '">解除封禁</button></td>' +
        '</tr>';
    }).join('');
  }

  function fmtTime(ts) {
    if (!ts) return '-';
    var d = new Date(ts);
    return d.getFullYear() + '-' +
      String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0') + ' ' +
      String(d.getHours()).padStart(2, '0') + ':' +
      String(d.getMinutes()).padStart(2, '0');
  }

  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function exportCSV(type) {
    var headers = [], data = [];
    if (type === 'users') {
      headers = ['用户名', '认证方式', '首次使用', '最后活跃', '提单拦截', '查重次数', '定级检查'];
      var userStats = {};
      allEvents.forEach(function (e) {
        if (!userStats[e.user]) userStats[e.user] = { submit: 0, dup: 0, grading: 0 };
        if (e.type === 'submit_check') userStats[e.user].submit++;
        if (e.type === 'dup_check') userStats[e.user].dup++;
        if (e.type === 'grading_check') userStats[e.user].grading++;
      });
      data = allUsers.map(function (u) {
        var s = userStats[u.name] || { submit: 0, dup: 0, grading: 0 };
        return [u.name, u.authType === 'feishu' ? '飞书' : '激活码', fmtTime(u.firstSeen), fmtTime(u.lastSeen), s.submit, s.dup, s.grading];
      });
    } else if (type === 'events') {
      headers = ['时间', '用户', '操作类型', '详情'];
      data = allEvents.slice().reverse().map(function (e) {
        return [fmtTime(e.ts), e.user, e.type, e.detail || ''];
      });
    } else {
      headers = ['日期', '活跃用户', '提单检测', '查重', '定级检查', '强制放行'];
      data = Object.keys(allDaily).sort().reverse().map(function (d) {
        var r = allDaily[d];
        return [d, r.dau || 0, r.submit || 0, r.dup || 0, r.grading || 0, r.submitForce || 0];
      });
    }
    var csv = [headers].concat(data).map(function (r) {
      return r.map(function (c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(',');
    }).join('\n');
    var blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'jsa_' + type + '_' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
  }

  function clearAllData() {
    if (!confirm('确定要清空所有使用数据吗？此操作不可恢复！')) return;
    chrome.storage.local.remove(['jsa_usage_users', 'jsa_usage_events', 'jsa_usage_daily'], function () {
      allUsers = []; allEvents = []; allDaily = {};
      renderStats(); renderUsers(); renderEvents(); renderDaily();
      alert('数据已清空');
    });
  }

  // ---- 初始化：绑定所有事件 ----
  function init() {
    // 密码输入框回车
    document.getElementById('admin-pwd').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') checkAdminPwd();
    });
    // 进入后台按钮
    document.getElementById('btn-login').addEventListener('click', checkAdminPwd);
    // 刷新按钮
    document.getElementById('btn-refresh').addEventListener('click', loadData);
    // 清空数据按钮
    document.getElementById('btn-clear').addEventListener('click', clearAllData);
    // Tab 切换按钮
    var tabBtns = document.querySelectorAll('.tab-btn');
    var tabNames = ['users', 'events', 'daily', 'blacklist'];
    tabBtns.forEach(function (btn, i) {
      btn.addEventListener('click', function () { switchTab(tabNames[i]); });
    });
    // 用户搜索
    document.getElementById('search-user').addEventListener('input', renderUsers);
    // 认证方式筛选
    document.getElementById('filter-auth').addEventListener('change', renderUsers);
    // 导出 CSV 按钮
    document.getElementById('btn-export-users').addEventListener('click', function () { exportCSV('users'); });
    document.getElementById('btn-export-events').addEventListener('click', function () { exportCSV('events'); });
    document.getElementById('btn-export-daily').addEventListener('click', function () { exportCSV('daily'); });
    // 事件类型筛选
    document.getElementById('filter-event').addEventListener('change', renderEvents);
    // 查询按钮
    document.getElementById('btn-query-events').addEventListener('click', renderEvents);
    // 用户列表：拉黑/解除封禁（事件委托）
    document.getElementById('user-tbody').addEventListener('click', function (e) {
      var btn = e.target.tagName === 'BUTTON' ? e.target : null;
      if (!btn) return;
      if (btn.classList.contains('jsa-block-btn')) {
        addToBlacklist(btn.getAttribute('data-name'), btn.getAttribute('data-openid'));
      } else if (btn.classList.contains('jsa-unblock-btn')) {
        removeFromBlacklist(btn.getAttribute('data-openid'));
      }
    });
    // 黑名单：解除封禁（事件委托）
    document.getElementById('blacklist-tbody').addEventListener('click', function (e) {
      var btn = e.target.tagName === 'BUTTON' ? e.target : null;
      if (btn && btn.classList.contains('jsa-unblock-btn')) {
        removeFromBlacklist(btn.getAttribute('data-openid'));
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
