/* eslint-disable no-undef */

// ===========================================================================
// JIRA效率助手  Background Service Worker (合并版 v3.0.0)
// ===========================================================================
// 本文件由原 JIRA效率助手 SW 与 Jira Smart Assistant SW 合并而成，包含：
//   1. 存储缓存 + 现有消息处理器（getIcon/getDomains/getOptions/getTemplates ...）
//   2. 内网平台统计上报（reportUsage → http://10.24.137.36:9527）
//   3. HMAC-SHA256 激活码校验（CHECK_LICENSE / ACTIVATE_LICENSE）
//   4. 定级规格 / 包名映射存储（UPLOAD_SPEC / UPLOAD_PKG_MAP ...）
//   5. 飞书 OAuth 登录 + 用户信息获取
//   6. 飞书多维表格统计双发（syncToFeishu）
//   7. 飞书标签页回调监听（chrome.tabs.onUpdated）
// ===========================================================================

// ---------------------------------------------------------------------------
// 常量定义
// ---------------------------------------------------------------------------

// HMAC 激活码签名密钥（从 minified 产物反混淆）
const HMAC_SECRET = 'JSA_HMAC_K3y_2026!@#LenovoTablet';

// 飞书应用配置
// const FEISHU_APP_ID = 'cli_a95705aff738dbc9';
// const FEISHU_APP_SECRET = '04FJIJNSz8ojRPtv358sbgf8ZJxMjaV1';
const FEISHU_TOKEN_URL = 'https://open.feishu.cn/open-apis/authen/v1/oidc/access_token';
const FEISHU_USER_URL = 'https://open.feishu.cn/open-apis/authen/v1/user_info';
const FEISHU_APP_TOKEN_URL = 'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal';
const FEISHU_APP_TOKEN_URL_LEGACY = 'https://open.feishu.cn/open-apis/auth/v3/app_access_token/internal';

// 飞书多维表格配置
var FEISHU_APP_ID = 'cli_a960ac9af7f81bb4';
var FEISHU_APP_SECRET = 'aLOd0O4bnxUhKS3OvYLUBghzvuPWWJs0';
var BITABLE_APP_TOKEN = 'OP58b7qwyaSCTOs66NzcyXTqnCf';
var BITABLE_USERS_TBL = 'tblB1LAb9edbQ5hC';
var BITABLE_EVENTS_TBL = 'tbltH9uBiKypQeJZ';

// const BITABLE_APP_TOKEN = 'OP58b7qwyaSCTOs66NzcyXTqnCf';
// const BITABLE_USERS_TBL = 'tblB1LAb9edbQ5hC';
// const BITABLE_EVENTS_TBL = 'tbltH9uBiKypQeJZ';
const BITABLE_BASE = 'https://open.feishu.cn/open-apis/bitable/v1/apps/' + BITABLE_APP_TOKEN;

// 内网统计上报地址
const INTRANET_REPORT_URL = 'http://10.24.137.36:9527/api/report/usage';

// ===== 环境配置：切换本地/远程只需改这一行 =====
// 'local'  → 本地 Docker (127.0.0.1:8080)
// 'remote' → 远程正式 (10.24.137.80:8080)
var JSA_ENV = 'remote';
var JSA_BASE_URL = JSA_ENV === 'local' ? 'http://127.0.0.1:8080' : 'http://10.24.137.80:8080';
var JSA_API_KEY = 'ext_jsa_2024_similar_search';
// ===============================================

// 飞书回调匹配
// 飞书回调匹配（兼容 Chrome chromiumapp.org 和 Firefox 扩展回调 URL）
const FEISHU_CALLBACK_MATCH_LIST = [
  'chromiumapp.org/feishu-callback',
  'feishu-callback.html',
  '/feishu-callback',
];

// ---------------------------------------------------------------------------
// Storage cache — loaded once on startup and kept in sync via onChanged
// ---------------------------------------------------------------------------

const storageCache = {};

const initStorageCache = getAllStorageSyncData().then((items) => {
  Object.assign(storageCache, items);
});

async function buildStorageCache() {
  try {
    await initStorageCache;
  } catch (e) {
    console.error('Storage cache init failed:', e);
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function openOptionsPage(param = '') {
  chrome.tabs.create({ url: chrome.runtime.getURL('dist/index.html' + param) });
}

function openSupportersPage() {
  chrome.tabs.create({ url: 'https://www.buymeacoffee.com/thisissteven' });
}

function getTemplates() {
  return JSON.parse(storageCache.templates);
}

function getOptions() {
  return JSON.parse(storageCache.options);
}

// ---------------------------------------------------------------------------
// [自更新检查] Firefox 端 — 与 Chrome 端一致的内置检查逻辑
// ---------------------------------------------------------------------------
const FF_UPDATE_JSON_URL = 'http://10.24.137.80/jsa-dist/updates.json';
const FF_UPDATE_INSTRUCTIONS_URL = 'http://10.24.137.80/jsa-dist/update-instructions.html';
const FF_UPDATE_CHECK_ALARM = 'ff-update-check';
const FF_UPDATE_NOTIFIED_KEY = 'ff_update_notified_version';

function ffCompareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const va = pa[i] || 0;
    const vb = pb[i] || 0;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

async function ffCheckUpdate(options = {}) {
  try {
    const currentVersion = chrome.runtime.getManifest().version;
    const res = await fetch(FF_UPDATE_JSON_URL, { cache: 'no-store' });
    if (!res.ok) {
      console.log('[FF-UpdateCheck] fetch 失败:', res.status);
      return options.returnResult ? { ok: false, error: 'fetch 失败:' + res.status } : null;
    }
    const data = await res.json();
    const updates = data && data.addons && data.addons['jira-template-manager@shugan']
      && data.addons['jira-template-manager@shugan'].updates || [];
    if (!updates.length) {
      console.log('[FF-UpdateCheck] updates.json 无版本条目');
      return options.returnResult ? { ok: false, error: '无版本条目' } : null;
    }
    // 找到最新版本(updates 数组按时间倒序,第一个最新)
    const latest = updates[0];
    const remoteVersion = latest.version;
    console.log('[FF-UpdateCheck] 当前:', currentVersion, '远程:', remoteVersion);

    const hasUpdate = ffCompareVersions(remoteVersion, currentVersion) === 1;

    if (options.returnResult) {
      return {
        ok: true,
        hasUpdate,
        currentVersion,
        latestVersion: remoteVersion,
        updateInstructionsUrl: FF_UPDATE_INSTRUCTIONS_URL,
      };
    }

    if (!hasUpdate) return null;

    // 通知去重
    if (!options.forceNotify) {
      const notified = await chrome.storage.local.get(FF_UPDATE_NOTIFIED_KEY);
      if (notified[FF_UPDATE_NOTIFIED_KEY] === remoteVersion) {
        console.log('[FF-UpdateCheck] 已通知过', remoteVersion, '，跳过');
        return null;
      }
    }

    chrome.notifications.create('ff-update-check-' + remoteVersion, {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('assets/icons/icon128.png'),
      title: 'JIRA效率助手有新版本',
      message: '新版本 ' + remoteVersion + ' 可用，点击查看更新方式',
      priority: 2,
    });
    const obj = {};
    obj[FF_UPDATE_NOTIFIED_KEY] = remoteVersion;
    await chrome.storage.local.set(obj);
    console.log('[FF-UpdateCheck] 已弹出通知，版本:', remoteVersion);
    return null;
  } catch (err) {
    console.log('[FF-UpdateCheck] 检查失败:', err.message);
    return options.returnResult ? { ok: false, error: err.message } : null;
  }
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener(async (details) => {
  switch (details.reason) {
    case 'install':
      openOptionsPage();
      break;
    case 'update':
      openOptionsPage('?newVersion');
      break;
    default:
      break;
  }
  await buildStorageCache();
  // [合并Jira工具套件] 初始化问题单提醒闹钟和 Badge
  reminderSetupAlarms();
  reminderRefreshBadge();
  // [自更新检查] 扩展更新后检查一次新版本
  ffCheckUpdate();
  // 创建 8 小时定时检查 alarm
  chrome.alarms.create(FF_UPDATE_CHECK_ALARM, { periodInMinutes: 8 * 60 });
});

// 浏览器启动时也初始化提醒
chrome.runtime.onStartup.addListener(() => {
  reminderSetupAlarms();
  reminderRefreshBadge();
  // [自更新检查] 启动时检查一次
  ffCheckUpdate();
  chrome.alarms.create(FF_UPDATE_CHECK_ALARM, { periodInMinutes: 8 * 60 });
});


chrome.action.onClicked.addListener(async () => {
  openOptionsPage();
  await buildStorageCache();
});

// Keep storageCache in sync with any external changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.templates) storageCache.templates = changes.templates.newValue;
  if (changes.options) storageCache.options = changes.options.newValue;

  // [合并新增] 监听 jsaLicense 变化，在激活成功时记录使用统计
  if (changes.jsaLicense) {
    var newVal = changes.jsaLicense.newValue;
    var oldVal = changes.jsaLicense.oldValue;
    if (newVal && newVal.user && (!oldVal || oldVal.key !== newVal.key)) {
      recordUsageEvent(newVal.user, 'license_activate', '激活码激活').catch(() => {});
    }
  }
});

// ---------------------------------------------------------------------------
// Context menu click — inject content script then forward the template
// ---------------------------------------------------------------------------

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const templates = getTemplates().filter((item) => item.quickAccessContextMenu);

  const matchIndex = templates.findIndex((_, j) => info.menuItemId === `contextMenu${j}`);
  if (matchIndex === -1) return;

  chrome.scripting.executeScript(
    { target: { tabId: tab.id }, files: ['contentScript.js'] },
    () => {
      chrome.tabs.sendMessage(tab.id, {
        contextMenu: templates[matchIndex].ticketDesc,
        templateType: templates[matchIndex].issueType,
      });
    }
  );
});

// ===========================================================================
// HMAC-SHA256 激活码校验模块（从 minified 产物反混淆）
// ===========================================================================

/**
 * 校验激活码签名
 * 格式：JSA-{user}-{YYYYMMDD}-{8位hex签名}
 * @param {string} licenseKey
 * @returns {Promise<{valid, user, expireDate, expired, error}>}
 */
async function validateLicenseKey(licenseKey) {
  if (!licenseKey) return { valid: false, user: '', expireDate: '', expired: false, error: '激活码为空' };

  const match = String(licenseKey).trim().match(/^(JSA-(.+)-(\d{8}))-([a-f0-9]{8})$/i);
  if (!match) return { valid: false, user: '', expireDate: '', expired: false, error: '激活码格式无效' };

  const user = match[2];
  const dateStr = match[3];
  const signature = match[4];

  // 计算 HMAC-SHA256(密钥, user) 取前8位
  const computedSig = await computeHmacHex(HMAC_SECRET, user);
  if (signature.toLowerCase() !== computedSig.substring(0, 8)) {
    return { valid: false, user: '', expireDate: '', expired: false, error: '激活码无效（签名校验失败）' };
  }

  // 解析过期日期 YYYYMMDD → 当天 23:59:59
  const year = parseInt(dateStr.substring(0, 4), 10);
  const month = parseInt(dateStr.substring(4, 6), 10) - 1;
  const day = parseInt(dateStr.substring(6, 8), 10);
  const expireDate = new Date(year, month, day, 23, 59, 59);
  const expired = new Date() > expireDate;

  return {
    valid: true,
    user,
    expireDate: year + '-' + String(month + 1).padStart(2, '0') + '-' + String(day).padStart(2, '0'),
    expired,
    error: expired ? '许可证已过期' : undefined,
  };
}

/**
 * 计算 HMAC-SHA256 并返回 hex 字符串
 */
async function computeHmacHex(key, message) {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(key);
  const msgData = encoder.encode(message);
  const cryptoKey = await crypto.subtle.importKey('raw', keyData, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sigBuf = await crypto.subtle.sign('HMAC', cryptoKey, msgData);
  return Array.from(new Uint8Array(sigBuf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * 查询当前激活状态（读取 jsaLicense 并校验）
 */
async function checkLicenseStatus() {
  const empty = { activated: false, expired: false, user: '', expireDate: '', licenseKey: '' };
  return new Promise((resolve) => {
    chrome.storage.local.get(['jsaLicense'], async (result) => {
      const stored = result.jsaLicense;
      if (!stored || !stored.key) return resolve(empty);
      const info = await validateLicenseKey(stored.key);
      resolve({
        activated: info.valid,
        expired: info.expired,
        user: info.user,
        expireDate: info.expireDate,
        licenseKey: stored.key,
      });
    });
  });
}

// ===========================================================================
// 飞书 OAuth 模块
// ===========================================================================

async function feishuGetAppToken() {
  const resp = await fetch(FEISHU_APP_TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ app_id: FEISHU_APP_ID, app_secret: FEISHU_APP_SECRET }),
  });
  const data = await resp.json();
  if (data.code !== 0) throw new Error('获取 tenant_access_token 失败: ' + data.msg);
  return data.tenant_access_token;
}

async function feishuExchangeToken(code) {
  const appToken = await feishuGetAppToken();
  const resp = await fetch(FEISHU_TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + appToken },
    body: JSON.stringify({ grant_type: 'authorization_code', code }),
  });
  const data = await resp.json();
  if (data.code !== 0) throw new Error('换取用户 token 失败: ' + data.msg);
  return data.data;
}

async function feishuGetUserInfo(userToken) {
  const resp = await fetch(FEISHU_USER_URL, { headers: { Authorization: 'Bearer ' + userToken } });
  const data = await resp.json();
  if (data.code !== 0) throw new Error('获取用户信息失败: ' + data.msg);
  return data.data;
}

// ===========================================================================
// 使用统计：本地存储 + 飞书多维表格双发
// ===========================================================================

function getToday() {
  return new Date().toISOString().slice(0, 10);
}

/**
 * 记录使用事件：写入本地 storage + fire-and-forget 同步飞书表格
 * @param {string} user 用户名
 * @param {string} type 事件类型（feishu_login/license_activate/submit_check/dup_check/grading_check/submit_force/template_apply/validation_check）
 * @param {string} detail 详情
 */
async function recordUsageEvent(user, type, detail) {
  if (!user) return;
  const today = getToday();
  const ts = Date.now();
  const result = await chrome.storage.local.get(['jsa_usage_users', 'jsa_usage_events', 'jsa_usage_daily']);
  let users = result.jsa_usage_users || [];
  let events = result.jsa_usage_events || [];
  const daily = result.jsa_usage_daily || {};

  // 更新用户记录
  const existUser = users.find((u) => u.name === user);
  if (!existUser) {
    users.push({ name: user, authType: type === 'feishu_login' ? 'feishu' : 'license', firstSeen: ts, lastSeen: ts });
  } else {
    existUser.lastSeen = ts;
    if (type === 'feishu_login') existUser.authType = 'feishu';
  }

  // 记录事件（最多 5000 条）
  events.push({ ts, date: today, user, type, detail: detail || '' });
  if (events.length > 5000) events = events.slice(events.length - 5000);

  // 每日聚合
  if (!daily[today]) daily[today] = { dau: 0, dauSet: [], submit: 0, dup: 0, grading: 0 };
  const dayData = daily[today];
  if (!dayData.dauSet) dayData.dauSet = [];
  if (!dayData.dauSet.includes(user)) {
    dayData.dauSet.push(user);
    dayData.dau = dayData.dauSet.length;
  }
  if (type === 'submit_check') dayData.submit = (dayData.submit || 0) + 1;
  if (type === 'dup_check') dayData.dup = (dayData.dup || 0) + 1;
  if (type === 'grading_check') dayData.grading = (dayData.grading || 0) + 1;
  if (type === 'submit_force') dayData.submitForce = (dayData.submitForce || 0) + 1;

  await chrome.storage.local.set({ jsa_usage_users: users, jsa_usage_events: events, jsa_usage_daily: daily });

  // fire-and-forget 飞书同步（失败静默降级）
  syncToFeishu(user, type, detail).catch((e) => console.warn('[JSA] Feishu sync failed:', e));
}

/**
 * 同步至飞书多维表格（用户表 + 事件表）
 */
async function syncToFeishu(userName, type, detail) {
  const appTk = await feishuGetAppToken();
  const h = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + appTk };

  const sr = await chrome.storage.local.get(['jsa_feishu_user']);
  const fu = sr.jsa_feishu_user;
  const openId = fu && fu.name === userName ? fu.openId || '' : '';
  const email = fu && fu.name === userName ? fu.email || '' : '';

  const now = new Date().toISOString();
  const today = now.slice(0, 10);
  const ts = Date.now();

  // 查询用户是否已存在
  const filterCond = openId
    ? [{ field_name: 'openId', operator: 'is', value: [openId] }]
    : [{ field_name: '文本', operator: 'is', value: [userName] }];
  const srResp = await fetch(BITABLE_BASE + '/tables/' + BITABLE_USERS_TBL + '/records/search', {
    method: 'POST',
    headers: h,
    body: JSON.stringify({ filter: { conjunction: 'and', conditions: filterCond } }),
  });
  const srData = await srResp.json();
  const items = (srData.data && srData.data.items) || [];

  if (items.length > 0) {
    // 更新已有用户
    const rid = items[0].record_id;
    const ef = items[0].fields;
    const upd = { lastSeen: now };
    if (type === 'feishu_login') upd.loginCount = (ef.loginCount || 0) + 1;
    if (type === 'submit_check') upd.submitCount = (ef.submitCount || 0) + 1;
    if (type === 'dup_check') upd.dupCount = (ef.dupCount || 0) + 1;
    if (type === 'grading_check') upd.gradingCount = (ef.gradingCount || 0) + 1;
    await fetch(BITABLE_BASE + '/tables/' + BITABLE_USERS_TBL + '/records/' + rid, {
      method: 'PUT',
      headers: h,
      body: JSON.stringify({ fields: upd }),
    });
  } else {
    // 新建用户记录
    await fetch(BITABLE_BASE + '/tables/' + BITABLE_USERS_TBL + '/records', {
      method: 'POST',
      headers: h,
      body: JSON.stringify({
        fields: {
          '文本': userName,
          openId,
          email,
          authType: type === 'feishu_login' ? 'feishu' : 'license',
          firstSeen: now,
          lastSeen: now,
          loginCount: type === 'feishu_login' ? 1 : 0,
          submitCount: type === 'submit_check' ? 1 : 0,
          dupCount: type === 'dup_check' ? 1 : 0,
          gradingCount: type === 'grading_check' ? 1 : 0,
        },
      }),
    });
  }

  // 记录事件流水
  await fetch(BITABLE_BASE + '/tables/' + BITABLE_EVENTS_TBL + '/records', {
    method: 'POST',
    headers: h,
    body: JSON.stringify({
      fields: {
        '多行文本': userName + '-' + type + '-' + today,
        ts,
        date: today,
        user: userName,
        type,
        detail: detail || '',
        openId,
      },
    }),
  });
}

// ===========================================================================
// 统一消息处理器
// ===========================================================================

// 现有 string-key 处理器
const messageHandlers = {
  getIcon: () => chrome.runtime.getURL('assets/icons/icon16.png'),
  getDomains: () => getOptions().validDomains,
  getOptions: () => getOptions(),
  getTemplates: () => getTemplates(),
  getButtonsForComment: () =>
    // 修复: 兜底 item.quickAccessButton，兼容存量数据(通过 JIRA 页面工具栏创建的旧模板
    // quickAccessCommentButton 恒为 false)，使其与 HomePage.vue / default-templates.json
    // 行为一致：只要 description 按钮启用，comment 区也显示快速填充按钮。
    getTemplates().filter((item) => item.issueType.toLowerCase() === 'comment' || item.quickAccessCommentButton || item.quickAccessButton),
  getButtonsForDescription: () => getTemplates().filter((item) => item.quickAccessButton),
  getEntriesForDropdown: () => getTemplates().filter((item) => item.templateName !== '' && item.quickAccessDropdown),
  getSupportersPage: () => {
    openSupportersPage();
    return 'done';
  },
};

// object-key（action）处理器：合并新增
const actionHandlers = {
  // ---- 激活码 ----
  CHECK_LICENSE: async () => ({ success: true, data: await checkLicenseStatus() }),

  ACTIVATE_LICENSE: async (payload) => {
    const info = await validateLicenseKey(payload.key);
    if (info.valid) {
      await chrome.storage.local.set({
        jsaLicense: { key: payload.key.trim(), user: info.user, expireDate: info.expireDate, activatedAt: Date.now() },
      });
    }
    return { success: info.valid, data: info, error: info.error };
  },

  // ---- 定级规格 ----
  UPLOAD_SPEC: async (payload) => {
    const spec = { version: '1.0', rules: [], uploadedAt: Date.now(), fileName: payload.fileName };
    await chrome.storage.local.set({ gradingSpec: spec, specRawContent: payload.content });
    return { success: true };
  },

  GET_SPEC_STATUS: async () => {
    const t = await chrome.storage.local.get('gradingSpec');
    return t.gradingSpec ? { success: true, data: { loaded: true, spec: t.gradingSpec } } : { success: true, data: { loaded: false } };
  },

  // ---- 包名映射 ----
  UPLOAD_PKG_MAP: async (payload) => {
    await chrome.storage.local.set({
      pkgMapEntries: payload.entries,
      pkgMapFileName: payload.fileName,
      pkgMapUploadedAt: Date.now(),
      pkgMapCount: payload.entries.length,
    });
    console.log('[Jira助手] 已保存包名映射表: ' + payload.entries.length + ' 条');
    return { success: true };
  },

  GET_PKG_MAP_STATUS: async () => {
    const t = await chrome.storage.local.get(['pkgMapFileName', 'pkgMapCount', 'pkgMapUploadedAt']);
    return t.pkgMapFileName
      ? { success: true, data: { loaded: true, fileName: t.pkgMapFileName, count: t.pkgMapCount, uploadedAt: t.pkgMapUploadedAt } }
      : { success: true, data: { loaded: false } };
  },

  GET_SETTINGS: async () => {
    const t = await chrome.storage.local.get('pluginSettings');
    return { success: true, data: t.pluginSettings || undefined };
  },

  // ---- 飞书认证 ----
  FEISHU_AUTH_CODE: async (payload) => {
    const code = payload && payload.code;
    if (!code) throw new Error('缺少授权码');
    const tokenData = await feishuExchangeToken(code);
    const userInfo = await feishuGetUserInfo(tokenData.access_token);
    const user = {
      openId: userInfo.open_id,
      name: userInfo.name || userInfo.en_name || userInfo.open_id,
      email: userInfo.email || userInfo.enterprise_email || '',
      avatar: userInfo.avatar_url || '',
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token,
      expiresAt: Date.now() + (tokenData.expires_in || 7200) * 1000,
    };
    await chrome.storage.local.set({ jsa_feishu_user: user });
    await recordUsageEvent(user.name, 'feishu_login', '飞书登录');
    return user;
  },

  GET_FEISHU_USER: async () => {
    const result = await chrome.storage.local.get('jsa_feishu_user');
    return result.jsa_feishu_user || null;
  },

  FEISHU_LOGOUT: async () => {
    await chrome.storage.local.remove('jsa_feishu_user');
    return true;
  },

  // ---- 使用统计双发 ----
  RECORD_USAGE: async (payload) => {
    const p = payload || {};
    await recordUsageEvent(p.user, p.type, p.detail);
    return true;
  },
};

// ---------------------------------------------------------------------------
// 统一 onMessage 监听器（兼容 string key + object action）
// ---------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  // 1) string-key 请求（现有插件用法）
  if (typeof request === 'string' && messageHandlers[request]) {
    sendResponse(messageHandlers[request]());
    return;
  }


  // [合并Jira工具套件] 问题单提醒消息处理
  if (typeof request === 'object' && (request.type === 'REMINDER_DATA_UPDATED' || request.type === 'REMINDER_MONITOR_UPDATED')) {
    reminderRefreshBadge();
    sendResponse({ ok: true });
    return;
  }
  if (typeof request === 'object' && request.type === 'REMINDER_SETTINGS_UPDATED') {
    reminderSetupAlarms();
    // 立即检查一次
    reminderTryAutoSync().then(function() { reminderCheckPending(); });
    sendResponse({ ok: true });
    return;
  }
  if (typeof request === 'object' && request.type === 'REMINDER_TEST_NOTIFICATION') {
    // 发送测试通知
    chrome.notifications.create('jsa-reminder-test-' + Date.now(), {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('assets/icons/icon128.png'),
      title: '问题单提醒测试',
      message: '这是一条测试通知，说明通知功能正常工作。',
      priority: 2,
      requireInteraction: true,
    }, function(notificationId) {
      if (chrome.runtime.lastError) {
        console.error('[Reminder] 通知创建失败:', chrome.runtime.lastError.message);
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        console.log('[Reminder] 测试通知已发送:', notificationId);
        sendResponse({ ok: true });
      }
    });
    return true; // 异步响应
  }
  // [自更新检查] 手动检查更新（来自 HubPage 的"检查更新"按钮）
  if (typeof request === 'object' && request.type === 'CHECK_UPDATE_MANUAL') {
    ffCheckUpdate({ returnResult: true, forceNotify: false })
      .then(result => sendResponse(result || { ok: false, error: '未知错误' }))
      .catch(err => sendResponse({ ok: false, error: err.message || String(err) }));
    return true; // 异步响应
  }

  // [合并Jira工具套件] 飞书通知专用 Jira 代理请求
  if (typeof request === 'object' && request.type === 'FEISHU_JIRA_FETCH') {
    feishuJiraProxyFetch(request.payload)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ error: true, message: err.message || String(err) }));
    return true;
  }

  // [合并Jira工具套件] 审计扫描 — Jira API 代理（通过SW请求避免Mixed Content）
  if (typeof request === 'object' && request.type === 'AUDIT_JIRA_SEARCH') {
    const { jql, domain, contextPath, startAt, maxResults, fields } = request.payload;
    const base = (domain || 'tbjira.lenovo.com').replace(/^https?:\/\//, '');
    const ctx = (contextPath || '').replace(/\/$/, '');
    const url = `${'https://' + base}${ctx}/rest/api/2/search?jql=${encodeURIComponent(jql)}&startAt=${startAt || 0}&maxResults=${maxResults || 100}&fields=${fields || '*all'}`;
    fetch(url, { credentials: 'include', headers: { Accept: 'application/json' } })
      .then(r => r.ok ? r.json().then(d => sendResponse({ ok: true, data: d })) : sendResponse({ ok: false, status: r.status }))
      .catch(e => {
        // HTTPS 失败尝试 HTTP
        const httpUrl = `${'http://' + base}${ctx}/rest/api/2/search?jql=${encodeURIComponent(jql)}&startAt=${startAt || 0}&maxResults=${maxResults || 100}&fields=${fields || '*all'}`;
        fetch(httpUrl, { credentials: 'include', headers: { Accept: 'application/json' } })
          .then(r => r.ok ? r.json().then(d => sendResponse({ ok: true, data: d })) : sendResponse({ ok: false, status: r.status }))
          .catch(e2 => sendResponse({ ok: false, error: e2.message }));
      });
    return true;
  }

  if (typeof request === 'object' && request.type === 'JIRA_FETCH') {
    reminderProxyFetch(request.payload)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ error: true, message: err.message || String(err) }));
    return true;
  }
  // 2) 内网统计上报（保留原有 reportUsage 逻辑，追加飞书双发）
  // [JIRASearch集成] 查找同单 - 通过 background 代理调用 JIRASearch API（绕过 CORS）
  if (typeof request === 'object' && request.type === 'JSA_SIMILAR_SEARCH') {
    var JSA_SEARCH_API = JSA_BASE_URL + '/api/ext/similar/search';
    var controller = new AbortController();
    var timeoutId = setTimeout(function() { controller.abort(); }, 120000);
    // 构建请求体，透传 force_refresh 参数
    var reqBody = { issue_key: request.key };
    if (request.force_refresh) {
      reqBody.force_refresh = true;
    }
    // 从 chrome.storage.local 读取飞书用户信息，附带到请求体中（向后兼容）
    chrome.storage.local.get(['jsa_feishu_user'], function(storageResult) {
      var feishuUser = storageResult && storageResult.jsa_feishu_user;
      if (feishuUser && feishuUser.name) {
        reqBody.feishu_user = {
          name: feishuUser.name || '',
          email: feishuUser.email || '',
          openId: feishuUser.openId || '',
        };
      }
      fetch(JSA_SEARCH_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': JSA_API_KEY },
        body: JSON.stringify(reqBody),
        signal: controller.signal,
      }).then(async function(resp) {
        clearTimeout(timeoutId);
        if (!resp.ok) {
          var txt = await resp.text().catch(function() { return ''; });
          sendResponse({ ok: false, status: resp.status, error: txt || resp.statusText });
        } else {
          var data = await resp.json();
          sendResponse({ ok: true, data: data });
        }
      }).catch(function(err) {
        clearTimeout(timeoutId);
        sendResponse({ ok: false, error: err.message || String(err) });
      });
    });
    return true; // 异步响应
  }
  // [JIRASearch集成] 工单详情 - 通过 background 代理获取
  if (typeof request === 'object' && request.type === 'JSA_ISSUE_DETAIL') {
    var JSA_DETAIL_API = JSA_BASE_URL + '/api/ext/issue-detail/';
    var controller2 = new AbortController();
    var timeoutId2 = setTimeout(function() { controller2.abort(); }, 15000);
    fetch(JSA_DETAIL_API + encodeURIComponent(request.key), {
      method: 'GET',
      headers: { 'X-API-Key': JSA_API_KEY },
      signal: controller2.signal,
    }).then(async function(resp) {
      clearTimeout(timeoutId2);
      if (!resp.ok) {
        var txt = await resp.text().catch(function() { return ''; });
        sendResponse({ ok: false, status: resp.status, error: txt || resp.statusText });
      } else {
        var data = await resp.json();
        sendResponse({ ok: true, data: data });
      }
    }).catch(function(err) {
      clearTimeout(timeoutId2);
      sendResponse({ ok: false, error: err.message || String(err) });
    });
    return true;
  }
  if (typeof request === 'object' && request.type === 'reportUsage') {
    fetch(INTRANET_REPORT_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-API-Key': request.apiKey },
      body: JSON.stringify(request.payload),
    }).catch((e) => console.warn('UsageReporter background fetch error:', e));

    // [合并新增] 同时触发飞书表格双发（静默降级）
    if (request.payload && request.payload.action) {
      const feishuUser = request.feishuUser || request.payload.user || 'anonymous';
      const actionMap = {
        template_apply: 'template_apply',
        validation_check: 'validation_check',
      };
      const mappedType = actionMap[request.payload.action] || request.payload.action;
      recordUsageEvent(feishuUser, mappedType, request.payload.action).catch(() => {});
    }

    sendResponse({ status: 'sent' });
    return;
  }

  // 3) object-key（action）请求（合并新增）
  if (typeof request === 'object' && request.action) {
    const handler = actionHandlers[request.action];
    if (handler) {
      Promise.resolve(handler(request.payload, _sender))
        .then((result) => sendResponse({ success: true, data: result }))
        .catch((error) => sendResponse({ success: false, error: String(error) }));
      return true; // 异步响应
    }
    console.log('Unknown action:', request.action);
    sendResponse({ success: false, error: 'Unknown action: ' + request.action });
    return false;
  }

  console.log('Unhandled message:', request);
  return false;
});

// ===========================================================================
// 飞书标签页登录回调监听（独立 IIFE）
// ===========================================================================

(() => {
  'use strict';
  // 多层防重入：内存层 + session 存储层（彻底防止同一 code 并发处理）
  const handledTabs = {};      // tabId → true（进程内内存去重）
  const processedCodes = {};   // code → true（进程内 code 去重，防止同一 code 被消费两次）
  const successTabs = {};      // tabId → true（标记已登录成功的 tab，防止错误页覆盖成功页）

  /**
   * 从 chrome.storage.session 读取已处理的 code 集合
   * （MV3 Service Worker 可能被休眠重启，session 存储可跨重启持久化，且浏览器关闭自动清理）
   */
  async function loadProcessedCodesFromSession() {
    try {
      // chrome.storage.session 在 MV3 中可用（Chrome 102+）
      if (!chrome.storage.session) return;
      const r = await chrome.storage.session.get('jsa_processed_codes');
      const arr = (r && r.jsa_processed_codes) || [];
      arr.forEach((c) => { if (c) processedCodes[c] = true; });
    } catch (e) {
      console.warn('[JSA] 读取 session 已处理 code 失败（降级为内存去重）:', e);
    }
  }

  /**
   * 将 code 持久化到 session 存储（限制最多保留 20 条，防止无限增长）
   */
  async function persistCodeToSession(code) {
    try {
      if (!chrome.storage.session) return;
      const r = await chrome.storage.session.get('jsa_processed_codes');
      const arr = (r && r.jsa_processed_codes) || [];
      if (!arr.includes(code)) {
        arr.push(code);
        // 只保留最近 20 条
        const trimmed = arr.slice(-20);
        await chrome.storage.session.set({ jsa_processed_codes: trimmed });
      }
    } catch (e) {
      console.warn('[JSA] 持久化 code 到 session 失败:', e);
    }
  }

  // 启动时加载历史已处理 code（await：恢复完成后再注册监听器，消除跨 SW 重启时序窗口）
  loadProcessedCodesFromSession().finally(() => registerFeishuCallbackListeners());

  function registerFeishuCallbackListeners() {
    // tab 关闭时统一清理 tab 级状态（取代 finally 中过早释放锁）
    chrome.tabs.onRemoved.addListener((tabId) => {
      delete handledTabs[tabId];
      delete successTabs[tabId];
    });

    chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
    if (!changeInfo.url) return;
    // 兼容 Chrome (chromiumapp.org) 和 Firefox (扩展页面回调) 两种回调 URL
    const matched = FEISHU_CALLBACK_MATCH_LIST.some((m) => changeInfo.url.indexOf(m) !== -1);
    if (!matched) return;
    // 已登录成功的 tab 不再处理（防止错误页覆盖成功页）
    if (successTabs[tabId]) return;
    if (handledTabs[tabId]) return;
    handledTabs[tabId] = true;
    // 第一时间跳转到 processing 页面（避免 chromiumapp.org URL 短暂显示）
    chrome.tabs.update(tabId, {
      url: chrome.runtime.getURL('dist/feishu-callback.html?status=processing'),
    });

    try {
      const url = new URL(changeInfo.url);
      const code = url.searchParams.get('code');
      if (!code) {
        chrome.tabs.update(tabId, {
          url: chrome.runtime.getURL('dist/feishu-callback.html?error=' + encodeURIComponent('未获取到授权码')),
        });
        return;
      }

      // 关键防重入：检查 code 是否已被处理（防止同一 code 被消费两次导致飞书返回 20003）
      if (processedCodes[code]) {
        console.warn('[JSA] 检测到重复的 OAuth code（内存命中），已跳过处理:', code.substring(0, 8) + '...');
        return;
      }
      // 双保险：对 session 做一次权威 await 检查（即便内存因任何原因未命中，也以 session 为准）
      if (chrome.storage.session) {
        try {
          const sess = await chrome.storage.session.get('jsa_processed_codes');
          const sessArr = (sess && sess.jsa_processed_codes) || [];
          if (sessArr.indexOf(code) >= 0) {
            processedCodes[code] = true; // 顺便回填内存
            console.warn('[JSA] 检测到重复的 OAuth code（session 命中），已跳过处理:', code.substring(0, 8) + '...');
            return;
          }
        } catch (eSess) {
          console.warn('[JSA] session 双保险检查失败（降级为仅内存去重）:', eSess);
        }
      }
      // 立即标记 code 为已处理（同步置锁，防止并发 onUpdated 事件穿透）
      processedCodes[code] = true;
      // await 持久化：完成后再发起登录，防止 SW 在持久化未完成时被回收导致 session 丢失该 code
      await persistCodeToSession(code);

      // 直接处理登录（不跳转页面，处理完后关闭标签页）
      feishuCompleteLogin(code, tabId);
    } catch (e) {
      console.error('[JSA] 飞书回调处理异常:', e);
      // 异常路径才释放 tab 锁，允许后续重试；正常流程不释放（由 onRemoved 清理）
      delete handledTabs[tabId];
    }
  });
  } // end registerFeishuCallbackListeners

  /**
   * 完成飞书登录：3步 OAuth + 统计记录 + 页面跳转
   */
  async function feishuCompleteLogin(code, tabId) {
    try {
      // Step 1: app_access_token（兼容两种 URL）
      let appToken;
      try {
        const r1 = await fetch(FEISHU_APP_TOKEN_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json; charset=utf-8' },
          body: JSON.stringify({ app_id: FEISHU_APP_ID, app_secret: FEISHU_APP_SECRET }),
        });
        if (!r1.ok) throw new Error('HTTP ' + r1.status + ': ' + r1.statusText);
        const d1 = await r1.json();
        if (d1.code !== 0) {
          throw new Error('[Step1 获取应用凭证] code=' + d1.code + ', msg=' + (d1.msg || 'token失败') + '。请检查 App ID/Secret 是否正确，应用是否已启用');
        }
        appToken = d1.tenant_access_token;
      } catch (e1) {
        // 降级到 legacy URL
        try {
          const r1b = await fetch(FEISHU_APP_TOKEN_URL_LEGACY, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=utf-8' },
            body: JSON.stringify({ app_id: FEISHU_APP_ID, app_secret: FEISHU_APP_SECRET }),
          });
          if (!r1b.ok) throw new Error('HTTP ' + r1b.status);
          const d1b = await r1b.json();
          if (d1b.code !== 0) {
            throw new Error('[Step1 获取应用凭证-降级] code=' + d1b.code + ', msg=' + (d1b.msg || 'token失败') + '。请检查 App ID/Secret');
          }
          appToken = d1b.app_access_token;
        } catch (e1b) {
          throw new Error('[Step1 获取应用凭证失败] ' + (e1b && e1b.message ? e1b.message : String(e1b)) + '。原始错误: ' + (e1 && e1.message ? e1.message : String(e1)));
        }
      }

      // Step 2: user_access_token
      const r2 = await fetch(FEISHU_TOKEN_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=utf-8', Authorization: 'Bearer ' + appToken },
        body: JSON.stringify({ grant_type: 'authorization_code', code }),
      });
      if (!r2.ok) throw new Error('[Step2 HTTP ' + r2.status + '] 网络错误');
      const d2 = await r2.json();
      if (d2.code !== 0) {
        const hint = d2.msg && d2.msg.indexOf('redirect') >= 0
          ? '（提示：请确认飞书应用后台"安全设置 → 重定向 URL"已添加 https://<扩展ID>.chromiumapp.org/feishu-callback）'
          : '';
        throw new Error('[Step2 换取用户令牌] code=' + d2.code + ', msg=' + (d2.msg || 'user_token失败') + hint);
      }

      // Step 3: user_info
      const r3 = await fetch(FEISHU_USER_URL, { headers: { Authorization: 'Bearer ' + d2.data.access_token } });
      if (!r3.ok) throw new Error('[Step3 HTTP ' + r3.status + '] 网络错误');
      const d3 = await r3.json();
      if (d3.code !== 0) {
        throw new Error('[Step3 获取用户信息] code=' + d3.code + ', msg=' + (d3.msg || 'user_info失败') + '。请确认应用已开通"获取用户身份信息"权限');
      }

      const user = {
        openId: d3.data.open_id,
        name: d3.data.name,
        email: d3.data.email || d3.data.enterprise_email || '',
        avatar: d3.data.avatar_url || '',
        loginTime: new Date().toISOString(),
      };

      await chrome.storage.local.set({ jsa_feishu_user: user });
      console.log('[JSA] 飞书登录成功:', user.name);

      // 记录使用统计（本地 + 飞书双发）
      await recordUsageEvent(user.name, 'feishu_login', '飞书登录');

      // 关键：标记该 tab 为已登录成功，防止后续竞态的错误页面覆盖
      successTabs[tabId] = true;

      // 跳转成功页面（显示成功信息，3秒后自动关闭）
      chrome.tabs.update(tabId, {
        url: chrome.runtime.getURL('dist/feishu-callback.html?success=1&name=' + encodeURIComponent(user.name)),
      });
    } catch (err) {
      console.error('[JSA] 飞书登录流程失败:', err);
      // 保护：若该 tab 已有成功的登录态（可能是并发的重复 code 调用），不再覆盖为错误页
      if (successTabs[tabId]) {
        console.warn('[JSA] 检测到该 tab 已登录成功，跳过错误页显示:', err.message);
        return;
      }
      // 任何错误都跳转到 Options 页面（避免 feishu-callback.html CSP问题）
      var errMsg = String(err.message || err);
      // 对于 code=20003（授权码已被使用）：可能已在另一处成功消费
      if (errMsg.indexOf('20003') >= 0) {
        chrome.tabs.update(tabId, {
          url: chrome.runtime.getURL('dist/feishu-callback.html?status=processing'),
        });
        return;
      }
      // 错误：跳转到错误页面
      chrome.tabs.update(tabId, {
        url: chrome.runtime.getURL('dist/feishu-callback.html?error=' + encodeURIComponent(errMsg)),
      });
    } finally {
      // 不再在此释放 tab 锁：正常流程期间锁始终有效，由 chrome.tabs.onRemoved 在 tab 关闭时统一清理
    }
  }

  console.log('[JSA] 飞书标签页登录回调监听已启动');
})();

// ===========================================================================
// [合并Jira工具套件] 问题单提醒模块 — Alarm + Notification + Badge + ProxyFetch
// ===========================================================================

const REMINDER_ALARM_AM = 'jsa-reminder-am';
const REMINDER_ALARM_PM = 'jsa-reminder-pm';
const REMINDER_PENDING_STATUSES = ['Published', 'Verified', 'Waitforinfo'];

/** 读取提醒设置 */
async function reminderGetSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get('jsa_reminder_settings', (data) => {
      const s = data.jsa_reminder_settings
      try {
        resolve(typeof s === 'string' ? JSON.parse(s) : (s || { timeAM: '10:00', timePM: '16:00' }));
      } catch {
        resolve({ timeAM: '10:00', timePM: '16:00' });
      }
    });
  });
}

/** 计算下一个闹钟时间 */
function reminderNextAlarmTime(timeStr) {
  const [h, m] = timeStr.split(':').map(Number);
  const now = new Date();
  const target = new Date();
  target.setHours(h, m, 0, 0);
  if (target <= now) target.setDate(target.getDate() + 1);
  return target.getTime();
}

/** 设置闹钟 */
async function reminderSetupAlarms() {
  await chrome.alarms.clearAll();
  const s = await reminderGetSettings();
  const amTime = reminderNextAlarmTime(s.timeAM || '10:00');
  const pmTime = reminderNextAlarmTime(s.timePM || '16:00');
  chrome.alarms.create(REMINDER_ALARM_AM, { when: amTime, periodInMinutes: 24 * 60 });
  chrome.alarms.create(REMINDER_ALARM_PM, { when: pmTime, periodInMinutes: 24 * 60 });
  console.log('[Reminder] 闹钟已设置 - 上午:', new Date(amTime).toLocaleString(), '下午:', new Date(pmTime).toLocaleString());
}

/** 判断是否待处理 */
function reminderIsPending(issue) {
  const status = (issue.status || '').trim();
  const resolution = (issue.resolution || '').trim();
  if (REMINDER_PENDING_STATUSES.includes(status)) return true;
  if (resolution === 'Cannot Reproduce' && status === 'Resolved') return true;
  return false;
}

/** 更新 Badge */
function reminderUpdateBadge(count) {
  if (count > 0) {
    chrome.action.setBadgeText({ text: count > 99 ? '99+' : String(count) });
    chrome.action.setBadgeBackgroundColor({ color: '#EF4444' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

/** 刷新 Badge（读取本地存储数据） */
async function reminderRefreshBadge() {
  const data = await new Promise((resolve) => {
    chrome.storage.local.get(['jsa_reminder_issues', 'jsa_reminder_monitored'], resolve);
  });
  let issues = [];
  try { issues = typeof data.jsa_reminder_issues === 'string' ? JSON.parse(data.jsa_reminder_issues) : (data.jsa_reminder_issues || []); } catch { issues = []; }
  const monitored = data.jsa_reminder_monitored || [];
  if (!monitored.length) { reminderUpdateBadge(0); return; }
  const set = new Set(monitored);
  const pending = issues.filter((i) => reminderIsPending(i) && set.has(i.reporter));
  reminderUpdateBadge(pending.length);
}

/** 检查待处理并发通知 */
async function reminderCheckPending() {
  const data = await new Promise((resolve) => {
    chrome.storage.local.get(['jsa_reminder_issues', 'jsa_reminder_monitored'], resolve);
  });
  let issues = [];
  try { issues = typeof data.jsa_reminder_issues === 'string' ? JSON.parse(data.jsa_reminder_issues) : (data.jsa_reminder_issues || []); } catch { issues = []; }
  const monitored = data.jsa_reminder_monitored || [];
  if (!issues.length) {
    reminderUpdateBadge(0);
    // 本地无数据，也发通知
    chrome.notifications.create('jsa-reminder-empty-' + Date.now(), {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('assets/icons/icon128.png'),
      title: '✅ 问题单提醒',
      message: '暂无本地数据，请先在"问题单提醒"页面同步数据。',
      priority: 1,
    });
    return;
  }
  // 如果有监控人员，只通知监控人员的；否则通知所有待处理
  var pending;
  if (monitored.length) {
    var set = new Set(monitored);
    pending = issues.filter(function(i) { return reminderIsPending(i) && set.has(i.reporter); });
  } else {
    pending = issues.filter(function(i) { return reminderIsPending(i); });
  }
  reminderUpdateBadge(pending.length);
  if (pending.length > 0) {
    reminderShowNotification(pending);
  } else {
    // 没有待处理问题，也发一个通知告知
    chrome.notifications.create('jsa-reminder-empty-' + Date.now(), {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('assets/icons/icon128.png'),
      title: '✅ 问题单提醒',
      message: '当前没有待处理的问题单。',
      priority: 1,
    });
  }
}

/** 发送系统通知 */
function reminderShowNotification(issues) {
  const map = new Map();
  issues.forEach((i) => {
    const name = i.reporterDisplay || i.reporter;
    map.set(name, (map.get(name) || 0) + 1);
  });
  const entries = Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  const reporterSummary = entries.slice(0, 8).map(([n, c]) => `${n}: ${c}单`).join('、');
  const title = `待处理问题单提醒 (${issues.length}个)`;
  const message = entries.length === 1 ? `${entries[0][0]} 有 ${entries[0][1]} 个待处理问题单` : `${entries.length} 位监控人员共 ${issues.length} 个待处理问题单`;
  chrome.notifications.create('jsa-reminder-' + Date.now(), {
    type: 'basic',
    iconUrl: chrome.runtime.getURL('assets/icons/icon128.png'),
    title,
    message,
    contextMessage: reporterSummary,
    priority: 2,
    requireInteraction: true,
  });
}

/** 代理 Jira Fetch（popup→SW） */
async function reminderProxyFetch(payload) {
  const { url, contextPath, username, password, path, basicOnly } = payload;
  var base = (url || '').replace(/\/+$/, '');
  var ctx = (contextPath || '').replace(/\/+$/, '');
  var domain = base.replace(/^https?:\/\//, '');
  var apiPath = ctx + path;
  var authHeader = 'Basic ' + btoa(username + ':' + password);
  
  // 带超时的 fetch
  function fetchWithTimeout(fullUrl, opts, timeoutMs) {
    timeoutMs = timeoutMs || 8000;
    return Promise.race([
      fetch(fullUrl, opts),
      new Promise(function(_, reject) { setTimeout(function() { reject(new Error('请求超时(' + timeoutMs + 'ms)')); }, timeoutMs); })
    ]);
  }
  
  // 策略1: cookie认证（借用浏览器登录态，无需Basic Auth）
  // 策略2: Basic Auth认证（credentials: omit）
  var strategies = basicOnly ? [
    { headers: { Authorization: authHeader, Accept: 'application/json' }, credentials: 'omit' },
  ] : [
    { headers: { Authorization: authHeader, Accept: 'application/json' }, credentials: 'omit' },
    { headers: { Accept: 'application/json' }, credentials: 'include' },
  ];
  var protocols = ['https', 'http'];
  
  for (var si = 0; si < strategies.length; si++) {
    for (var pi = 0; pi < protocols.length; pi++) {
      var fullUrl = protocols[pi] + '://' + domain + apiPath;
      try {
        var resp = await fetchWithTimeout(fullUrl, { method: 'GET', headers: strategies[si].headers, credentials: strategies[si].credentials }, 8000);
        if (resp.ok) {
          return { error: false, data: await resp.json() };
        }
        if (resp.status === 401 || resp.status === 403) {
          // 认证失败，尝试下一个策略
          console.log('[Reminder] ' + protocols[pi] + ' 认证失败: ' + resp.status);
          continue;
        }
      } catch (e) {
        console.log('[Reminder] ' + protocols[pi] + ' 请求失败:', e.message);
      }
    }
  }
  return { error: true, message: '无法连接 Jira 服务器。\n请确认：\n1. 已连接公司内网/VPN\n2. Jira 地址正确：' + domain + '\n3. 用户名密码正确' };
}

/** [合并Jira工具套件] 飞书通知专用 Jira 代理 Fetch（SW中不受 Mixed Content 限制） */
async function feishuJiraProxyFetch(payload) {
  const { path, domain } = payload;
  if (!domain) return { error: true, message: 'Jira 域名未配置' };

  // 检查缓存的协议
  const cached = await new Promise((resolve) => {
    chrome.storage.local.get(['jsa_jiraProtocol'], (r) => resolve(r.jsa_jiraProtocol || ''));
  });
  const opts = { credentials: 'include', redirect: 'follow', headers: { Accept: 'application/json' } };

  // 尝试已缓存协议
  if (cached === 'https' || cached === 'http') {
    try {
      const res = await fetch(cached + '://' + domain + path, opts);
      if (res.ok || res.status === 401 || res.status === 403) {
        return { error: false, status: res.status, ok: res.ok, data: res.status === 200 ? await res.json() : null };
      }
    } catch (e) { /* 缓存失效 */ }
  }

  // 尝试 HTTPS
  try {
    const httpsRes = await fetch('https://' + domain + path, opts);
    if (httpsRes.ok || httpsRes.status === 401 || httpsRes.status === 403) {
      await chrome.storage.local.set({ jsa_jiraProtocol: 'https' });
      return { error: false, status: httpsRes.status, ok: httpsRes.ok, data: httpsRes.status === 200 ? await httpsRes.json() : null };
    }
  } catch (e) { /* HTTPS 失败 */ }

  // 尝试 HTTP（SW中不受 Mixed Content 限制）
  try {
    const httpRes = await fetch('http://' + domain + path, opts);
    if (httpRes.ok || httpRes.status === 401 || httpRes.status === 403) {
      await chrome.storage.local.set({ jsa_jiraProtocol: 'http' });
      return { error: false, status: httpRes.status, ok: httpRes.ok, data: httpRes.status === 200 ? await httpRes.json() : null };
    }
    return { error: false, status: httpRes.status, ok: httpRes.ok, data: httpRes.status === 200 ? await httpRes.json() : null };
  } catch (e) {
    return { error: true, message: '无法连接 Jira: ' + e.message };
  }
}

// 注册闹钟监听
// 定时自动同步 + 检查
async function reminderTryAutoSync() {
  const data = await new Promise((resolve) => {
    chrome.storage.local.get(['jsa_reminder_settings', 'jsa_reminder_lastSync'], resolve);
  });
  let settings = {};
  try { settings = typeof data.jsa_reminder_settings === 'string' ? JSON.parse(data.jsa_reminder_settings) : (data.jsa_reminder_settings || {}); } catch { settings = {}; }
  if (!settings.url || !settings.username || !settings.password) return;
  
  // 4小时內不同步
  const lastSync = data.jsa_reminder_lastSync;
  const hoursSinceSync = lastSync ? (Date.now() - lastSync) / (1000 * 60 * 60) : Infinity;
  if (hoursSinceSync < 4) return;
  
  try {
    const base = (settings.url || '').replace(/\/+$/, '');
    const ctx = (settings.contextPath || '').replace(/\/+$/, '');
    const authHeader = 'Basic ' + btoa(settings.username + ':' + settings.password);
    const statusList = REMINDER_PENDING_STATUSES.map(function(s) { return '"' + s + '"'; }).join(', ');
    var jql = '(status in (' + statusList + ') OR (resolution = "Cannot Reproduce" AND status = "Resolved")) ORDER BY updated DESC';
    
    // 先尝试 HTTPS 再 HTTP
    var protocols = ['https', 'http'];
    var result = null;
    for (var pi = 0; pi < protocols.length; pi++) {
      var fullUrl = protocols[pi] + '://' + base.replace(/^https?:\/\//, '') + ctx + '/rest/api/2/search?jql=' + encodeURIComponent(jql) + '&startAt=0&maxResults=500&fields=summary,status,resolution,reporter,project,priority,updated';
      try {
        var resp = await fetch(fullUrl, { method: 'GET', headers: { Authorization: authHeader, Accept: 'application/json' }, credentials: 'omit' });
        if (resp.ok) { result = await resp.json(); break; }
      } catch (e) { /* 尝试下一个协议 */ }
    }
    
    if (!result) return;
    
    var issues = (result.issues || []).map(function(i) {
      return {
        key: i.key,
        summary: (i.fields && i.fields.summary) || '',
        status: (i.fields && i.fields.status && i.fields.status.name) || '',
        resolution: (i.fields && i.fields.resolution && i.fields.resolution.name) || '',
        reporter: (i.fields && i.fields.reporter && (i.fields.reporter.name || i.fields.reporter.displayName)) || '',
        reporterDisplay: (i.fields && i.fields.reporter && i.fields.reporter.displayName) || '',
        project: (i.fields && i.fields.project && i.fields.project.key) || '',
        priority: (i.fields && i.fields.priority && i.fields.priority.name) || '',
        updated: (i.fields && i.fields.updated) || '',
      };
    });
    
    await chrome.storage.local.set({ jsa_reminder_issues: issues, jsa_reminder_lastSync: Date.now() });
    console.log('[Reminder] 自动同步完成: ' + issues.length + ' 条');
  } catch (err) {
    console.log('[Reminder] 自动同步失败:', err.message);
    // 同步失败不阻塞，继续用本地数据检查
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
if (alarm.name === REMINDER_ALARM_AM || alarm.name === REMINDER_ALARM_PM) {
    console.log('[Reminder] 定时检查触发:', alarm.name);
    // 直接检查本地数据并发通知（不自动同步，避免覆盖）
    reminderCheckPending();
  }
});

// 注册通知点击
chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId.startsWith('jsa-reminder-')) {
    chrome.action.openPopup?.();
  }
  // [自更新检查] 点击更新通知 → 打开中转说明页
  if (notificationId.startsWith('ff-update-check-')) {
    chrome.tabs.create({ url: FF_UPDATE_INSTRUCTIONS_URL });
  }
});

// [自更新检查] alarm 定时触发
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === FF_UPDATE_CHECK_ALARM) {
    ffCheckUpdate();
  }
});

// ===========================================================================
// Dev / Prod logging
// ===========================================================================

if (chrome.i18n.getMessage('DEV_MODE') === 'false') {
  ['log', 'debug', 'error', 'info', 'warn', 'table', 'trace'].forEach((m) => {
    console[m] = () => {};
  });
} else {
  console.log('[Jira助手] Background Service Worker (合并版 v3.0.0) 已启动');
}

// ===========================================================================
// Storage bootstrap utility
// ===========================================================================

function getAllStorageSyncData() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(null, (items) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(items);
      }
    });
  });
}
