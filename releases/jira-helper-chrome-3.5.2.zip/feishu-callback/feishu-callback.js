﻿// feishu-callback.js - 飞书登录回调状态页面
(function () {
  'use strict';

  var card = document.getElementById('card');
  var params = new URLSearchParams(window.location.search);

  /**
   * 关闭当前标签页（兼容 Firefox 的 window.close() 限制）
   *
   * 背景：Firefox 不允许扩展页面调用 window.close() 关闭由
   * chrome.tabs.create 打开的标签页（会静默失败）；Chrome 则允许。
   * 解决：优先通过 tabs API 获取当前 tab 并 remove，失败再降级 window.close()。
   * manifest 已声明 "tabs" 权限，两端均可正常工作。
   */
  function closeCurrentTab() {
    try {
      if (chrome && chrome.tabs && chrome.tabs.getCurrent) {
        chrome.tabs.getCurrent(function (tab) {
          if (tab && tab.id) {
            chrome.tabs.remove(tab.id, function () {
              // remove 失败（如权限不足）时降级
              if (chrome.runtime.lastError) window.close();
            });
          } else {
            window.close();
          }
        });
      } else {
        window.close();
      }
    } catch (e) {
      window.close();
    }
  }

  // 初始分发：根据 URL 参数决定渲染哪个状态（内部含 storage 兜底）
  if (params.get('success') === '1') {
    renderSuccess(params.get('name') || '');
  } else if (params.get('error')) {
    renderErrorWithFallback(params.get('error') || '未知错误');
  } else if (params.get('status') === 'processing') {
    // processing 状态下做兜底：退避重试检查登录态是否已就绪（防止 background 已成功但跳转被竞态覆盖，
    // 或 20003 经 background 改跳 processing 后等待成功路径 storage.set 完成）
    checkUserWithBackoff(function (u) {
      if (u && u.openId) {
        renderSuccess(u.name || '飞书用户');
      }
      // 否则保持 processing 默认显示（不渲染错误页）
    }, 0);
  }

  /**
   * 渲染成功页面（支持 3 秒倒计时自动关闭）
   */
  function renderSuccess(name) {
    card.innerHTML =
      '<div class="icon">✅</div>' +
      '<h2>飞书登录成功</h2>' +
      '<p class="msg">' +
        '欢迎，<span class="name">' + escHtml(name) + '</span>！<br>' +
        '插件已激活，你可以关闭此页面。' +
      '</p>' +
      '<button class="btn" id="btn-close">关闭页面</button>' +
      '<p class="countdown" id="cd">3 秒后自动关闭...</p>';
    var btnClose = document.getElementById('btn-close');
    if (btnClose) btnClose.addEventListener('click', function () { closeCurrentTab(); });
    var sec = 3;
    var timer = setInterval(function () {
      sec--;
      var cdEl = document.getElementById('cd');
      if (sec <= 0) {
        clearInterval(timer);
        closeCurrentTab();
      } else if (cdEl) {
        cdEl.textContent = sec + ' 秒后自动关闭...';
      }
    }, 1000);
  }

  /**
   * 渲染错误页面（带 storage 登录态兜底检查）
   * 关键：渲染错误页前，先检查 storage 中是否已有飞书登录态。
   * 如果登录实际已成功（background 已写入 storage），说明此错误是并发竞态导致的误报，
   * 应改显成功页面，避免误导用户。
   */
  function renderErrorWithFallback(errMsg, retry) {
    if (typeof retry !== 'number') retry = 0;
    chrome.storage.local.get(['jsa_feishu_user'], function (r) {
      var u = r && r.jsa_feishu_user;
      if (u && u.openId) {
        // 登录态已存在 → 改显成功页面（关键兜底，防止误报）
        renderSuccess(u.name || '飞书用户');
      } else if (retry < 3) {
        // 退避重试：覆盖成功路径 storage.set 的延迟窗口（300/600/1200ms）
        setTimeout(function () { renderErrorWithFallback(errMsg, retry + 1); }, [300, 600, 1200][retry]);
      } else {
        renderError(errMsg);
      }
    });
  }

  /**
   * 带退避重试地读取登录态（供 processing 分支使用）
   * @param {function} cb 回调，参数为 jsa_feishu_user（可能为 null）
   * @param {number} retry 当前重试次数
   */
  function checkUserWithBackoff(cb, retry) {
    chrome.storage.local.get(['jsa_feishu_user'], function (r) {
      var u = r && r.jsa_feishu_user;
      if (u && u.openId) {
        cb(u);
      } else if (retry < 3) {
        setTimeout(function () { checkUserWithBackoff(cb, retry + 1); }, [300, 600, 1200][retry]);
      } else {
        cb(null);
      }
    });
  }

  /**
   * 渲染错误页面（已确认 storage 无登录态）
   */
  function renderError(errMsg) {
    var tips = matchTroubleshootingTips(errMsg);
    card.innerHTML =
      '<div class="icon">❌</div>' +
      '<h2>飞书登录失败</h2>' +
      '<p class="msg">请关闭此页面，回到插件重新尝试。</p>' +
      '<div class="error-box">' +
        '<div class="error-label">错误详情：</div>' +
        '<div class="error-detail">' + escHtml(errMsg) + '</div>' +
      '</div>' +
      tips +
      '<br><button class="btn" id="btn-close2">关闭页面</button>';
    var btnClose2 = document.getElementById('btn-close2');
    if (btnClose2) btnClose2.addEventListener('click', function () { closeCurrentTab(); });
  }

  /**
   * 根据错误信息匹配对应的排查提示
   */
  function matchTroubleshootingTips(errMsg) {
    var msg = String(errMsg || '').toLowerCase();
    var tips = '';

    if (msg.indexOf('redirect') >= 0 || msg.indexOf('回调') >= 0 || msg.indexOf('重定向') >= 0) {
      tips =
        '<div class="tips"><strong>排查建议：</strong><br>' +
        '1. 登录 <a href="https://open.feishu.cn/app/cli_a960ac9af7f81bb4/safe" target="_blank">飞书应用后台 → 安全设置</a><br>' +
        '2. 在"重定向 URL"中添加当前扩展的回调地址<br>' +
        '3. 回调格式：<code>https://<扩展ID>.chromiumapp.org/feishu-callback</code><br>' +
        '4. 修改后需等待 1-2 分钟生效</div>';
    } else if (msg.indexOf('app_id') >= 0 || msg.indexOf('app_secret') >= 0 || msg.indexOf('invalid app') >= 0 || msg.indexOf('凭证') >= 0) {
      tips =
        '<div class="tips"><strong>排查建议：</strong><br>' +
        '1. 检查飞书应用 App ID/Secret 是否正确<br>' +
        '2. 确认应用状态为"已启用"<br>' +
        '3. 当前 App ID：<code>cli_a960ac9af7f81bb4</code></div>';
    } else if (msg.indexOf('code') >= 0 && (msg.indexOf('invalid') >= 0 || msg.indexOf('expire') >= 0 || msg.indexOf('used') >= 0)) {
      tips =
        '<div class="tips"><strong>排查建议：</strong><br>' +
        '授权码已失效或重复使用，请重新点击"飞书登录"按钮获取新的授权码</div>';
    } else if (msg.indexOf('permission') >= 0 || msg.indexOf('权限') >= 0 || msg.indexOf('scope') >= 0) {
      tips =
        '<div class="tips"><strong>排查建议：</strong><br>' +
        '1. 登录 <a href="https://open.feishu.cn/app/cli_a960ac9af7f81bb4/auth" target="_blank">飞书应用后台 → 权限管理</a><br>' +
        '2. 开通"获取用户身份信息"权限<br>' +
        '3. 确认应用已发布到企业</div>';
    } else if (msg.indexOf('network') >= 0 || msg.indexOf('timeout') >= 0 || msg.indexOf('超时') >= 0 || msg.indexOf('fetch') >= 0) {
      tips =
        '<div class="tips"><strong>排查建议：</strong><br>' +
        '网络连接异常，请检查：<br>' +
        '1. 网络是否能正常访问 open.feishu.cn<br>' +
        '2. 公司代理/防火墙是否放行</div>';
    } else {
      tips =
        '<div class="tips"><strong>通用排查：</strong><br>' +
        '1. 确认飞书应用后台已添加重定向 URL<br>' +
        '2. 确认 App ID/Secret 正确<br>' +
        '3. 确认应用已发布到企业且已开通用户信息权限<br>' +
        '4. 如问题持续，请将上方"错误详情"截图反馈</div>';
    }
    return tips;
  }

  function escHtml(s) {
    var amp = String.fromCharCode(38) + 'amp;';
    var lt = String.fromCharCode(38) + 'lt;';
    var gt = String.fromCharCode(38) + 'gt;';
    return String(s || '')
      .replace(/&/g, amp)
      .replace(/</g, lt)
      .replace(/>/g, gt);
  }
})();
