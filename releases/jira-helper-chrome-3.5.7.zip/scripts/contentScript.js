console.log("[JSA-DIAG] contentScript.js 已加载, host=" + location.hostname + ", path=" + location.pathname);
const UsageReporter = {
	API_URL: 'http://10.24.137.36:9527/api/report/usage',
	API_KEY: 'aitk_5660095eba0261d4865e9e2db97e67f11485137a007e8ef2',
	
	_getUser() {
		const meta = document.querySelector('meta[name="ajs-remote-user"]');
		if (meta && meta.content) {
			return meta.content;
		}
		return 'unknown_user';
	},

	async report(action, metadata = {}) {
		try {
			const userId = this._getUser();
			// 获取飞书用户信息（如果已登录）
			let feishuUser = null;
			try {
				if (window.__jsaAuth && typeof window.__jsaAuth.getUser === 'function') {
					const fu = window.__jsaAuth.getUser();
					if (fu && fu.name) feishuUser = fu.name;
				}
			} catch (e) { /* 飞书用户获取失败不影响上报 */ }
			chrome.runtime.sendMessage({
				type: 'reportUsage',
				apiKey: this.API_KEY,
				payload: {
					user_identifier: userId,
					user: userId, // 兼容飞书统计字段
					feishuUser: feishuUser,
					action: action,
					metadata: metadata,
				}
			});
		} catch (error) {
			console.warn('UsageReporter: 消息发送异常', error);
		}
	}
};

// ====== 认证门控辅助 ======
let _jsaAuthPromptTs = 0;

/**
 * 认证门控检查
 * @param {object} [opts] - { silent: true } 时不弹窗（用于被动绑定场景）
 * @returns {boolean} true=已认证可继续，false=未认证已处理
 */
function jsaRequireAuth(opts) {
	opts = opts || {};
	const silent = opts.silent;
	let authenticated = false;
	try {
		if (window.__jsaAuth && typeof window.__jsaAuth.check === 'function') {
			authenticated = !!window.__jsaAuth.check();
		} else {
			console.warn('[JSA] 认证门控: __jsaAuth 未定义，功能已禁用');
		}
	} catch (e) {
		console.warn('[JSA] 认证门控检查异常，视为未认证', e);
	}
	if (!authenticated && !silent) {
		const now = Date.now();
		if (now - _jsaAuthPromptTs > 3000) {
			_jsaAuthPromptTs = now;
			showAuthGuideDialog();
		}
	}
	return authenticated;
}

function showAuthGuideDialog() {
	const styleTag = document.createElement('style');
	styleTag.id = 'jsa-auth-guide-styles';
	if (!document.getElementById('jsa-auth-guide-styles')) {
		styleTag.textContent = `
			@keyframes jsaFadeIn { from { opacity: 0; } to { opacity: 1; } }
			@keyframes jsaSlideUp { from { opacity: 0; transform: translate(-50%, -48%); } to { opacity: 1; transform: translate(-50%, -50%); } }
			.jsa-overlay { position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;animation:jsaFadeIn .2s ease }
			.jsa-dialog { position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.25),0 0 0 1px rgba(0,0,0,.06);z-index:10000;width:420px;max-width:90vw;overflow:hidden;animation:jsaSlideUp .3s ease;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif }
			.jsa-header { display:flex;align-items:center;gap:12px;padding:20px 24px 0 }
			.jsa-icon { width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#DBEAFE,#BFDBFE);display:flex;align-items:center;justify-content:center;flex-shrink:0 }
			.jsa-icon svg { width:22px;height:22px;color:#2563EB }
			.jsa-title { font-size:17px;font-weight:600;color:#1F2937;line-height:1.3 }
			.jsa-body { padding:16px 24px 0 }
			.jsa-desc { font-size:14px;color:#6B7280;line-height:1.6;margin:0 0 14px }
			.jsa-footer { padding:20px 24px;display:flex;justify-content:flex-end;gap:10px;margin-top:8px }
			.jsa-btn { padding:9px 22px;border-radius:8px;font-size:14px;font-weight:500;cursor:pointer;transition:all .15s ease;border:none;outline:none }
			.jsa-btn:active { transform:scale(.97) }
			.jsa-btn-primary { background:linear-gradient(135deg,#3B82F6,#2563EB);color:#fff;box-shadow:0 1px 3px rgba(37,99,235,.3) }
			.jsa-btn-primary:hover { background:linear-gradient(135deg,#2563EB,#1D4ED8);box-shadow:0 2px 6px rgba(37,99,235,.4) }
		`;
		document.head.appendChild(styleTag);
	}

	const overlay = document.createElement('div');
	overlay.className = 'jsa-overlay';
	document.body.appendChild(overlay);

	const dialog = document.createElement('div');
	dialog.className = 'jsa-dialog';
	dialog.innerHTML = `
		<div class="jsa-header">
			<div class="jsa-icon">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
					<circle cx="12" cy="7" r="4"></circle>
				</svg>
			</div>
			<div class="jsa-title">需要登录后使用</div>
		</div>
		<div class="jsa-body">
			<p class="jsa-desc">请先完成飞书登录或激活码激活后使用此功能。</p>
		</div>
		<div class="jsa-footer">
			<button class="jsa-btn jsa-btn-primary" id="jsa_auth_confirm">了解</button>
		</div>
	`;
	document.body.appendChild(dialog);

	const closeDialog = () => {
		overlay.style.opacity = '0';
		dialog.style.opacity = '0';
		dialog.style.transform = 'translate(-50%, -48%)';
		setTimeout(() => {
			overlay.remove();
			dialog.remove();
		}, 200);
	};

	dialog.querySelector('#jsa_auth_confirm').addEventListener('click', closeDialog);
	overlay.addEventListener('click', closeDialog);
}

const ERROR_NO_EDIT_FIELD_VISIBLE = 'There is no textfield with custom selector visible.';
const TITLE_DROPDOWN_ICON = chrome.i18n.getMessage('html_title_of_created_dropdown');
let isJiraCloud = window.location.href.includes('atlassian.net');
let insertTemplate = true;
let cachedTemplates = async () => {
	let res = await Utils.getSyncStorage('templates');
	let isValid = true;
	return { templates: JSON.parse(res.templates), valid: isValid };
};
let templateCache;

// type var because content.js may be injected multiple times,
// which would causing errors if type const
const NEW_LINE = '\n';
const DEFAULT_TEMPLATE_ID = '默认项目';
const TEXTFIELD_IDS = '#description, #comment';

const DEFAULT_FIELDS_MAP = {
  'Gerrit Id': 'customfield_10130',
  'Solution': 'customfield_10120',
  'Root Cause': 'customfield_10111',
  'fixVersion': 'fixVersions'
};

const DEFAULT_TRANSITION_RULES = {
  'Publish': ['Gerrit Id', 'Solution', 'Root Cause', 'fixVersion'],
  "Review Won't Fix": ['Solution', 'Root Cause'],
  'Review Invalid': ['Solution', 'Root Cause'],
  'Resolve': ['Solution', 'Root Cause', 'Gerrit Id']
};

function getFieldsMap(opts) {
  const map = (opts && opts.validationField && opts.validationField.fieldsMap) || DEFAULT_FIELDS_MAP;
  return new Map(Object.entries(map));
}

function getTransitionRules(opts) {
  return (opts && opts.validationField && opts.validationField.transitionRules) || DEFAULT_TRANSITION_RULES;
}

const Utils = {
	checkEnvironment() {
		// deactive console.logs in production
		if (chrome.i18n.getMessage('DEV_MODE') == 'false') {
			console.log = () => {};
			console.debug = () => {};
			console.error = () => {};
			console.info = () => {};
			console.warn = () => {};
			console.table = () => {};
			console.trace = () => {};
		} else {
			// document.getElementsByTagName('TITLE')[0].innerText = 'DEV Mode';
		}
	},
	getSyncStorage: async function (storageName) {
		async function getLocalStorageValue(key) {
			return new Promise((resolve, reject) => {
				try {
					chrome.storage.local.get(key, function (value) {
						resolve(value);
					});
				} catch (ex) {
					reject(ex);
				}
			});
		}

		let result = await getLocalStorageValue(storageName);
		return result;
	},
	createUpdateTemplate(data) {
		templates = templateCache.templates;

		if (data.doUpdate) {
			for (const key in templates) {
				if (Object.hasOwnProperty.call(templates, key)) {
					//if (isUpdated) return;
					if (data.uuid === templates[key].uuid) {
						templates[key].issueType = data.issueType;
						templates[key].projects = data.projects;
						templates[key].templateName = data.templateName;
						templates[key].ticketDesc = data.newTemplate;
					}
				}
			}
		} else {
			// create new template
			// 修复: quickAccessCommentButton 需与 HomePage.vue / default-templates.json 保持一致为 true，
			// 否则 getButtonsForComment 过滤条件 (issueType==='comment' || quickAccessCommentButton) 永远不命中，
			// 导致通过 JIRA 页面工具栏创建的模板在 comment 区不显示快速填充按钮。
			const newTemplate = {
				issueType: data.issueType,
				projects: data.projects,
				quickAccessButton: true,
				quickAccessCommentButton: true,
				quickAccessContextMenu: true,
				quickAccessDropdown: true,
				templateName: data.templateName,
				ticketDesc: data.newTemplate,
				uuid: data.uuid,
				isCloudTemplate: data.isCloudTemplate,
			};
			templates.push(newTemplate);
		}

		// Update Cache
		templateCache['templates'] = templates;

		// Save in sync storage
		chrome.storage.local.set({ templates: JSON.stringify(templates) }, function () {});
	},
};

const JiraInterface = {
	/**
	 * @returns value of description textarea either cloud or server
	 */
	getValueOfTemplateDescriptionField() {
		return isJiraCloud
			? document.getElementsByClassName('ak-editor-content-area')[0].children[1].innerHTML
			: document.getElementById('description').value;
	},
	setValueOfTemplateDescriptionField(value) {
		return isJiraCloud
			? (document.getElementsByClassName('ak-editor-content-area')[0].children[1].innerHTML = value)
			: (document.getElementById('description').value = value);
	},

	setCustomToolBar(chosenTemplate, selectedProject, selectedIssueType) {
		// do not create tool bar more than once
		if (document.querySelector('#customToolBar')) return;

		let headline = 'Ticket Templates for JIRA';
		if (chosenTemplate != '') {
			selectedIssueType = chosenTemplate.issueType;
			selectedProject = chosenTemplate.projects;
			templateName = chosenTemplate.templateName;
			uuid = chosenTemplate.uuid;

			createRadioBoxAttributes = 'style="display: block; cursor: pointer;"';
			updateRadioBoxAttributes = 'style="display: block; cursor: pointer;" checked="checked"';
		} else {
			templateName = `${selectedIssueType} (${selectedProject})`;

			createRadioBoxAttributes = 'style="display: block; cursor: pointer;" checked="checked"';
			updateRadioBoxAttributes = 'style="display: block; color: grey;" disabled="disabled"';
		}

		const $customToolBar = `<div id="customToolBar" style="display: flex;flex-direction: column;position:relative; gap: 1rem;padding: 1rem;border: 1px solid lightgray;border-radius: 5px;margin-top: 1rem;">
			<span style="position: absolute;top: -0.7rem;background-color: white;padding: 0 0.4rem;">
				<img src="" style="vertical-align: middle;"/>
				${headline}
			</span>

			<div class="input-group" style="display: flex;flex-wrap: wrap;">
				<form> 
					<input ${createRadioBoxAttributes} type="radio" id="saveMode" name="saveMode" value="createMode">
					<label ${createRadioBoxAttributes} for="saveMode">Create new template</label>
					<input ${updateRadioBoxAttributes} type="radio" id="updateMode" name="saveMode" value="updateMode" >
					<label ${updateRadioBoxAttributes} for="updateMode">Update this template</label>
				</form>
			</div>
			<div class="input-group" style="display: flex;flex-wrap: wrap;gap: 1rem;">
				<div style="display: flex;flex-direction: column;width: min-content;">
					<input type="text" id="selectedIssueType" value="${selectedIssueType}" onkeypress="this.style.width = ((this.value.length + 1) * 8) + 'px';">
					<label for="selectedIssueType"><small>Type</small></label>
				</div>

				<div style="display: flex;flex-direction: column;width: min-content;">
					<input type="text" id="selectedProjects" value="${selectedProject}" onkeypress="this.style.width = ((this.value.length + 1) * 8) + 'px';"/>
					<label for="selectedProjects"><small>Projects</small></label>
				</div>

				<div style="display: flex;flex-direction: column;width: min-content;">
					<input type="text" id="templateName" value="${templateName}" onkeypress="this.style.width = ((this.value.length + 1) * 8) + 'px';"/>
					<label for="templateName"><small>Template Name</small></label>
				</div>

				<button id="saveTemplate" title="save" style="height: 36px; cursor: pointer;display: flex;align-items: center;">
					<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><path d="M0 0h24v24H0z" fill="none"/><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>
				</button>
			</div>
			
			
			
			<span id="saving_success" style="display: none; align-items: center;position: absolute;bottom: -0.7rem;background-color: white;padding: 0 0.4rem;right: 0.7rem;">
				Template saved! <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#0BDA51"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
			</span>
			<span id="saving_failure" style="display: none; align-items: center;position: absolute;bottom: -0.7rem;background-color: white;padding: 0 0.4rem;right: 0.7rem;">
				Error occured! <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#FF5733"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"/></svg>
			</span>
		</div>`;

		const $containerForCustomToolBar = isJiraCloud
			? document.querySelector('div.akEditor')
			: document.querySelector('div#qf-field-description .save-options');

		const showNotification = (id) => {
			document.getElementById(id).style.display = 'flex';
			setTimeout(function () {
				document.getElementById(id).style.display = 'none';
			}, 5000);
		};

		// insert save / update formular
		$containerForCustomToolBar.insertAdjacentHTML('afterend', $customToolBar);

		// set image src
		chrome.runtime.sendMessage('getIcon', function (response) {
			document.querySelector('#customToolBar img').src = response;
			//selectList.style = `background-image: url(${response}); background-repeat: no-repeat;background-position: center;background-color: inherit;width: 16px;appearance: none;cursor: pointer;`;
		});

		// resize inputs
		const $inputA = document.getElementById('selectedIssueType');
		const $inputB = document.getElementById('selectedProjects');
		const $inputC = document.getElementById('templateName');
		$inputA.style.width = ($inputA.value.length + 1) * 8 + 'px';
		$inputB.style.width = ($inputB.value.length + 1) * 8 + 'px';
		$inputC.style.width = ($inputC.value.length + 1) * 8 + 'px';

		// trigger template update logic
		document.querySelector('#customToolBar #saveTemplate').addEventListener('click', async (e) => {
			try {
				e.preventDefault();
				if (!isJiraCloud) CurrentView.setTextMode(e.currentTarget);
				/* chrome.runtime.sendMessage({
					name: 'setNewTemplate',
					data: {
						newTemplate: this.getValueOfTemplateDescriptionField(),
						issueType: document.getElementById('selectedIssueType').value || '',
						projects: document.getElementById('selectedProjects').value || 'default',
						templateName: document.getElementById('templateName').value || '',
						uuid: uuid,
					},
				}); */
				const isUpdate = document.querySelector('#customToolBar input[name="saveMode"]:checked').value === 'updateMode' ? true : false;
				const data = {
					doUpdate: isUpdate,
					newTemplate: this.getValueOfTemplateDescriptionField(),
					issueType: document.getElementById('selectedIssueType').value || '全部类型',
					projects: document.getElementById('selectedProjects').value || '默认项目',
					templateName: document.getElementById('templateName').value || '',
					uuid: isUpdate ? uuid : String(Date.now().toString(32) + Math.random().toString(16)).replace(/\./g, ''),
					isCloudTemplate: isJiraCloud,
				};
				Utils.createUpdateTemplate(data);
				showNotification('saving_success');
			} catch (error) {
				console.error("contentScrpte: ", error);
				showNotification('saving_failure');
			}
		});
	},
};

const CurrentView = {
	insertDescription(selector, template, options) {
		if (insertTemplate) {
			if (isJiraCloud) return;

			const textBefore = selector.value;
			if (textBefore.length === 0 || !options.keeptext.enabled) {
				selector.value = template.contextMenu;
			} else {
				// preserve text in description
				selector.value = `${template.contextMenu}${NEW_LINE}${NEW_LINE}${options.keeptext.separator}${NEW_LINE}${NEW_LINE}${textBefore}`;
			}
			insertTemplate = false;
		}
	},
	insertDescriptionJiraCloud(selector, template, options) {
		const justPlaceholder = selector.querySelector('p > span[contenteditable="false"]');
		const textBefore = JiraInterface.getValueOfTemplateDescriptionField();

		// check if override or preserve
		// length == 1 if '\n' in cloud version basically empty
		if (justPlaceholder || !options.keeptext.enabled) {
			JiraInterface.setValueOfTemplateDescriptionField(template.contextMenu);
		} else if (CurrentView.isPlainTemplate(textBefore, templateCache.templates)) {
			JiraInterface.setValueOfTemplateDescriptionField(template.contextMenu);
		} else {
			// preserve text in description
			let newText = `${template.contextMenu}${NEW_LINE}${NEW_LINE}${options.keeptext.separator}${NEW_LINE}${NEW_LINE}${textBefore}`;
			JiraInterface.setValueOfTemplateDescriptionField(newText);
		}
	},
	isPlainTemplate(text, templates) {
		let result = false;
		for (const key in templates) {
			if (Object.hasOwnProperty.call(templates, key)) {
				// if text is written for server version and injected in cloud it became wrapped in <p>
				let text2 = text.replace(/[^a-zA-Z]/g, '');
				let knownTemplate = templates[key].ticketDesc.replace(/[^a-zA-Z]/g, '');
				if (text === templates[key].ticketDesc || text2 === `p${knownTemplate}p`) {
					result = true;
				}
			}
		}
		return result;
	},
	enableButtonSaveComment() {
		try {
			let saveBtn = document.getElementById('issue-comment-add-submit') || document.getElementById('comment-edit-submit');
			saveBtn.removeAttribute('disabled');
		} catch (error) {
			console.error("contentScrpte: ", error);
		}
	},
	// make sure text mode is active
	setTextMode(activeElement) {
		try {
			// find correct link in case of more than one data-mode links
			activeElement.closest('.field-group').querySelector('[data-mode=source] a, [data-mode=source] button').click();
		} catch (error) {
			// in cloud version is no edit button
			console.error("contentScrpte: ", error);
			try {
				document.querySelector('[data-mode=source] a, [data-mode=source] button').click();
			} catch (error) {
				console.error("contentScrpte: ", error);
			}
		}
	},
	// 检测当前编辑器是否处于 Visual 模式（写值前调用，避免 setTextMode 切走 source 后误判）。
	// Jira AUI wiki 编辑器的实际 DOM：
	//   <li class="menu-item active-tab" data-mode="wysiwyg"><a aria-selected="true">可视化</a></li>
	//   <li class="menu-item"             data-mode="source"><a aria-selected="false">文本</a></li>
	// 即：Visual=wyg  mode=wysiwyg，Text=source；激活态为 <li> 上的 .active-tab（也对应 <a> aria-selected="true"）。
	// 判定逻辑：source tab 处于激活态（.active-tab 或其 <a> aria-selected="true"）→ 当前是 Source → 非 Visual；
	// 无 source tab → 不支持切换，无需切回；其余/失败默认 Visual（Jira 默认即 Visual）。
	detectIsVisual(fieldGroup) {
		try {
			const fg = fieldGroup || document;
			const sourceTab = fg.querySelector('[data-mode=source]');
			if (!sourceTab) return false;
			const sourceActive = sourceTab.classList.contains('active-tab') ||
				!!sourceTab.querySelector('a[aria-selected="true"]');
			return !sourceActive;
		} catch (error) {
			console.warn("contentScrpte: detectIsVisual failed, default to visual", error);
			return true;
		}
	},
	// 切回 Visual（wysiwyg）模式。与 setTextMode 对称，点击 wysiwyg tab 内的 <a>。
	// 找不到或失败时静默兜底，不影响已写入的模板内容与保存按钮启用。
	setVisualMode(activeElement) {
		try {
			activeElement.closest('.field-group').querySelector('[data-mode=wysiwyg] a, [data-mode=wysiwyg] button').click();
		} catch (error) {
			console.warn("contentScrpte: setVisualMode failed", error);
			try {
				document.querySelector('[data-mode=wysiwyg] a, [data-mode=wysiwyg] button').click();
			} catch (error) {
				console.warn("contentScrpte: setVisualMode fallback failed", error);
			}
		}
	},
};

// deactive dev outputs if productive
Utils.checkEnvironment();

// insert template after click in context menu
chrome.runtime.onMessage.addListener(function onMsg(message, _sender, sendResponse) {
	chrome.runtime.sendMessage('getOptions', function getMsg(options) {
		// handle context menu click
		if (message.contextMenu && message.contextMenu !== 'donate_link') {
			if (!jsaRequireAuth()) { sendResponse({ message: 'unauthorized' }); return; }
			UsageReporter.report('template_apply', { source: 'context_menu', templateName: message.contextMenu.substring(0, 50) });
			if (!isJiraCloud) {
				const isTextField = this.document.activeElement.type === ('textarea' || 'input');
				if (!isTextField) {
					// make sure text mode is active
					CurrentView.setTextMode(this.document.activeElement);
				}
				setTimeout(
					() => {
						CurrentView.insertDescription(this.document.activeElement, message, options);
						CurrentView.enableButtonSaveComment();
					},
					isTextField ? 0 : 500
				);
			} else {
				CurrentView.insertDescriptionJiraCloud(this.document.activeElement, message, options);
			}

			sendResponse({ message: 'done' });
		} else if (message.contextMenu && message.contextMenu === 'donate_link') {
			chrome.runtime.sendMessage('getSupportersPage', function getSupportersPage() {});
		}
	});
});

// ====== XML Export 数据获取层（用于字段校验）======
// 动态推导 JIRA 基础 URL，不再硬编码

function _getJiraBaseUrl() {
	return window.location.origin + (window.location.pathname.match(/^\/[^/]+/) || [''])[0].replace(/\/browse.*/, '').replace(/\/secure.*/, '').replace(/\/issues.*/, '');
}

function _decodeEntities(str) {
	if (!str || typeof str !== 'string') return str;
	if (!str.includes('&')) return str;
	const el = document.createElement('textarea');
	el.innerHTML = str;
	return el.value;
}

function _parseXmlDate(dateStr) {
	if (!dateStr) return '';
	try { return new Date(dateStr).toISOString(); }
	catch { return dateStr; }
}

function _buildXmlExportUrl(jql, fields, tempMax, startAt) {
	const base = _getJiraBaseUrl();
	let url = `${base}/sr/jira.issueviews:searchrequest-xml/temp/SearchRequest.xml?jqlQuery=${encodeURIComponent(jql)}&tempMax=${tempMax}`;
	if (startAt > 0) url += `&pager/start=${startAt}`;
	if (fields && fields.length > 0) {
		fields.forEach(f => { url += `&field=${encodeURIComponent(f)}`; });
	}
	return url;
}

function _parseXmlToIssues(xmlText) {
	const parser = new DOMParser();
	const doc = parser.parseFromString(xmlText, 'text/xml');
	const issueEl = doc.querySelector('issue');
	const total = issueEl ? parseInt(issueEl.getAttribute('total'), 10) || 0 : 0;

	const items = doc.querySelectorAll('item');
	const issues = [];

	items.forEach(item => {
		const keyEl = item.querySelector('key');
		const key = keyEl?.textContent || '';
		const id = keyEl?.getAttribute('id') || '';

		const assigneeEl = item.querySelector('assignee');
		const resolutionEl = item.querySelector('resolution');
		const statusEl = item.querySelector('status');

		const fixVersionEls = item.querySelectorAll('fixVersion');
		const fixVersions = Array.from(fixVersionEls).map(fv => ({ name: _decodeEntities(fv.textContent || '') }));

		const customFieldMap = {};
		item.querySelectorAll('customfield').forEach(cf => {
			const cfId = cf.getAttribute('id');
			const vals = cf.querySelectorAll('customfieldvalue');
			if (vals.length === 1) customFieldMap[cfId] = _decodeEntities(vals[0].textContent || '');
			else if (vals.length > 1) customFieldMap[cfId] = Array.from(vals).map(v => _decodeEntities(v.textContent || ''));
			else customFieldMap[cfId] = null;
		});

		const fields = {
			summary: _decodeEntities(item.querySelector('summary')?.textContent || ''),
			assignee: assigneeEl ? { displayName: _decodeEntities(assigneeEl.textContent || ''), name: assigneeEl.getAttribute('username') || '' } : null,
			resolution: resolutionEl ? { name: _decodeEntities(resolutionEl.textContent || ''), id: resolutionEl.getAttribute('id') || '' } : null,
			status: statusEl ? { name: _decodeEntities(statusEl.textContent || ''), id: statusEl.getAttribute('id') || '' } : null,
			updated: _parseXmlDate(item.querySelector('updated')?.textContent || ''),
			fixVersions
		};
		Object.keys(customFieldMap).forEach(k => { fields[k] = customFieldMap[k]; });

		issues.push({ id, key, fields });
	});

	return { issues, total };
}

// QA审计功能已迁移至 Options Page (Vue SPA)
// 请通过扩展管理页面的"QA审计"模块使用

// [DELETED: QA审计IIFE代码块已删除，约1000行]
// 原包含: QA_AUDIT_SQLS, AUDIT_COLUMN_CONFIGS, buildQASQL, fetchAuditIssuesPage,
// fetchAllAuditIssues, enrichIssuesWithExtraData, showPreviewDialog, injectQAAuditUI 等
// 已迁移至: src/services/audit-engine.js, src/services/jira-api.js,
//           src/components/qa-audit/*.vue

// PLACEHOLDER_QA_AUDIT_DELETED


// execute scripts only if domains whitelisted
chrome.runtime.sendMessage('getDomains', async function getDomains(customDomains) {
	const domains = customDomains.replaceAll(',', '|');
	const pattern = new RegExp(domains);
	if (!pattern.test(window.location.href)) {
		console.log('contentScrpte: Current location does not contain a valid domain!');
		console.log(`contentScrpte: Given domains: ${domains}`);
	} else {
		// funktoinal aber möglicherweise fehler verursachend, bei speichern lieber hier auch updaten
		/* async function getLocalStorageValue(key) {
			return new Promise((resolve, reject) => {
				try {
					chrome.storage.local.get(key, function (value) {
						resolve(value);
					});
				} catch (ex) {
					reject(ex);
				}
			});
		}

		const result = await getLocalStorageValue('templates');
		console.log(result); */

		chrome.runtime.sendMessage('getOptions', function getOptions(data1) {
			chrome.runtime.sendMessage('getTemplates', async function getTemplates(data2) {
				console.log('shugan templates: enter -----');

				// 在页面加载完成后调用获取状态值的函数
				if (document.readyState === 'loading') {
					document.addEventListener('DOMContentLoaded', function() {
						setTimeout(getStatusValue, 100);
					});
				} else {
					setTimeout(getStatusValue, 100);
				}

				// set dom observer
				const observer = new MutationObserver((mutations) => {
					console.log("shugan 111 子view发生变化");
				// 检查是否满足Publish的条件
				interceptActionButton71();
				// 检查新增状态切换按钮的字段校验
				interceptNewStatusTransitions();
				mutations.forEach(observeDocumentBody);
				});
				observer.observe(document.body, {
				subtree: true,
				attributes: true,
				attributeFilter: ['resolved', 'contenteditable'],
				childList: true,
			});

			// 修复: 初始扫描已有 wiki-edit-toolbar（进入已有 Jira 单的 Comment 区时,工具栏可能在 observer 启动前就已存在）
			setTimeout(() => {
				const existingToolbars = document.querySelectorAll('.wiki-edit-toolbar:not(#issueDropdownMenu)');
				if (existingToolbars.length > 0) {
					const fakeMutation = { type: 'childList', target: document.body, addedNodes: [], attributeName: null };
					observeDocumentBody(fakeMutation);
				}
			}, 1500);

				const options = data1;
				templateCache = await cachedTemplates();
				let templates = templateCache.templates;
				// options.validationField 现为布尔型总开关（true=开启所有字段校验）
				// function validateHTML(htmlString) {
				// 	let parser = new DOMParser();
				// 	let doc = parser.parseFromString(htmlString, 'application/xml');
				// 	let errorNode = doc.querySelector('parsererror');
				// 	if (errorNode) {
				// 		console.log("contentScrpte: ", errorNode);
				// 	} else {
				// 		console.log('contentScrpte: , Valid HTML!');
				// 	}
				// }
				// templates.forEach((template) => {
				// 	validateHTML(template.ticketDesc);
				// });

				/**
				 * helper functions
				 */

				function applyTemplate() {
					if (!jsaRequireAuth()) return;
					const currentEditForm = this.closest('.field-group');
					// 写值前先记录原模式（setTextMode 会切到 Source，必须在切换前检测）
					const isVisual = CurrentView.detectIsVisual(currentEditForm);
					CurrentView.setTextMode(currentEditForm);

					const textfield = currentEditForm.querySelector(TEXTFIELD_IDS);
					let template;
					let templateType;
					let uiType;

					let templateNameForReport = '';

					if (this.getAttribute('insertdata')) {
						// user clicked on button
						uiType = 'button';
						template = this.getAttribute('insertdata');
						templateType = this.getAttribute('templateType').toLowerCase();
						templateNameForReport = this.innerText;
					} else {
						// user selected item on dropdown
						uiType = 'dropdown';
						template = this.options[this.selectedIndex].value;
						templateType = this.options[this.selectedIndex].templateType.toLowerCase();
						templateNameForReport = this.options[this.selectedIndex].text;
					}

					const isDescription = textfield && textfield.id === 'description';
					UsageReporter.report('template_apply', {
						source: `${isDescription ? 'description' : 'comment'}_${uiType}`,
						templateName: templateNameForReport
					});

					// insert template if textarea is empty
					const textBefore = textfield.value;
					if (textBefore.length === 0 || !options.keeptext.enabled) {
						textfield.value = template;
					} else {
						// exchange template if textarea contains only plain template
						if (CurrentView.isPlainTemplate(textBefore, templates)) {
							textfield.value = template;
							// append template if textarea already contains text not plain template
						} else {
							textfield.value = `${template}${NEW_LINE}${NEW_LINE}${options.keeptext.separator}${NEW_LINE}${NEW_LINE}${textBefore}`;
						}
					}

					// 派发 input 事件，确保 Atlassian wiki 编辑器感知到 textarea 内容变化，
					// 使后续切回 Visual 时内容能正确重渲染（与 1748/2542 行已验证的写入模式对齐）
					try {
						textfield.dispatchEvent(new Event('input', { bubbles: true }));
					} catch (e) { /* 派发失败不影响已写入的内容 */ }

					// 原为 Visual 模式则切回，让 wiki 标记重渲染为富文本；原为 Source 则保持。
					// setVisualMode 内部 try/catch 兜底，失败时静默停在 Source，不抛错。
					if (isVisual) CurrentView.setVisualMode(currentEditForm);

					CurrentView.enableButtonSaveComment();
				}

				function createDropdown(templates, showInProject) {
					// create select
					const selectList = document.createElement('select');
					selectList.id = 'issueDropdownMenu';
					// 注意: 不使用 aui-dropdown2-trigger 类,该类要求元素配对 AUI dropdown2
				// 弹出层(需 aria-owns/aria-controls 属性)。我们用原生 <select> + onchange,
				// 无需 AUI 弹出层,移除该类可消除 AUI 的 "Dropdown triggers need either
				// a 'aria-owns' or 'aria-controls' attribute" 警告,避免 AUI 对原生
				// select 的潜在干扰。视觉样式由 aui-button + wiki-edit-style-picker-trigger 提供。
				selectList.className =
					'aui-button aui-button-subtle wiki-edit-operation-dropdown wiki-edit-style-picker-trigger';
					selectList.title = TITLE_DROPDOWN_ICON;
					chrome.runtime.sendMessage('getIcon', function (response) {
						selectList.style = `background-image: url(${response}); background-repeat: no-repeat;background-position: center;background-color: inherit;width: 16px;appearance: none;cursor: pointer;`;
					});
					selectList.onchange = applyTemplate;

					// create options
					for (const key in templates) {
						if (templates[key].projects.toLowerCase().includes(DEFAULT_TEMPLATE_ID) || templates[key].projects.includes(showInProject)) {
							var option = document.createElement('option');
							option.value = templates[key].ticketDesc;
							option.templateType = templates[key].issueType;
							option.text = templates[key].templateName;
							selectList.appendChild(option);
						}
					}

					// create default option
					var option = document.createElement('option');
					option.className = 'issueDropdownMenuOptions';
					option.value = '';
					option.text = TITLE_DROPDOWN_ICON;
					option.selected = 'true';
					option.disabled = 'true';
					option.hidden = 'true';
					selectList.appendChild(option);

					return selectList;
				}

				function createButtons(templates, showInProject) {
					// create buttoncontainer
					const container = document.createElement('div');
					container.id = 'buttonContainer';
					container.className = 'aui-buttons';
					container.style = 'padding-left: 0px;margin-left: 0px;border-left: 0;white-space: break-spaces;display: inline-block;';

					// create buttons
					for (const key in templates) {
						const canBeApplied = templates[key].isCloudTemplate === isJiraCloud;
						if (
							(canBeApplied && templates[key].projects.toLowerCase().includes(DEFAULT_TEMPLATE_ID)) ||
							templates[key].projects.includes(showInProject)
						) {
							const button = document.createElement('a');
							button.className = 'aui-button aui-button-subtle';
							button.innerText = templates[key].templateName;
							button.setAttribute('templateType', templates[key].issueType);
							button.setAttribute('insertdata', templates[key].ticketDesc);
							button.onclick = applyTemplate;
							container.appendChild(button);
						}
					}

					return container;
				}

				// search for projectspecific template
				async function getTemplate(templates, projects, issueType) {
					let specifcTemplate;
					let defaultTemplate;
					projects = projects.toUpperCase();
					issueType = issueType.toLowerCase();

					for (const key in templates) {
						if (Object.hasOwnProperty.call(templates, key)) {
							const isForIssueType = templates[key].issueType.toLowerCase();
							const isSpecific = templates[key].projects.includes(projects);
							const isDefault = templates[key].projects.toLowerCase().includes(DEFAULT_TEMPLATE_ID);
							const canBeApplied = templates[key].isCloudTemplate === isJiraCloud;

							if (isForIssueType == issueType && isSpecific && canBeApplied) {
								// specific if issueType e.g. "Bug" and project e.g. "ABC"
								specifcTemplate = templates[key];
							} else if (!specifcTemplate && isForIssueType == issueType && isDefault && canBeApplied) {
								// default if  issueType e.g. "Bug" and project "default"
								defaultTemplate = templates[key];
							}
						}
					}
					// return specific, default or no template
					return typeof specifcTemplate !== 'undefined' ? specifcTemplate : typeof defaultTemplate !== 'undefined' ? defaultTemplate : '';
				}

				/**
				 * executives
				 */
				function observeDocumentBody(mutation) {
				// console.info("contentScrpte: ", mutation.target.getAttribute('aria-label'));
				// console.log("observeDocumentBody: contentScrpte: ", mutation.target);
				// console.log("shugan: contentScrpte: ", mutation.target);

				// 如果mutation.target就是包含fixVersions-field的元素
				// const fixVersionLink = mutation.target.querySelector('a[href*="fixVersion"]');
				// if (fixVersionLink) {
				// 	const fixVersion = fixVersionLink.textContent.trim();
				// 	console.log("shugan 提取到的fixVersion:", fixVersion);
				// }
				const isDescriptionField =
					['description'].includes(mutation.target.id) ||
					(mutation.target.getAttribute('contenteditable') && mutation.target.closest('#description-container'));
					let prj = '';
					let selectedIssueType = '';
					let chosenTemplate = '';

					// get selected parameters

					// no project-field available, probably just clicked edit at current issue
					if (isDescriptionField) {
						setTimeout(async () => {
							if (!isJiraCloud) {
								prj = document.getElementById('project-field') ? document.getElementById('project-field').value : '';
								selectedIssueType =
									document.getElementById('issuetype-field').value ||
									document.querySelector('[data-issue-type]').getAttribute('data-issue-type');
							} else {
								prj = document.getElementById('issue-create.ui.modal.create-form.project-picker.project-select').textContent || '';
								selectedIssueType =
									document.getElementById('issue-create.ui.modal.create-form.type-picker.issue-type-select').textContent || '';
							}

							selectedProject = prj.substring(prj.lastIndexOf('(') + 1, prj.length - 1);
							chosenTemplate = await getTemplate(templates, selectedProject, selectedIssueType);

							JiraInterface.setCustomToolBar(chosenTemplate, selectedProject, selectedIssueType);
						}, 200);
					}

					// observe for autofill
					if (options.autofill.enabled) {
						if (isDescriptionField) {
							setTimeout(() => {
								if (!jsaRequireAuth({ silent: true })) return;
								// autofill template only if textarea is empty or just another template
								let textBefore = '';
								if (!isJiraCloud && chosenTemplate !== '') {
									textBefore = mutation.target.value;
									if (textBefore.length === 0) {
										mutation.target.value = chosenTemplate.ticketDesc;
										// exchange template if textarea contains only plain template
									} else if (CurrentView.isPlainTemplate(textBefore, templates)) {
										mutation.target.value = templateticketDesc;
										// no autofill if something else is given in description
									} else {
									}
								} else if (chosenTemplate !== '') {
									const justPlaceholder = mutation.target.querySelector('p > span[contenteditable="false"]');
									textBefore = JiraInterface.getValueOfTemplateDescriptionField();

									// check if override or preserve
									// length == 1 if '\n' in cloud version basically empty
									if (justPlaceholder || !options.keeptext.enabled) {
										JiraInterface.setValueOfTemplateDescriptionField(chosenTemplate.ticketDesc);
									} else if (CurrentView.isPlainTemplate(textBefore, templates)) {
										JiraInterface.setValueOfTemplateDescriptionField(chosenTemplate.ticketDesc);
									} else {
										// preserve text in description
										let newText = `${chosenTemplate.ticketDesc}${NEW_LINE}${NEW_LINE}${options.keeptext.separator}${NEW_LINE}${NEW_LINE}${textBefore}`;
										JiraInterface.setValueOfTemplateDescriptionField(newText);
									}
								} else {
									// template was set, change ticket type -> jira reminds the template
									// remove template if theres is no template for ticket type
									if (CurrentView.isPlainTemplate(JiraInterface.getValueOfTemplateDescriptionField(), templates))
										JiraInterface.setValueOfTemplateDescriptionField('');
								}

								// mutation.target.focus();
								// mutation.target.scrollIntoView(false);
							}, 300);
						}
					}

					// observe for dropdown
				if (options.quickaccess.enabled) {
					// 修复: childList mutation 时,检查新增节点是否含 wiki-edit-toolbar 或 #comment;
					// attributes mutation 时,也检查 mutation.target.closest('#comment') 以覆盖
					// contenteditable 变化在 comment 内部子元素上触发、但 target.id 不等于 'comment' 的场景
					const isCommentMutation =
						['comment'].includes(mutation.target.id) ||
						(mutation.type === 'childList' && (
							mutation.target.querySelector?.('.wiki-edit-toolbar') ||
							mutation.target.id === 'comment' ||
							[...mutation.addedNodes].some(n => n instanceof HTMLElement && (n.querySelector?.('.wiki-edit-toolbar') || n.id === 'comment'))
						)) ||
						(mutation.type === 'attributes' && mutation.target.closest?.('#comment'));
					if (
						['wiki-editor-initialised', 'textfield', 'wiki-edit-operation'].includes(mutation.target.className) ||
						isCommentMutation ||
						isDescriptionField
					) {
							const toolbars = document.querySelectorAll('.wiki-edit-toolbar:not(#issueDropdownMenu)');
							if (toolbars) {
								let currentProject;
							try {
								const targetId = mutation.target.id;
								currentProject = (targetId && document.querySelector(`textarea#${targetId}`)) || document.querySelector('textarea');
								currentProject = currentProject?.getAttribute('data-projectkey');
							} catch (error) {
								console.warn(`contentScrpte: Could not find currentProject in this view: ${window.location.href}`);
							}

								// render dropdown either target is description or comment
								// 兜底: Jira wiki editor 在某些场景(如 Chrome 版 Comment 编辑器)初始化时
								// `_overrideWikiFallbackOperations` 会抛 "Operation not supported: clear-format"
								// (Atlassian 自身行为),导致工具栏结构不完整, .aui-buttons:nth-last-child(2)
								// 可能不存在。原代码在 null 上调用 appendChild 会抛 TypeError,静默中断整个
								// dropdown 注入回调,使模板下拉菜单永不显示。
								chrome.runtime.sendMessage('getEntriesForDropdown', function (entries) {
									if (entries.length > 0) {
										for (let index = 0; index < toolbars.length; index++) {
											if (toolbars[index].querySelector('#issueDropdownMenu') === null) {
												try {
													// append as second last,失败时回退到 toolbar 自身
													const host =
														toolbars[index].querySelector('.wiki-edit-toolbar .aui-buttons:nth-last-child(2)') ||
														toolbars[index].querySelector('.aui-buttons') ||
														toolbars[index];
													host.appendChild(createDropdown(entries, currentProject));
												} catch (e) {
													console.warn('contentScrpte: dropdown 注入失败', e);
												}
											}
										}
									}
								});

								if (isDescriptionField) {
									// buttons for description wysiwyg editor
									chrome.runtime.sendMessage('getButtonsForDescription', function getBtnDesc(buttons) {
										if (buttons.length > 0) {
											for (let index = 0; index < toolbars.length; index += 1) {
												if (toolbars[index].querySelector('#buttonContainer') === null) {
													try {
														// append in the end,失败时回退到 toolbar 自身
														const lastBtn = toolbars[index].querySelector('.wiki-edit-toolbar-last');
														const host = (lastBtn && lastBtn.parentNode) || toolbars[index];
														host.appendChild(createButtons(buttons, currentProject));
													} catch (e) {
														console.warn('contentScrpte: description buttons 注入失败', e);
													}
												}
											}
										}
									});
								} else {
									console.log("shugan 3333333333");
									// buttons for comment wysiwyg editor
									chrome.runtime.sendMessage('getButtonsForComment', function getBtnComment(buttons) {
										if (buttons.length > 0) {
											for (let index = 0; index < toolbars.length; index += 1) {
												if (toolbars[index].querySelector('#buttonContainer') === null) {
													try {
														// append in the end,失败时回退到 toolbar 自身
														const lastBtn = toolbars[index].querySelector('.wiki-edit-toolbar-last');
														const host = (lastBtn && lastBtn.parentNode) || toolbars[index];
														host.appendChild(createButtons(buttons, currentProject));
													} catch (e) {
														console.warn('contentScrpte: comment buttons 注入失败', e);
													}
												}
											}
										}
									});
								}

							}
						}
					}
				}

				function isEmpty(value) {
					// 检查未定义或 null
					if (value === undefined || value === null) {
						return true;
					}
					
					// 检查字符串
					if (typeof value === 'string') {
						return value.trim() === '';
					}
					
					// 检查数组
					if (Array.isArray(value)) {
						return value.length === 0;
					}
					
					// 检查 Map 和 Set
					if (value instanceof Map || value instanceof Set) {
						return value.size === 0;
					}
					
					// 检查对象
					if (typeof value === 'object') {
						return Object.keys(value).length === 0;
					}
					
					// 其他类型（数字、布尔值等）通常不为空
					return false;
				}

				async function fetchJiraData(key) {
					try {
						const url = _buildXmlExportUrl(`key = ${key}`, null, 1, 0);
						const response = await fetch(url, { credentials: 'same-origin' });
						if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
						const xmlText = await response.text();
						return _parseXmlToIssues(xmlText);
					} catch (error) {
						console.error('contentScript: 请求JIRA数据失败:', error);
						throw error;
					}
				}

				function getKeyNumber() {
					const keyElement = document.getElementById('key-val');
					let keyText = '';
					if (keyElement) {
						keyText = (keyElement.textContent || keyElement.innerText).trim();
					}
					return keyText;
				}

				function getResolution() {
					// 获取状态: status-val元素
					const statusElement = document.getElementById('status-val');
					if (statusElement) {
						const statusText = statusElement.textContent || statusElement.innerText;
						if (statusText.trim() === '已解决') {
							return true;
						}
					}
					return false;
				}

			// ===== AI 分析评价门禁 =====
			// 在指定状态流转提交前对"最近一条已回传的 AI 分析"采集评价(3档必选+可选文字),
			// 回传 JIRABugAnalyzer2 用于提升分析能力。仅当存在已回传分析时启用。
			// 触发流转:Publish(单子闭环前最后一道流程),以及 Review Won't Fix / Review Invalid
			// (Won't Fix / Invalid 类单子不走 Publish,在进入 Review Won't Fix / Review Invalid 时即采集评价,
			//  否则这类单子永远不会被采集到)。
			const EVAL_RATINGS = [
				{ value: 'no_help', label: '没有帮助' },
				{ value: 'some_help', label: '有些帮助', hint: '有些说到点上，对梳理代码有帮助' },
				{ value: 'fully_correct', label: '完全正确', hint: '根因正确' },
			];

			// 需要触发 AI 分析评价门禁的流转名(与按钮文本 / transitionName 一致)
			const EVAL_GATED_TRANSITIONS = ['Publish', "Review Won't Fix", 'Review Invalid'];

			// 查询某 issue 是否有可评的已回传分析(经 background 调 ext 端点)
			// 返回 {exists, task_id} 或 {exists:false}(含端点不可达兜底)
			function getEvaluationTarget(issueKey) {
				return new Promise(function (resolve) {
					try {
						chrome.runtime.sendMessage(
							{ type: 'EVALUATION_POSTED', jira_key: issueKey },
							function (resp) {
								if (chrome.runtime.lastError || !resp || resp.ok !== true) {
									resolve({ exists: false });
									return;
								}
								const d = resp.data || {};
								resolve({ exists: !!d.exists, task_id: d.task_id || '' });
							}
						);
					} catch (e) {
						resolve({ exists: false });
					}
				});
			}

			// 回传评价到 JIRABugAnalyzer2;失败仅告警,不阻断用户提交
			function submitEvaluation(payload) {
				try {
					chrome.runtime.sendMessage(
						{ type: 'EVALUATION_SUBMIT', payload: payload },
						function (resp) {
							if (chrome.runtime.lastError || !resp || resp.ok !== true) {
								console.warn('shugan 评价回传失败(已放行提交):', resp && resp.error);
								return;
							}
							console.log('shugan 评价已回传:', resp.data);
						}
					);
				} catch (e) {
					console.warn('shugan 评价回传异常(已放行提交):', e);
				}
			}

			// 获取当前 JIRA 用户名(用于评价标识);取不到返回空串
			function getJiraUsername() {
				try {
					const el = document.querySelector('#header-details-user-fullname, .aui-avatar-inner-text, [data-username]');
					if (el) {
						return (el.getAttribute('data-username') || el.textContent || '').trim();
					}
					const meta = document.querySelector('meta[name="ajs-remote-user"]');
					if (meta) return (meta.getAttribute('content') || '').trim();
				} catch (e) {}
				return '';
			}

			// ===== 同账号流转身份校验 =====
			// 业务约束:开发切到 Review Won't Fix / Review Invalid 后,应由上级/PL 切到 Won't do / Invalid,
			// 不允许同一 JIRA 账号"自己搁置、自己闭环"。身份比对统一到账号 key 维度
			// (当前用户 myself.name / DOM data-username,前次流转 actor 取 changelog histories[].author.name)。
			// 取数失败时 fail-open 放行,不阻断流转。
			const DEFAULT_SAME_ACTOR_GUARD = {
				enabled: true,
				blockedTransitions: ["Won't do", 'Invalid']
			};

			// 读取同账号拦截配置;缺失字段时回退默认值(enabled 默认开)。
			function getSameActorGuard(opts) {
				const g = (opts && opts.sameActorGuard) || {};
				return {
					enabled: g.enabled !== false,
					blockedTransitions: (g.blockedTransitions && g.blockedTransitions.length)
						? g.blockedTransitions
						: DEFAULT_SAME_ACTOR_GUARD.blockedTransitions
				};
			}

			// 取当前登录用户账号 key(JIRA Server 下 .name 即用户名 key);REST 失败回退 DOM data-username;再失败返回 null。
			async function fetchMyself() {
				try {
					const base = _getJiraBaseUrl();
					const resp = await fetch(`${base}/rest/api/2/myself`, { credentials: 'same-origin' });
					if (!resp.ok) throw new Error(`myself HTTP ${resp.status}`);
					const data = await resp.json();
					if (data && data.name) return String(data.name).trim();
				} catch (e) {
					console.warn('shugan 同账号校验: 取 myself 失败,回退 DOM', e);
				}
				const domUser = getJiraUsername();
				return domUser ? String(domUser).trim() : null;
			}

			// 取 issue 的 changelog histories;失败返回 null。
			async function fetchIssueChangelog(key) {
				try {
					const base = _getJiraBaseUrl();
					const resp = await fetch(`${base}/rest/api/2/issue/${encodeURIComponent(key)}?expand=changelog`, { credentials: 'same-origin' });
					if (!resp.ok) throw new Error(`changelog HTTP ${resp.status}`);
					const data = await resp.json();
					return (data && data.changelog && data.changelog.histories) ? data.changelog.histories : null;
				} catch (e) {
					console.warn('shugan 同账号校验: 取 changelog 失败', e);
					return null;
				}
			}

			// 从 histories(按 created 升序)尾向前找最近一条其 status 项 toString(trim) 等于 targetStatus 的 history,
			// 返回该 history 的 author.name(账号 key);找不到返回 null。
			function findLastTransitionActor(histories, targetStatus) {
				if (!histories || !histories.length || !targetStatus) return null;
				const target = String(targetStatus).trim();
				for (let i = histories.length - 1; i >= 0; i--) {
					const h = histories[i] || {};
					const items = h.items || [];
					for (let j = 0; j < items.length; j++) {
						const it = items[j] || {};
						if (it.field === 'status' && String(it.toString || '').trim() === target) {
							return (h.author && h.author.name) ? String(h.author.name).trim() : null;
						}
					}
				}
				return null;
			}

			// 弹出 AI 分析评价弹窗(独立 modal,覆盖在 JIRA 流转对话框之上)。
			// 返回 Promise:用户点「确认」且选了 rating → resolve({rating, comment});
			//              用户取消/关闭/未选确认 → resolve(null)(留在流转对话框,不放行提交)。
			function showEvaluationDialog() {
				return new Promise(function (resolve) {
					const styleId = 'vd-eval-dialog-styles';
					if (!document.getElementById(styleId)) {
						const s = document.createElement('style');
						s.id = styleId;
						s.textContent = `
							@keyframes vdEvalFadeIn { from { opacity: 0; } to { opacity: 1; } }
							@keyframes vdEvalSlideUp { from { opacity: 0; transform: translate(-50%, -48%); } to { opacity: 1; transform: translate(-50%, -50%); } }
							.vd-eval-overlay { position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:2147483000;animation:vdEvalFadeIn .2s ease }
							.vd-eval-modal { position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.25),0 0 0 1px rgba(0,0,0,.06);z-index:2147483001;width:460px;max-width:92vw;max-height:90vh;overflow:auto;animation:vdEvalSlideUp .3s ease;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif }
							.vd-eval-head { padding:20px 24px 0;display:flex;align-items:center;gap:10px }
							.vd-eval-icon { width:36px;height:36px;border-radius:9px;background:linear-gradient(135deg,#FEF3C7,#FDE68A);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:20px }
							.vd-eval-title { font-size:16px;font-weight:600;color:#1F2937;line-height:1.3 }
							.vd-eval-body { padding:14px 24px 0 }
							.vd-eval-desc { font-size:13px;color:#6B778C;margin:0 0 12px }
							.vd-eval-options { display:flex;flex-direction:column;gap:10px;margin-bottom:14px }
							.vd-eval-opt { display:flex;align-items:flex-start;gap:10px;cursor:pointer;font-size:14px;color:#374151;padding:8px 10px;border:1px solid #E5E7EB;border-radius:8px;transition:all .12s ease }
							.vd-eval-opt:hover { border-color:#3B82F6;background:#EFF6FF }
							.vd-eval-opt input { margin-top:3px;accent-color:#3B82F6 }
							.vd-eval-opt-text { display:flex;flex-direction:column }
							.vd-eval-opt-hint { font-size:12px;color:#9CA3AF;margin-top:2px }
							.vd-eval-opt:has(input:checked) { border-color:#3B82F6;background:#EFF6FF }
							.vd-eval-comment-label { font-size:12px;color:#6B778C;margin:0 0 4px }
							.vd-eval-comment { width:100%;min-height:56px;padding:8px 10px;border:1px solid #DFE1E6;border-radius:8px;font-size:13px;resize:vertical;box-sizing:border-box;font-family:inherit }
							.vd-eval-comment:focus { outline:none;border-color:#3B82F6 }
							.vd-eval-warn { font-size:12px;color:#EF4444;margin:8px 0 0;height:16px }
							.vd-eval-foot { padding:16px 24px 20px;display:flex;justify-content:flex-end;gap:10px;margin-top:8px }
							.vd-eval-btn { padding:8px 20px;border-radius:8px;font-size:14px;font-weight:500;cursor:pointer;transition:all .15s ease;border:none;outline:none }
							.vd-eval-btn:active { transform:scale(.97) }
							.vd-eval-btn-cancel { background:#F3F4F6;color:#374151 }
							.vd-eval-btn-cancel:hover { background:#E5E7EB }
							.vd-eval-btn-primary { background:linear-gradient(135deg,#3B82F6,#2563EB);color:#fff;box-shadow:0 1px 3px rgba(37,99,235,.3) }
							.vd-eval-btn-primary:hover { background:linear-gradient(135deg,#2563EB,#1D4ED8);box-shadow:0 2px 6px rgba(37,99,235,.4) }
						`;
						document.head.appendChild(s);
					}
					const overlay = document.createElement('div');
					overlay.className = 'vd-eval-overlay';
					const modal = document.createElement('div');
					modal.className = 'vd-eval-modal';
					const optionsHtml = EVAL_RATINGS.map(function (r) {
						const hint = r.hint ? '<span class="vd-eval-opt-hint">' + r.hint + '</span>' : '';
						return '<label class="vd-eval-opt"><input type="radio" name="vd-eval-rating" value="' + r.value + '"><span class="vd-eval-opt-text"><span>' + r.label + '</span>' + hint + '</span></label>';
					}).join('');
					modal.innerHTML = `
						<div class="vd-eval-head">
							<div class="vd-eval-icon">★</div>
							<div class="vd-eval-title">请对本单的 AI 分析做评价</div>
						</div>
						<div class="vd-eval-body">
							<p class="vd-eval-desc">评价将用于提升 AI 分析能力。请选择评价等级(必选),可补充文字说明。</p>
							<div class="vd-eval-options">${optionsHtml}</div>
							<p class="vd-eval-comment-label">补充说明(可选)</p>
							<textarea class="vd-eval-comment" placeholder="可补充文字说明…"></textarea>
							<p class="vd-eval-warn" id="vd-eval-warn"></p>
						</div>
						<div class="vd-eval-foot">
							<button class="vd-eval-btn vd-eval-btn-cancel" id="vd-eval-cancel">取消</button>
							<button class="vd-eval-btn vd-eval-btn-primary" id="vd-eval-confirm">确认</button>
						</div>
					`;
					document.body.appendChild(overlay);
					document.body.appendChild(modal);

					let done = false;
					const finish = function (result) {
						if (done) return;
						done = true;
						overlay.remove();
						modal.remove();
						resolve(result);
					};
					// 取消:留在流转对话框,不放行
					document.getElementById('vd-eval-cancel').addEventListener('click', function () { finish(null); });
					overlay.addEventListener('click', function () { finish(null); });
					// 确认:必选校验,选了才 resolve 评价并放行
					document.getElementById('vd-eval-confirm').addEventListener('click', function () {
						const checked = modal.querySelector('input[name="vd-eval-rating"]:checked');
						if (!checked) {
							document.getElementById('vd-eval-warn').textContent = '请先选择评价等级';
							return;
						}
						const comment = (modal.querySelector('.vd-eval-comment') || {}).value || '';
						finish({ rating: checked.value, comment: comment.trim() });
					});
					// Esc 取消
					document.addEventListener('keydown', function onEsc(e) {
						if (e.key === 'Escape') { document.removeEventListener('keydown', onEsc); finish(null); }
					});
				});
			}

			// 拦截action_id_71(Publish)按钮点击事件
			// 不阻止默认行为，让 JIRA 正常打开编辑对话框，再拦截对话框底部的提交按钮
			function interceptActionButton71() {
				// 字段校验总开关：关闭时跳过所有拦截
				if (!options.validationField) return;
				if (!jsaRequireAuth({ silent: true })) return;

				if (!getResolution()) {
					return;
				}

				const actionButton = document.getElementById('action_id_71');
				if (actionButton) {
					// 防止重复绑定
					if (actionButton.dataset.publishIntercepted === 'true') return;

					// 克隆按钮以清除原有事件监听器
					const newButton = actionButton.cloneNode(true);
					actionButton.parentNode.replaceChild(newButton, actionButton);
					newButton.dataset.publishIntercepted = 'true';

					console.log('shugan 找到Publish按钮，绑定对话框拦截');

					// 不阻止默认行为，让 JIRA 正常打开编辑对话框
					// 点击后监听对话框出现，在对话框的提交按钮上做校验拦截
					newButton.addEventListener('click', function() {
						console.log('shugan Publish按钮被点击，等待JIRA编辑对话框出现');
						const rules = getTransitionRules(options);
						const publishFields = rules['Publish'] || DEFAULT_TRANSITION_RULES['Publish'];
						watchForTransitionDialogSubmit(publishFields, 'Publish');
					});
				} else {
					console.log('shugan 未找到action_id_71按钮，无法设置点击事件拦截');
				}
			}
				// 显示状态流转拦截提示的函数
				function showStatusInterceptDialog(message) {
					const styleTag = document.createElement('style');
					styleTag.id = 'status-intercept-dialog-styles';
					if (!document.getElementById('status-intercept-dialog-styles')) {
						styleTag.textContent = `
							@keyframes vdFadeIn { from { opacity: 0; } to { opacity: 1; } }
							@keyframes vdSlideUp { from { opacity: 0; transform: translate(-50%, -48%); } to { opacity: 1; transform: translate(-50%, -50%); } }
							.vd-overlay { position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;animation:vdFadeIn .2s ease }
							.vd-dialog { position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.25),0 0 0 1px rgba(0,0,0,.06);z-index:10000;width:420px;max-width:90vw;overflow:hidden;animation:vdSlideUp .3s ease;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif }
							.vd-header { display:flex;align-items:center;gap:12px;padding:20px 24px 0 }
							.vd-icon { width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#FEE2E2,#FECACA);display:flex;align-items:center;justify-content:center;flex-shrink:0 }
							.vd-icon svg { width:22px;height:22px;color:#EF4444 }
							.vd-title { font-size:17px;font-weight:600;color:#1F2937;line-height:1.3 }
							.vd-body { padding:16px 24px 0 }
							.vd-desc { font-size:14px;color:#EF4444;line-height:1.6;margin:0 0 14px;font-weight:500; }
							.vd-footer { padding:20px 24px;display:flex;justify-content:flex-end;gap:10px;margin-top:8px }
							.vd-btn { padding:9px 22px;border-radius:8px;font-size:14px;font-weight:500;cursor:pointer;transition:all .15s ease;border:none;outline:none }
							.vd-btn:active { transform:scale(.97) }
							.vd-btn-primary { background:linear-gradient(135deg,#3B82F6,#2563EB);color:#fff;box-shadow:0 1px 3px rgba(37,99,235,.3) }
							.vd-btn-primary:hover { background:linear-gradient(135deg,#2563EB,#1D4ED8);box-shadow:0 2px 6px rgba(37,99,235,.4) }
						`;
						document.head.appendChild(styleTag);
					}

					const overlay = document.createElement('div');
					overlay.className = 'vd-overlay';
					document.body.appendChild(overlay);

					const dialog = document.createElement('div');
					dialog.className = 'vd-dialog';
					dialog.innerHTML = `
						<div class="vd-header">
							<div class="vd-icon">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line>
								</svg>
							</div>
							<div class="vd-title">无效的状态流转</div>
						</div>
						<div class="vd-body">
							<p class="vd-desc">${message}</p>
						</div>
						<div class="vd-footer">
							<button class="vd-btn vd-btn-primary" id="vd-btn-confirm">了解</button>
						</div>
					`;
					document.body.appendChild(dialog);

					const closeDialog = () => {
						overlay.style.opacity = '0';
						dialog.style.opacity = '0';
						dialog.style.transform = 'translate(-50%, -48%)';
						setTimeout(() => {
							overlay.remove();
							dialog.remove();
							isIntercepting = false; // Reset lock
							const submitBtn = findSubmitButton();
							if (submitBtn) submitBtn.removeAttribute('data-validation-bound');
						}, 200);
					};

					dialog.querySelector('#vd-btn-confirm').addEventListener('click', closeDialog);
					overlay.addEventListener('click', closeDialog);
				}


				function showActionButtonDialog(emptyFields) {
					const fieldList = Array.isArray(emptyFields) ? emptyFields : emptyFields.split(',');

					const styleTag = document.createElement('style');
					styleTag.id = 'validation-dialog-styles';
					styleTag.textContent = `
						@keyframes vdFadeIn { from { opacity: 0; } to { opacity: 1; } }
						@keyframes vdSlideUp { from { opacity: 0; transform: translate(-50%, -48%); } to { opacity: 1; transform: translate(-50%, -50%); } }
						.vd-overlay { position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;animation:vdFadeIn .2s ease }
						.vd-dialog { position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.25),0 0 0 1px rgba(0,0,0,.06);z-index:10000;width:420px;max-width:90vw;overflow:hidden;animation:vdSlideUp .3s ease;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif }
						.vd-header { display:flex;align-items:center;gap:12px;padding:20px 24px 0 }
						.vd-icon { width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#FEF3C7,#FDE68A);display:flex;align-items:center;justify-content:center;flex-shrink:0 }
						.vd-icon svg { width:22px;height:22px;color:#D97706 }
						.vd-title { font-size:17px;font-weight:600;color:#1F2937;line-height:1.3 }
						.vd-body { padding:16px 24px 0 }
						.vd-desc { font-size:14px;color:#6B7280;line-height:1.6;margin:0 0 14px }
						.vd-field-list { list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:8px }
						.vd-field-tag { display:inline-flex;align-items:center;gap:5px;padding:5px 12px;background:#FEF2F2;border:1px solid #FECACA;border-radius:6px;font-size:13px;font-weight:500;color:#DC2626 }
						.vd-field-tag::before { content:'';width:6px;height:6px;border-radius:50%;background:#EF4444;flex-shrink:0 }
						.vd-footer { padding:20px 24px;display:flex;justify-content:flex-end;gap:10px;margin-top:8px }
						.vd-btn { padding:9px 22px;border-radius:8px;font-size:14px;font-weight:500;cursor:pointer;transition:all .15s ease;border:none;outline:none }
						.vd-btn:active { transform:scale(.97) }
						.vd-btn-primary { background:linear-gradient(135deg,#3B82F6,#2563EB);color:#fff;box-shadow:0 1px 3px rgba(37,99,235,.3) }
						.vd-btn-primary:hover { background:linear-gradient(135deg,#2563EB,#1D4ED8);box-shadow:0 2px 6px rgba(37,99,235,.4) }
					`;
					document.head.appendChild(styleTag);

					const overlay = document.createElement('div');
					overlay.className = 'vd-overlay';
					document.body.appendChild(overlay);

					const dialog = document.createElement('div');
					dialog.className = 'vd-dialog';
					dialog.innerHTML = `
						<div class="vd-header">
							<div class="vd-icon">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
									<line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
								</svg>
							</div>
							<div class="vd-title">必填字段未填写</div>
						</div>
						<div class="vd-body">
							<p class="vd-desc">以下必填字段为空，请填写完整后再执行状态切换操作。</p>
							<ul class="vd-field-list">
								${fieldList.map(f => `<li class="vd-field-tag">${f.trim()}</li>`).join('')}
							</ul>
						</div>
						<div class="vd-footer">
							<button class="vd-btn vd-btn-primary" id="vd_close_btn">知道了</button>
						</div>
					`;
					document.body.appendChild(dialog);

					function closeDialog() {
						dialog.remove();
						overlay.remove();
						styleTag.remove();
					}

					document.getElementById('vd_close_btn').addEventListener('click', closeDialog);
					overlay.addEventListener('click', closeDialog);
					document.addEventListener('keydown', function onEsc(e) {
						if (e.key === 'Escape') { closeDialog(); document.removeEventListener('keydown', onEsc); }
					});
				}


		// 新增状态切换字段校验拦截函数
		// 在工作流按钮点击后，等待JIRA编辑对话框出现，再拦截对话框底部左边的提交按钮
		function interceptNewStatusTransitions() {
			// 字段校验总开关：关闭时跳过所有拦截
			if (!options.validationField) return;
			if (!jsaRequireAuth({ silent: true })) return;

			const statusValidationConfig = getTransitionRules(options);

				const actionButtons = document.querySelectorAll('[id^="action_id_"]');

				actionButtons.forEach(button => {
					// 跳过已有专门处理的 action_id_71 按钮
					if (button.id === 'action_id_71') return;
					// 防止重复绑定
					if (button.dataset.statusIntercepted === 'true') return;

					const buttonText = (button.textContent || button.innerText || '').trim();
					const fieldsToValidate = statusValidationConfig[buttonText];

					if (!fieldsToValidate) return;

					button.dataset.statusIntercepted = 'true';
					console.log('shugan 找到状态切换按钮:', buttonText, '需校验字段:', fieldsToValidate);

					// 不阻止默认行为，让 JIRA 正常打开编辑对话框
					// 点击后监听对话框出现，在对话框的提交按钮上做校验拦截
					button.addEventListener('click', function() {
						console.log('shugan 状态切换按钮被点击:', buttonText, '等待JIRA编辑对话框出现');
						watchForTransitionDialogSubmit(fieldsToValidate, buttonText);
					});
				});
			}

		// 监听 JIRA 工作流过渡对话框的底部提交按钮，并在点击时进行字段校验
		function watchForTransitionDialogSubmit(fieldsToValidate, transitionName) {
			let isIntercepting = true;
			let observerTimeout = null;

			// 在当前可见的对话框容器内查找表单字段值
			// 返回字段当前值（字符串），若字段不在对话框中则返回 null
			function getFieldValueInDialog(fieldId) {
				const dialogContainer = document.querySelector(
					'#workflow-transition-dialog:not([style*="display: none"]), ' +
					'.aui-dialog2:not([aria-hidden="true"]), ' +
					'.aui-dialog2[open], ' +
					'.jira-dialog-open'
				);
				if (!dialogContainer) return null;

				const selectors = [
					`#${fieldId}`,
					`textarea[id="${fieldId}"]`,
					`input[id="${fieldId}"]`,
					`[name="${fieldId}"]`,
					`[data-field-id="${fieldId}"]`,
				];
				for (const sel of selectors) {
					try {
						const el = dialogContainer.querySelector(sel);
						if (el) {
							if (el.tagName && el.tagName.toLowerCase() === 'select') {
								return el.options[el.selectedIndex].text.trim();
							}
							if (el.value !== undefined) return el.value;
							return el.textContent || '';
						}
					} catch (e) {}
				}
				return null;
			}

			function findSubmitButton() {
					// 标准JIRA Server/DataCenter工作流过渡对话框提交按钮
					return (
						document.querySelector('#issue-workflow-transition-submit') ||
						document.querySelector('#workflow-transition-dialog .buttons input[type="submit"]') ||
						document.querySelector('#workflow-transition-dialog .buttons button[type="submit"]') ||
						document.querySelector('#workflow-transition-dialog .aui-button-primary') ||
						// AUI Dialog2 样式（较新版本）
						document.querySelector('.aui-dialog2:not([aria-hidden="true"]) .aui-dialog2-footer .aui-button-primary') ||
						document.querySelector('.aui-dialog2[open] .aui-dialog2-footer .aui-button-primary') ||
						// 旧版jira-dialog样式
						document.querySelector('.jira-dialog-open #issue-workflow-transition-submit') ||
						document.querySelector('.jira-dialog-content .buttons-container .buttons input[type="submit"]') ||
						document.querySelector('.jira-dialog-content .buttons-container .buttons button[type="submit"]') ||
						// 兜底：过渡对话框内任意可见的提交按钮
						document.querySelector('[id*="workflow"][id*="dialog"] [type="submit"]') ||
						document.querySelector('[id*="workflow-transition"] .submit')
					);
				}

				function bindSubmitInterception(submitBtn) {
					if (submitBtn.dataset.validationBound === 'true') return;
					submitBtn.dataset.validationBound = 'true';

					console.log('shugan 找到工作流对话框提交按钮，绑定校验拦截');

					submitBtn.addEventListener('click', function(event) {
						if (!isIntercepting) return;

						// 认证态失效时放行提交（避免锁死用户操作）
						if (!jsaRequireAuth({ silent: true })) {
							isIntercepting = false;
							submitBtn.removeAttribute('data-validation-bound');
							submitBtn.click();
							return;
						}

						event.preventDefault();
						event.stopPropagation();

						const keyText = getKeyNumber();
						if (isEmpty(keyText)) {
							console.log('shugan 未找到 issue key，跳过校验，允许提交');
							isIntercepting = false;
							submitBtn.click();
							return;
						}

						fetchJiraData(keyText).then(async data => {
					if (data.total !== 1) {
							console.log('shugan 无法获取 issue 数据，跳过校验，允许提交');
							isIntercepting = false;
							submitBtn.removeAttribute('data-validation-bound');
							submitBtn.click();
							return;
						}

					const fields = data.issues[0].fields;

					// --- START: 状态流转拦截 (高优先级) ---
					if (transitionName === 'Resolve') {
						const dialogResolutionValue = getFieldValueInDialog('resolution');
						let resolutionName = dialogResolutionValue;
						if (!resolutionName && fields.resolution) {
							resolutionName = fields.resolution.name;
						}
						
						const currentStatusName = fields.status ? fields.status.name : '';
						
						const deprecatedResolutions = ["Duplicate(废弃)", "Un resolved(已弃用）", "Un resolved(已弃用） ", "Done"];
						if (deprecatedResolutions.includes(resolutionName) || deprecatedResolutions.includes(resolutionName.trim())) {
							console.log('shugan 状态流转拦截: 此状态已废弃，无法切换到此状态');
							UsageReporter.report("validation_check", { transition: transitionName, result: "blocked", reason: "deprecated_resolution" });
							showStatusInterceptDialog('此状态已废弃，无法切换到此状态');
							return; // 阻断并跳过后续非空校验
						} else if (resolutionName === "Won't do" || resolutionName === "Won't Do") {
							if (currentStatusName !== "Review Won't Fix") {
								console.log("shugan 状态流转拦截: 只能从Review Won't Fix切到Won't do");
								UsageReporter.report("validation_check", { transition: transitionName, result: "blocked", reason: "invalid_flow" });
								showStatusInterceptDialog("只能从Review Won't Fix切到Won't do");
								return; // 阻断并跳过后续非空校验
							}
						} else if (resolutionName === "Invalid") {
							if (currentStatusName !== "Review Invalid") {
								console.log('shugan 状态流转拦截: 只能从Review Invalid切到Invalid');
								UsageReporter.report("validation_check", { transition: transitionName, result: "blocked", reason: "invalid_flow" });
								showStatusInterceptDialog('只能从Review Invalid切到Invalid');
								return; // 阻断并跳过后续非空校验
							}
						} else if (resolutionName && currentStatusName === "Review Won't Fix") {
							// 反向约束:处于 Review Won't Fix 时,Resolve 只能选 Won't do,选其他 resolution(Fixed 等)要拦。
							// resolution 为空(用户未选)时不拦,放行让 JIRA 自管必填。
							console.log("shugan 状态流转拦截: Review Won't Fix 只能切到 Won't do");
							UsageReporter.report("validation_check", { transition: transitionName, result: "blocked", reason: "invalid_flow" });
							showStatusInterceptDialog("处于 Review Won't Fix 状态，Resolve 只能选择 Won't do，不能切换到其他状态");
							return;
						} else if (resolutionName && currentStatusName === "Review Invalid") {
							// 反向约束:处于 Review Invalid 时,Resolve 只能选 Invalid,选其他 resolution 要拦。
							console.log("shugan 状态流转拦截: Review Invalid 只能切到 Invalid");
							UsageReporter.report("validation_check", { transition: transitionName, result: "blocked", reason: "invalid_flow" });
							showStatusInterceptDialog("处于 Review Invalid 状态，Resolve 只能选择 Invalid，不能切换到其他状态");
							return;
						}

						// --- START: 同账号流转身份校验(状态前置通过后,字段非空校验前)---
						// 仅 Won't do / Invalid 且开关开启时执行;此时 currentStatusName 已由状态前置校验保证
						// 为 "Review Won't Fix" / "Review Invalid"。比对"最近一次进入当前 Review 状态的 actor"与
						// 当前用户 key,相同则阻断(本人不可闭环,需交由他人);取数失败 fail-open 放行,不阻断流转。
						const sameActorGuard = getSameActorGuard(options);
						const isBlockedRes = sameActorGuard.blockedTransitions.some(r =>
							String(r).trim().toLowerCase() === String(resolutionName).trim().toLowerCase());
						if (sameActorGuard.enabled && isBlockedRes && currentStatusName) {
							try {
								const currentUserKey = await fetchMyself();
								const histories = await fetchIssueChangelog(keyText);
								const actorKey = findLastTransitionActor(histories, currentStatusName);
								if (currentUserKey && actorKey && currentUserKey === actorKey) {
									const msg = currentStatusName === "Review Won't Fix"
										? "该单已由你切到 Review Won't Fix，不能由你本人切换到 Won't do，请交由他人处理"
										: "该单已由你切到 Review Invalid，不能由你本人切换到 Invalid，请交由他人处理";
									console.log('shugan 同账号流转拦截: ' + msg);
									UsageReporter.report("validation_check", { transition: transitionName, result: "blocked", reason: "same_actor" });
									showStatusInterceptDialog(msg);
									return; // 阻断并跳过后续非空校验
								}
								if (!currentUserKey || !actorKey) {
									console.log('shugan 同账号校验: 取数不全,放行(currentUser/actor 为空)');
									UsageReporter.report("validation_check", { transition: transitionName, result: "skipped", reason: "actor_lookup_skipped" });
								}
							} catch (e) {
								console.warn('shugan 同账号校验: 异常,放行', e);
								UsageReporter.report("validation_check", { transition: transitionName, result: "skipped", reason: "actor_lookup_skipped" });
							}
						}
						// --- END: 同账号流转身份校验 ---
					}
					// --- END: 状态流转拦截 ---

					const emptyFields = [];

					const dynamicFieldsMap = getFieldsMap(options);
					fieldsToValidate.forEach(field => {
						let tempfield = dynamicFieldsMap.get(field);
						if (!tempfield) tempfield = field;

						// 优先检查对话框表单中的字段值（用户在对话框内实时填写的内容）
						const dialogValue = getFieldValueInDialog(tempfield);
						if (dialogValue !== null) {
							// 字段存在于对话框表单，使用对话框中的值进行校验
							console.log('shugan 从对话框表单读取字段', field, '值:', dialogValue);
							if (isEmpty(dialogValue)) {
								emptyFields.push(field);
							}
						} else {
							// 字段不在对话框表单中，通过 API 获取已保存的值
							if (isEmpty(fields[tempfield])) {
								emptyFields.push(field);
							}
						}
					});

						if (emptyFields.length > 0) {
							console.log('shugan 状态切换被拦截，空字段:', emptyFields);
							UsageReporter.report("validation_check", { transition: transitionName, result: "blocked", emptyFields: emptyFields });
							showActionButtonDialog(emptyFields.toString());
							return;
						}

						// --- START: AI 分析评价门禁(Publish / Review Won't Fix / Review Invalid)---
						// 置于字段非空校验之后、放行之前:避免字段为空被拦截后,用户补填再提交时被重复要求评价。
						// 仅 EVAL_GATED_TRANSITIONS 内的流转、开关开启、已认证时,
						// 对"最近一条已回传的 AI 分析"采集必选评价。
						// 弹出独立评价弹窗:点「确认」且选了 rating → 回传评价并放行提交;
						//                  点「取消」/关闭/未选 → 留在流转对话框,不放行。
						if (EVAL_GATED_TRANSITIONS.indexOf(transitionName) !== -1 && options.evaluationEnabled !== false) {
							try {
								const target = await getEvaluationTarget(keyText);
								if (target && target.exists) {
									// 有可评分析:弹评价弹窗(必选),用户确认后才放行
									const evalData = await showEvaluationDialog();
									if (!evalData) {
										console.log('shugan ' + transitionName + ' 拦截:用户取消 AI 分析评价');
										UsageReporter.report("validation_check", { transition: transitionName, result: "blocked", reason: "evaluation_cancelled" });
										return; // 留在流转对话框,不放行
									}
									// 已确认评价:异步回传,放行提交
									submitEvaluation({
										jira_key: keyText,
										task_id: target.task_id || '',
										rating: evalData.rating,
										comment: evalData.comment,
										evaluator: getJiraUsername(),
									});
									console.log('shugan 评价已确认,放行提交');
								}
								// 无可评分析或端点不可达:不弹窗,直接放行
							} catch (e) {
								console.warn('shugan 评价门禁异常,放行不卡:', e);
							}
						}
						// --- END: AI 分析评价门禁 ---

						console.log('shugan 校验通过，允许切换状态至:', transitionName);
						UsageReporter.report("validation_check", { transition: transitionName, result: "passed" });
						isIntercepting = false;
						submitBtn.removeAttribute('data-validation-bound');
						submitBtn.click();
					}).catch(error => {
						console.error('shugan 获取JIRA数据失败，跳过校验:', error);
						isIntercepting = false;
						submitBtn.removeAttribute('data-validation-bound');
						submitBtn.click();
					});
					});

					// 对话框取消时清理标记，以便下次可重新绑定
					const cancelBtn = document.querySelector(
						'#workflow-transition-dialog-cancel, #transition-dialog-cancel, ' +
						'.aui-dialog2-footer .aui-button-link, .cancel-link'
					);
					if (cancelBtn) {
						cancelBtn.addEventListener('click', function() {
							submitBtn.removeAttribute('data-validation-bound');
						}, { once: true });
					}
				}

				// 先立即检查一次（防止对话框已存在于DOM中）
				const existingBtn = findSubmitButton();
				if (existingBtn) {
					bindSubmitInterception(existingBtn);
					return;
				}

				// 通过 MutationObserver 等待对话框出现
				const dialogObserver = new MutationObserver(() => {
					const submitBtn = findSubmitButton();
					if (!submitBtn) return;

					dialogObserver.disconnect();
					clearTimeout(observerTimeout);
					bindSubmitInterception(submitBtn);
				});

				dialogObserver.observe(document.body, {
					subtree: true,
					childList: true,
					attributes: true,
					attributeFilter: ['aria-hidden', 'style', 'open', 'class'],
				});

				// 10秒后自动清理，防止内存泄漏
				observerTimeout = setTimeout(() => {
					dialogObserver.disconnect();
					console.log('shugan 对话框监听超时，已清理');
				}, 10000);
			}

				// 启用Publish按钮的函数
				function enableActionButton71() {
					const actionButton = document.getElementById('action_id_71');
					if (actionButton) {
						if (actionButton.style.pointerEvents === 'auto') {
							console.log('shugan enableActionButton71 return false');
							return false;
						}
						actionButton.style.pointerEvents = 'auto';
						actionButton.style.opacity = '1';
						actionButton.style.cursor = 'pointer';
						actionButton.removeAttribute('disabled');
						console.log('shugan 已启用Publish的按钮');
					} else {
						console.log('shugan 未找到Publish的按钮');
					}
				}

				// 禁用Publish按钮的函数
				function disableActionButton71() {
					const actionButton = document.getElementById('action_id_71');
					if (actionButton) {
						if (actionButton.style.pointerEvents === 'none') {
							console.log('shugan disableActionButton71 return false');
							return false;
						}
						actionButton.style.pointerEvents = 'none';
						actionButton.style.opacity = '0.5';
						actionButton.style.cursor = 'not-allowed';
						actionButton.setAttribute('disabled', 'disabled');
						console.log('shugan 已禁用Publish的按钮');
					} else {
						console.log('shugan 未找到Publish的按钮');
					}
				}

				// 添加获取状态值的函数
				function getStatusValue() {
					// 等待页面完全加载
					console.log('shugan getStatusValue: 等待页面完全加载');
					if (document.readyState === 'loading') {
						document.addEventListener('DOMContentLoaded', function() {
							setTimeout(getStatusValue, 100); // 延迟100ms确保DOM完全渲染
						});
						// disableActionButton71();
						return false;
					}

				interceptActionButton71();
				// 检查新增状态切换按钮的字段校验
				interceptNewStatusTransitions();
					
				// // 获取状态: status-val元素
					// const statusElement = document.getElementById('status-val');
					// if (statusElement) {
					// 	// 获取状态文本内容
					// 	const statusText = statusElement.textContent || statusElement.innerText;
					// 	console.log('shugan statusText = ', statusText.trim());
					// 	if (statusText.trim() !== '已解决') {
					// 		return false;
					// 	}
					// } else {
					// 	console.log('shugan 未找到状态值');
					// 	return false;
					// }

					// // 获取Gerrit Id: customfield_10130-val元素
					// const gerritIdElement = document.getElementById('customfield_10130-val');
					// if (gerritIdElement) {
					// 	// 获取gerritId文本内容
					// 	const gerritId = gerritIdElement.textContent || gerritIdElement.innerText;
					// 	if (gerritId.trim() === '') {
					// 		console.log('shugan gerritId为空字符串');
					// 		disableActionButton71();
					// 		return false;
					// 	}
					// } else {
					// 	console.log('shugan 未找gerritId');
					// 	disableActionButton71();
					// 	return false;
					// }

					// // 获取Solution: customfield_10120-val元素
					// const solutionElement = document.getElementById('customfield_10120-val');
					// if (solutionElement) {
					// 	// 获取Solution文本内容
					// 	const solutionText = solutionElement.textContent || solutionElement.innerText;
					// 	if (solutionText.trim() === '') {
					// 		console.log('shugan solutionText为空字符串');
					// 		disableActionButton71();
					// 		return false;
					// 	}
					// } else {
					// 	console.log('shugan 未找到 solutionText');
					// 	disableActionButton71();
					// 	return false;
					// }

					// // 获取Root Cause: customfield_10111-val元素
					// const rootCauseElement = document.getElementById('customfield_10111-val');
					// if (rootCauseElement) {
					// 	// 获取Root Cause文本内容
					// 	const rootCauseText = rootCauseElement.textContent || rootCauseElement.innerText;
					// 	if (rootCauseText.trim() === '') {
					// 		console.log('shugan rootCauseText为空字符串');
					// 		disableActionButton71();
					// 		return false;
					// 	}
					// } else {
					// 	console.log('shugan 未找到 rootCauseText');
					// 	disableActionButton71();
					// 	return false;
					// }

					// // 获取修复的版本: fixfor-val元素
					// const fixforElement = document.getElementById('fixfor-val');
					// if (fixforElement) {
					// 	// 获取修复的版本文本内容
					// 	const fixforText = (fixforElement.textContent || fixforElement.innerText).trim();
					// 	if (fixforText === '' || fixforText === '无') {
					// 		console.log('shugan fixforText为空字符串');
					// 		disableActionButton71();
					// 		return false;
					// 	}
					// } else {
					// 	console.log('shugan 未找到 fixforText');
					// 	disableActionButton71();
					// 	return false;
					// }

					// console.log('shugan getStatusValue: 所有检查通过');
					return true;
				}
			});
		});
	}
});

// ======================= MTK eService Case 模板校验与填充 =======================
// 独立模块：仅在 MTK eService 创建页生效，不影响 JIRA 逻辑
// 功能：1) Class=Bug 时校验 Description / Repeat Steps 模板段是否填写
//       2) 提供一键填充模板按钮，避免研发重复复制
(function initMtkCaseValidation() {
  'use strict';
  console.log("[JSA-DIAG] MTK IIFE 开始执行");

  // 防止 content script 多次注入
  if (window.__mtkCaseValidationInited) return;
  window.__mtkCaseValidationInited = true;

  // ---- 页面判定 ----
  function isMtkCreatePage() {
    try {
      return (
        location.hostname === 'eservice.mediatek.com' &&
        location.pathname.indexOf('/eservice-portal/issue_manager/create') === 0
      );
    } catch (e) {
      return false;
    }
  }
  if (!isMtkCreatePage()) return;

  // ---- 配置缓存 ----
  let mtkEnabled = true; // 默认开启，异步读取真实配置后更新
  function loadMtkOption() {
    try {
      chrome.runtime.sendMessage('getOptions', function (opts) {
        try {
          mtkEnabled = !!(opts && opts.mtkValidation && opts.mtkValidation.enabled);
        } catch (e) {
          mtkEnabled = true;
        }
      });
    } catch (e) {
      mtkEnabled = true;
    }
  }
  loadMtkOption();

  // ---- 模板内容 ----
  const DESC_TEMPLATE =
    '[Current status]\n\n' +
    '[Expected result]\n\n' +
    '[Note]\n';
  const REPEAT_TEMPLATE =
    '【1、问题现象 / Symptom of the problem】：\n\n' +
    '【2、复现步骤 / Reproduction steps】：\n\n' +
    '【3、复现概率 / Reproducibility probability】：\n\n' +
    '【4、抓取Log信息 / Capture log information】：\n\n' +
    '【5、问题分析过程 / Problem analysis】：\n\n' +
    '【6、问题分析结论 / Analysis conclusion of the problem】：\n\n' +
    '【7、下一步action / Next action】：\n';

  // Description 模板标题（用于校验）
  const DESC_HEADERS = ['[Current status]', '[Expected result]', '[Note]'];
  // Repeat Steps 段标题正则
  const REPEAT_HEADER_RE = /【(\d)、([^】]+)】：/g;
  // 非全局版本（用于单行内容检查，避免 lastIndex 污染）
  const REPEAT_HEADER_SINGLE_RE = /【(\d)、([^】]+)】：/;

  // ---- DOM 选择器 ----
  const SEL = {
    clazzFormItem: 'label[for="clazz"]',
    clazzBugItem: '.ant-select-selection-item[title="Bug"]',
    description: '#description',
    repeatSteps: '#repeatSteps',
    submitBtn: 'form.ant-form button[type="submit"]',
    form: 'form.ant-form',
    descLabel: 'label[for="description"]',
    repeatLabel: 'label[for="repeatSteps"]',
  };

  // ---- 认证门控（复用 JSA 体系；MTK 页面可能无 __jsaAuth，此时放行） ----
  function mtkAuthOk() {
    try {
      if (window.__jsaAuth && typeof window.__jsaAuth.check === 'function') {
        return !!window.__jsaAuth.check();
      }
    } catch (e) {}
    return true; // MTK 页无认证上下文时默认放行，避免锁死
  }

  // ---- 判断 Class 是否为 Bug ----
  function isClassBug() {
    // 诊断：输出 Class 下拉的完整 HTML
    const clazzInput = document.getElementById('clazz');
    const clazzWrap = clazzInput ? clazzInput.closest('.ant-select') : null;
    console.log('[JSA-MTK] clazzWrap HTML:', clazzWrap ? clazzWrap.outerHTML.substring(0, 500) : 'NOT FOUND');
    
    // 诊断：输出所有 selection-item
    const allItems = document.querySelectorAll('.ant-select-selection-item, .ant-select-selection-placeholder');
    console.log('[JSA-MTK] 所有 selection-item/placeholder 数量:', allItems.length);
    allItems.forEach(function(el, i) {
      console.log('[JSA-MTK]   item[' + i + ']: title="' + el.getAttribute('title') + '" text="' + (el.textContent||'').trim() + '"');
    });
    
    // 方式1：selection-item[title=Bug]
    const bugItem = document.querySelector('.ant-select-selection-item[title="Bug"]');
    if (bugItem) { console.log('[JSA-MTK] isClassBug=true (via title=Bug)'); return true; }
    // 方式2：任何 selection-item 含 Bug 文本
    const allSel = document.querySelectorAll('.ant-select-selection-item');
    for (const el of allSel) {
      if (/bug/i.test(el.textContent || '')) { console.log('[JSA-MTK] isClassBug=true (via text)'); return true; }
    }
    // 方式3：clazz input value
    if (clazzInput && clazzInput.value && /bug/i.test(clazzInput.value)) {
      console.log('[JSA-MTK] isClassBug=true (via input value)'); return true;
    }
    console.log('[JSA-MTK] isClassBug=false');
    return false;
  }

  // ---- React 受控 textarea 写入 ----
  function setReactTextarea(textarea, value) {
    if (!textarea) return false;
    const proto = window.HTMLTextAreaElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) {
      desc.set.call(textarea, value);
    } else {
      textarea.value = value;
    }
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  // ---- 注入模板填充按钮 ----
  const BUTTON_FLAG = 'data-mtk-btn';
  function injectFillButton(labelSelector, template, which) {
    const label = document.querySelector(labelSelector);
    if (!label) return;
    // 标题所在列
    const labelCol = label.closest('.ant-form-item-label') || label.parentElement;
    if (!labelCol) return;
    if (labelCol.querySelector('[' + BUTTON_FLAG + '="' + which + '"]')) return; // 已注入
    const btn = document.createElement('a');
    btn.setAttribute(BUTTON_FLAG, which);
    btn.href = 'javascript:void(0)';
    btn.textContent = '📝 填充模板';
    Object.assign(btn.style, {
      marginLeft: '8px',
      fontSize: '12px',
      color: '#32C5D2',
      cursor: 'pointer',
      whiteSpace: 'nowrap',
      textDecoration: 'none',
      fontWeight: '500',
      verticalAlign: 'middle',
    });
    btn.addEventListener('mouseenter', function () { btn.style.textDecoration = 'underline'; });
    btn.addEventListener('mouseleave', function () { btn.style.textDecoration = 'none'; });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      const targetId = which === 'desc' ? SEL.description : SEL.repeatSteps;
      const ta = document.querySelector(targetId);
      if (!ta) return;
      setReactTextarea(ta, template);
      // 聚焦与视觉反馈
      ta.focus();
      btn.textContent = '✓ 已填充';
      setTimeout(function () { btn.textContent = '📝 填充模板'; }, 1200);
    });
    labelCol.appendChild(btn);
  }

  function injectAllFillButtons() {
    injectFillButton(SEL.descLabel, DESC_TEMPLATE, 'desc');
    injectFillButton(SEL.repeatLabel, REPEAT_TEMPLATE, 'repeat');
  }

  // ---- 校验逻辑 ----
  // 返回 { missing: [..], kind: 'desc'|'repeat'|'empty' }
  function validateDescription() {
    const ta = document.querySelector(SEL.description);
    const text = ta ? ta.value : '';
    if (!text || !text.trim()) {
      return { kind: 'empty', missing: DESC_HEADERS.slice() };
    }
    const missing = [];
    const lines = text.split(/\r?\n/);
    // 用模式匹配找标题行：以 [ 开头 ] 结尾
    const headerIdx = [];
    lines.forEach(function (line, i) {
      const trimmed = line.trim();
      if (/^\[.+\]$/.test(trimmed)) headerIdx.push({ line: i, text: trimmed });
    });
    if (headerIdx.length === 0) {
      return { kind: 'empty', missing: DESC_HEADERS.slice() };
    }
    // 检查每段：标题文字是否标准 + 标题下是否有内容
    headerIdx.forEach(function (item, idx) {
      const expectedHeader = DESC_HEADERS[idx];
      const nextLine = idx + 1 < headerIdx.length ? headerIdx[idx + 1].line : lines.length;
      let hasContent = false;
      for (let j = item.line + 1; j < nextLine; j++) {
        if (lines[j].trim()) { hasContent = true; break; }
      }
      // 报告条件：标题文字不标准 OR 标题下无内容
      if (item.text !== expectedHeader || !hasContent) {
        missing.push(expectedHeader || ('第' + (idx+1) + '段'));
      }
    });
    return { kind: 'desc', missing: missing };
  }
  function validateRepeatSteps() {
    const ta = document.querySelector(SEL.repeatSteps);
    const text = ta ? ta.value : '';
    const DEFAULT_REP_HEADERS = [
      '1、问题现象 / Symptom of the problem',
      '2、复现步骤 / Reproduction steps',
      '3、复现概率 / Reproducibility probability',
      '4、抓取Log信息 / Capture log information',
      '5、问题分析过程 / Problem analysis',
      '6、问题分析结论 / Analysis conclusion of the problem',
      '7、下一步action / Next action'
    ];
    // 标准段标题（用于匹配，含【】：）
    const STD_REP_FULL = [
      '【1、问题现象 / Symptom of the problem】：',
      '【2、复现步骤 / Reproduction steps】：',
      '【3、复现概率 / Reproducibility probability】：',
      '【4、抓取Log信息 / Capture log information】：',
      '【5、问题分析过程 / Problem analysis】：',
      '【6、问题分析结论 / Analysis conclusion of the problem】：',
      '【7、下一步action / Next action】：'
    ];
    if (!text || !text.trim()) {
      return { kind: 'empty', missing: DEFAULT_REP_HEADERS.slice() };
    }
    const missing = [];
    const lines = text.split(/\r?\n/);
    const segIdx = [];
    lines.forEach(function (line, i) {
      const trimmed = line.trim();
      const m = trimmed.match(/^(【\d+、[^】]+】[：:]*)/);
      if (m) segIdx.push({ no: parseInt(m[1].match(/\d+/)[0], 10), line: i, fullLine: trimmed, headerLen: m[1].length, headerText: m[1] });
    });
    if (segIdx.length === 0) {
      return { kind: 'empty', missing: DEFAULT_REP_HEADERS.slice() };
    }
    segIdx.forEach(function (item, idx) {
      const nextLine = idx + 1 < segIdx.length ? segIdx[idx + 1].line : lines.length;
      let hasContent = false;
      const afterTitle = item.fullLine.slice(item.headerLen).trim();
      if (afterTitle) hasContent = true;
      for (let j = item.line + 1; j < nextLine; j++) {
        if (lines[j].trim()) { hasContent = true; break; }
      }
      // 报告条件：标题文字不标准 OR 标题下无内容
      const stdFull = STD_REP_FULL[item.no - 1];
      if ((stdFull && item.headerText !== stdFull) || !hasContent) {
        const defaultTitle = DEFAULT_REP_HEADERS[item.no - 1] || (item.no + '、（未知段）');
        missing.push(defaultTitle);
      }
    });
    return { kind: 'repeat', missing: missing };
  }
  // ---- 校验结果弹窗（复用现有 vd 样式风格） ----
  let mtkStyleInjected = false;
  function injectMtkStyle() {
    if (mtkStyleInjected) return;
    mtkStyleInjected = true;
    const s = document.createElement('style');
    s.textContent =
      '@keyframes mtkFadeIn{from{opacity:0}to{opacity:1}}' +
      '@keyframes mtkSlideUp{from{opacity:0;transform:translate(-50%,-48%)}to{opacity:1;transform:translate(-50%,-50%)}}' +
      '.mtk-overlay{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99999;animation:mtkFadeIn .2s ease}' +
      '.mtk-dialog{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.25),0 0 0 1px rgba(0,0,0,.06);z-index:100000;width:460px;max-width:90vw;max-height:85vh;overflow:auto;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;animation:mtkSlideUp .3s ease}' +
      '.mtk-header{display:flex;align-items:center;gap:12px;padding:20px 24px 0}' +
      '.mtk-icon{width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#FEF3C7,#FDE68A);display:flex;align-items:center;justify-content:center;flex-shrink:0}' +
      '.mtk-icon svg{width:22px;height:22px;color:#D97706}' +
      '.mtk-title{font-size:17px;font-weight:600;color:#1F2937;line-height:1.3}' +
      '.mtk-body{padding:16px 24px 0}' +
      '.mtk-desc{font-size:14px;color:#6B7280;line-height:1.6;margin:0 0 14px}' +
      '.mtk-field-list{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:8px}' +
      '.mtk-field-tag{display:inline-flex;align-items:center;gap:5px;padding:5px 12px;background:#FEF2F2;border:1px solid #FECACA;border-radius:6px;font-size:13px;font-weight:500;color:#DC2626}' +
      '.mtk-field-tag::before{content:"";width:6px;height:6px;border-radius:50%;background:#EF4444;flex-shrink:0}' +
      '.mtk-footer{padding:20px 24px;display:flex;justify-content:flex-end;gap:10px;margin-top:8px}' +
      '.mtk-btn{padding:9px 22px;border-radius:8px;font-size:14px;font-weight:500;cursor:pointer;transition:all .15s ease;border:none;outline:none}' +
      '.mtk-btn:active{transform:scale(.97)}' +
      '.mtk-btn-primary{background:linear-gradient(135deg,#3B82F6,#2563EB);color:#fff;box-shadow:0 1px 3px rgba(37,99,235,.3)}' +
      '.mtk-btn-primary:hover{background:linear-gradient(135deg,#2563EB,#1D4ED8);box-shadow:0 2px 6px rgba(37,99,235,.4)}';
    document.head.appendChild(s);
  }
  function showMtkErrorDialog(groups) {
    // groups: { desc: [...], repeat: [...] }
    injectMtkStyle();
    const overlay = document.createElement('div');
    overlay.className = 'mtk-overlay';
    const dialog = document.createElement('div');
    dialog.className = 'mtk-dialog';
    // 构建分组 HTML
    function renderGroup(title, items) {
      if (!items || items.length === 0) return '';
      var tags = items.map(function (f) {
        return '<li class="mtk-field-tag">' + f.replace(/</g, '&lt;') + '</li>';
      }).join('');
      return '<div style="margin-bottom:12px"><div style="font-size:14px;font-weight:600;color:#1F2937;margin-bottom:6px">' + title + '</div><ul class="mtk-field-list">' + tags + '</ul></div>';
    }
    var groupsHtml = renderGroup('Description', groups.desc) + renderGroup('Repeat Steps', groups.repeat);
    dialog.innerHTML =
      '<div class="mtk-header"><div class="mtk-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div><div class="mtk-title">MTK Case 模板内容不完整</div></div>' +
      '<div class="mtk-body"><p class="mtk-desc">以下模板段未填写具体信息，请补全后再提交（可点"填充模板"按钮快速生成骨架）：</p>' +
      groupsHtml + '</div>' +
      '<div class="mtk-footer"><button class="mtk-btn mtk-btn-primary" id="mtk_close_btn">知道了</button></div>';
    document.body.appendChild(overlay);
    document.body.appendChild(dialog);
    function close() { overlay.remove(); dialog.remove(); }
    dialog.querySelector('#mtk_close_btn').addEventListener('click', close);
    overlay.addEventListener('click', close);
    document.addEventListener('keydown', function onEsc(e) {
      if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onEsc); }
    });
  }
  // ---- 拦截表单提交 ----
  // 抽取校验逻辑为独立函数：返回 true=通过，false=拦截
  function runMtkValidation() {
    const descRes = validateDescription();
    const repRes = validateRepeatSteps();
    // Description 和 Repeat Steps 都需要满足，分类收集缺失项
    const groups = { desc: [], repeat: [] };
    groups.desc = descRes.missing.slice();
    groups.repeat = repRes.missing.slice();
    const total = groups.desc.length + groups.repeat.length;
    if (total > 0) {
      showMtkErrorDialog(groups);
      return false;
    }
    return true;
  }
  function bindSubmitIntercept() {
    // 多种选择器兜底查找 Submit 按钮
    let buttons = document.querySelectorAll(SEL.submitBtn);
    if (buttons.length === 0) buttons = document.querySelectorAll('button[type="submit"]');
    if (buttons.length === 0) {
      const all = document.querySelectorAll('button.ant-btn-primary, button.ant-btn');
      buttons = Array.from(all).filter(function (b) { return /submit/i.test(b.textContent || ''); });
    }
    console.log('[JSA-MTK] bindSubmitIntercept 找到 ' + buttons.length + ' 个按钮');
    Array.from(buttons).forEach(function (btn) {
      if (btn.getAttribute('data-mtk-click-bound') === '1') return;
      btn.setAttribute('data-mtk-click-bound', '1');
      console.log('[JSA-MTK] 绑定按钮:', btn.textContent.trim().substring(0, 30));
      btn.addEventListener('click', function (event) {
        console.log('[JSA-MTK] Submit click 拦截, mtkEnabled=' + mtkEnabled);
        if (!mtkEnabled) return;
        // 不再限制 Class 必须为 Bug，所有 Class 都校验
        if (!mtkAuthOk()) { console.log('[JSA-MTK] 认证未通过'); return; }
        const ok = runMtkValidation();
        console.log('[JSA-MTK] 校验结果=' + ok);
        if (!ok) { event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation(); }
      }, true);
    });
    // 兜底：form submit
    const form = document.querySelector(SEL.form);
    if (form && form.getAttribute('data-mtk-submit-bound') !== '1') {
      form.setAttribute('data-mtk-submit-bound', '1');
      form.addEventListener('submit', function (event) {
        if (!mtkEnabled || !mtkAuthOk()) return;
        if (!runMtkValidation()) { event.preventDefault(); event.stopPropagation(); }
      }, true);
    }
  }
  function mtkTick() {
    if (!mtkEnabled) {
      console.log('[JSA-MTK] mtkEnabled=false，跳过');
      return;
    }
    // 始终绑定 Submit 拦截（Class 判断在 click 回调内部）
    bindSubmitIntercept();
    // 始终尝试注入填充按钮（即使非 Bug 也无妨，按钮只在 Bug 时有用）
    injectAllFillButtons();
  }

  // 定期重读配置（用户可能在配置页改了开关）
  setInterval(loadMtkOption, 5000);

  // 首次尝试 + DOM 变化监听
  setTimeout(mtkTick, 500);
  setTimeout(mtkTick, 1500);
  setTimeout(mtkTick, 3000);
  const obs = new MutationObserver(function () { mtkTick(); });
  try {
    obs.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['class', 'title'] });
  } catch (e) {}

  console.log('[JSA] MTK eService Case 模板校验模块已加载, host=' + location.hostname);
})();
// ===================== MTK eService Case 模板校验与填充 END =====================

// ===================== 查找同单（Find Similar Issues）START =====================
/**
 * 在问题详情页的 #opsbar-opsbar-transitions 工具栏后注入"查找同单"按钮，
 * 通过 JIRASearch API 获取语义搜索结果（FAISS + Embedding + LLM Rerank）。
 * 复用 jsaRequireAuth() 认证门控、UsageReporter.report() 统计上报。
 * v3.2.0: 从本地算法改为调用 JIRASearch API，不再依赖 JIRA REST API 搜索。
 * v3.3.0: 服务器端缓存机制、更新按钮、缓存时间提示，移除内部搜单工具跳转入口和相似度列。
 * v3.3.1: 移除后台自动预热缓存，改为仅在点击"查找同单"按钮时才触发搜索，
 *         避免用户浏览工单时对未缓存单子无谓消耗 LLM token。
 */
(function () {
  'use strict';
  var MAX_DISPLAY = 15;
  // Bug 搜索系统首页（API 不可用时的降级跳转目标，与 background 的 JSA_BASE_URL 同源）
  var BUG_SEARCH_HOME = 'http://10.24.137.80:8080/';
  // ---- 0. 问题详情页判定（兼容多种 URL 格式）----
  // JIRA 问题详情页有多种 URL 格式：
  //   1) 传统格式: /browse/XXX-123
  //   2) 项目视图格式: /projects/XXX/issues/XXX-123
  //   3) 部分版本格式: /issue/projects/XXX/issues/XXX-123
  function isIssueDetailPage() {
    var p = window.location.pathname;
    if (/\/browse\/[A-Z][A-Z0-9]+-\d+/i.test(p)) return true;
    if (/\/(?:issue\/)?projects\/[^/]+\/issues\/[A-Z][A-Z0-9]+-\d+/i.test(p)) return true;
    return false;
  }
  // 从 URL 提取 Issue Key（兼容多种 URL 格式），作为 #key-val 不可用时的 fallback
  function parseIssueKeyFromUrl() {
    var p = window.location.pathname;
    var m = p.match(/\/(?:browse\/|(?:issue\/)?projects\/[^/]+\/issues\/)([A-Z][A-Z0-9]+-\d+)/i);
    return m ? m[1].toUpperCase() : '';
  }

  // ---- 1. 当前工单信息提取 ----
  function getCurrentIssueInfo() {
    var issueKey = '';
    var summary = '';
    var keyEl = document.querySelector('#key-val');
    if (keyEl) {
      issueKey = (keyEl.textContent || '').trim();
    }
    if (!issueKey) {
      issueKey = parseIssueKeyFromUrl();
    }
    if (!issueKey) return null;
    var summaryEl = document.querySelector('#summary-val');
    if (summaryEl) {
      summary = (summaryEl.textContent || '').trim();
    }
    if (!summary) return null;
    var keyParts = issueKey.match(/^([A-Z][A-Z0-9]+)-\d+$/i);
    var projectKey = keyParts ? keyParts[1].toUpperCase() : '';
    return { issueKey: issueKey, summary: summary, projectKey: projectKey };
  }

  // ---- 2. DOM 注入（按钮 + 样式）----
  function injectStyles() {
    if (document.getElementById('jsa-find-similar-styles')) return;
    var style = document.createElement('style');
    style.id = 'jsa-find-similar-styles';
    style.textContent =
      '@keyframes jsaFsiFadeIn { from { opacity: 0; } to { opacity: 1; } }' +
      '@keyframes jsaFsiZoomIn { from { opacity: 0; transform: scale(.96); } to { opacity: 1; transform: scale(1); } }' +
      '#jsa-find-similar-btn { display:inline-flex; align-items:center; gap:4px; cursor:pointer; ' +
      '  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; ' +
      '  background: #fff; border: 1px solid #DFE1E6; border-radius: 4px; padding: 4px 12px; ' +
      '  font-size: 14px; color: #42526E; height: 30px; transition: all .15s ease; }' +
      '#jsa-find-similar-btn:hover { background: #F4F5F7; border-color: #C1C7D0; color: #172B4D; }' +
      '#jsa-find-similar-btn svg { width: 16px; height: 16px; }' +
      '.jsa-fsi-overlay { position:fixed; inset:0; background:rgba(9,30,66,.54); z-index:999999; display:flex; align-items:center; justify-content:center; animation:jsaFsiFadeIn .2s ease; }' +
      '.jsa-fsi-modal { background:#fff; border-radius:8px; box-shadow:0 20px 60px rgba(0,0,0,.25); width:min(1180px, 92vw); max-width:92vw; max-height:85vh; display:flex; flex-direction:column; overflow:hidden; animation:jsaFsiZoomIn .3s ease; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; }' +
      '.jsa-fsi-header { display:flex; align-items:center; justify-content:space-between; padding:16px 20px; border-bottom:1px solid #DFE1E6; gap:8px; }' +
      '.jsa-fsi-title { font-size:16px; font-weight:600; color:#172B4D; }' +
      '.jsa-fsi-refresh { cursor:pointer; font-size:13px; color:#0052CC; border:1px solid #DEEBFF; background:#DEEBFF; padding:4px 12px; border-radius:4px; line-height:1; transition:all .15s; white-space:nowrap; margin-right:8px; }' +
      '.jsa-fsi-refresh:hover { background:#B2D4FF; border-color:#B2D4FF; }' +
      '.jsa-fsi-bugsearch { font-size:13px; color:#0052CC; text-decoration:none; white-space:nowrap; margin-left:auto; margin-right:8px; padding:4px 8px; border-radius:4px; line-height:1; transition:all .15s; display:inline-flex; align-items:center; gap:3px; }' +
      '.jsa-fsi-bugsearch:hover { background:#DEEBFF; }' +
      '.jsa-fsi-refresh:disabled { opacity:0.5; cursor:not-allowed; }' +
      '.jsa-fsi-close { cursor:pointer; font-size:20px; color:#6B778C; border:none; background:none; padding:4px; line-height:1; }' +
      '.jsa-fsi-close:hover { color:#172B4D; }' +
      '.jsa-fsi-cache-info { padding:8px 20px; background:#FFFAE6; border-bottom:1px solid #FFF0B3; font-size:12px; color:#974F0C; display:flex; align-items:center; gap:6px; }' +
      '.jsa-fsi-stats { display:flex; gap:12px; flex-wrap:wrap; padding:12px 20px; background:#F4F5F7; border-bottom:1px solid #DFE1E6; font-size:13px; }' +
      '.jsa-fsi-stat { display:flex; align-items:center; gap:4px; }' +
      '.jsa-fsi-body { flex:1; overflow-y:auto; padding:0; }' +
      '.jsa-fsi-table { width:100%; border-collapse:collapse; font-size:13px; }' +
      '.jsa-fsi-table th { text-align:left; padding:8px 12px; background:#FAFBFC; border-bottom:1px solid #DFE1E6; color:#6B778C; font-weight:600; font-size:12px; }' +
      '.jsa-fsi-table td { padding:8px 12px; border-bottom:1px solid #EBECF0; color:#172B4D; vertical-align:top; }' +
      '.jsa-fsi-table tr.jsa-fsi-row:hover td { background:#F4F5F7; cursor:pointer; }' +
      '.jsa-fsi-key a { color:#0052CC; text-decoration:none; font-weight:600; }' +
      '.jsa-fsi-key a:hover { text-decoration:underline; }' +
      '.jsa-fsi-summary { min-width:240px; word-break:break-word; overflow-wrap:break-word; }' +
      '.jsa-fsi-status { padding:2px 6px; border-radius:3px; font-size:11px; font-weight:500; }' +
      '.jsa-fsi-status-closed { background:#E3FCEF; color:#006644; }' +
      '.jsa-fsi-status-resolved { background:#DEEBFF; color:#0052CC; }' +
      '.jsa-fsi-status-open { background:#FFF0B3; color:#974F0C; }' +
      '.jsa-fsi-status-other { background:#F4F5F7; color:#6B778C; }' +
      '.jsa-fsi-empty { padding:60px 20px; text-align:center; color:#6B778C; font-size:15px; }' +
      '.jsa-fsi-footer { flex-shrink:0; border-top:1px solid #DFE1E6; background:#FAFBFC; }' +
      '.jsa-fsi-pagination { display:flex; align-items:center; justify-content:center; gap:6px; padding:12px 20px; flex-wrap:wrap; }' +
      '.jsa-fsi-page-info { font-size:12px; color:#6B778C; margin-right:4px; }' +
      '.jsa-fsi-page-num { font-family:inherit; font-size:13px; color:#0052CC; background:#fff; border:1px solid #DFE1E6; border-radius:4px; padding:4px 10px; cursor:pointer; transition:all .15s; line-height:1; }' +
      '.jsa-fsi-page-num:hover:not(:disabled) { background:#DEEBFF; border-color:#B2D4FF; }' +
      '.jsa-fsi-page-num.active { background:#0052CC; color:#fff; border-color:#0052CC; cursor:default; }' +
      '.jsa-fsi-page-num:disabled { opacity:0.5; cursor:not-allowed; }' +
      '.jsa-fsi-page-prev, .jsa-fsi-page-next { white-space:nowrap; }' +
      '.jsa-fsi-page-ellipsis { color:#6B778C; padding:0 2px; }' +
      '.jsa-fsi-detail { display:none; background:#FAFBFC; border-bottom:2px solid #DFE1E6; }' +
      '.jsa-fsi-detail.open { display:table-row; }' +
      '.jsa-fsi-detail-cell { padding:16px 20px 20px; }' +
      '.jsa-fsi-detail-grid { font-size:13px; }' +
      // 根因/方案/Gerrit 紧凑键值对行（完整显示，标签左列固定宽 + 值右列换行）
      '.jsa-fsi-info-cards { display:flex; flex-direction:column; gap:6px; margin-bottom:14px; padding:8px 10px; background:#fff; border:1px solid #DFE1E6; border-radius:4px; }' +
      '.jsa-fsi-info-card { display:flex; align-items:baseline; gap:8px; line-height:1.6; }' +
      '.jsa-fsi-info-card-label { flex-shrink:0; width:64px; font-size:11px; font-weight:600; color:#6B778C; }' +
      '.jsa-fsi-info-card-value { flex:1; min-width:0; color:#172B4D; word-break:break-word; white-space:pre-wrap; line-height:1.6; }' +
      '.jsa-fsi-info-card-empty { color:#97A0AF; font-style:italic; }' +
      // 评论区标题
      '.jsa-fsi-detail-label { color:#172B4D; font-weight:600; margin:0 0 10px; font-size:13px; display:flex; align-items:center; gap:6px; }' +
      '.jsa-fsi-detail-label .count { color:#6B778C; font-weight:400; font-size:12px; }' +
      // 时间轴评论流
      '.jsa-fsi-comments { position:relative; padding-left:22px; }' +
      '.jsa-fsi-comments::before { content:""; position:absolute; left:9px; top:4px; bottom:4px; width:2px; background:#DFE1E6; }' +
      '.jsa-fsi-comment { position:relative; padding:0 0 14px 12px; }' +
      '.jsa-fsi-comment::before { content:""; position:absolute; left:-18px; top:5px; width:10px; height:10px; border-radius:50%; background:#0052CC; border:2px solid #FAFBFC; box-sizing:border-box; }' +
      '.jsa-fsi-comment-head { display:flex; align-items:center; gap:8px; margin-bottom:4px; }' +
      '.jsa-fsi-comment-avatar { flex-shrink:0; width:24px; height:24px; border-radius:50%; color:#fff; font-size:12px; font-weight:600; display:inline-flex; align-items:center; justify-content:center; }' +
      '.jsa-fsi-comment-author { font-weight:600; color:#172B4D; font-size:13px; }' +
      '.jsa-fsi-comment-time { color:#6B778C; font-size:11px; white-space:nowrap; }' +
      '.jsa-fsi-comment-body { color:#172B4D; word-break:break-word; line-height:1.7; white-space:pre-wrap; max-height:320px; overflow-y:auto; padding:8px 10px; background:#fff; border:1px solid #EBECF0; border-radius:4px; }' +
      '.jsa-fsi-comment-empty { color:#97A0AF; font-style:italic; padding:8px 0; }' +
      '.jsa-fsi-comments-toggle { text-align:center; padding:6px; border:1px dashed #C1C7D0; border-radius:4px; cursor:pointer; color:#0052CC; font-size:12px; margin-left:-22px; background:#fff; transition:all .15s; }' +
      '.jsa-fsi-comments-toggle:hover { background:#DEEBFF; border-color:#B2D4FF; }' +
      '.jsa-fsi-detail-loading { color:#6B778C; font-style:italic; padding:12px; }' +
      '.jsa-fsi-progress { position:fixed; bottom:24px; right:24px; background:#fff; border-radius:8px; box-shadow:0 8px 24px rgba(0,0,0,.15); padding:20px 24px; z-index:999998; width:340px; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; animation:jsaFsiFadeIn .2s ease; }' +
      '.jsa-fsi-progress-text { font-size:14px; color:#172B4D; margin-bottom:10px; }' +
      '.jsa-fsi-progress-bar { width:100%; height:6px; background:#DFE1E6; border-radius:3px; overflow:hidden; margin-bottom:12px; position:relative; }' +
      '.jsa-fsi-progress-fill { position:absolute; top:0; left:0; height:100%; width:30%; background:#0052CC; border-radius:3px; animation:jsaFsiProgressSlide 1.4s ease-in-out infinite; }' +
      '@keyframes jsaFsiProgressSlide { 0% { left:-30%; width:30%; } 50% { left:50%; width:45%; } 100% { left:100%; width:30%; } }';
    document.head.appendChild(style);
  }
  function createFindSimilarButton() {
    var btn = document.createElement('button');
    btn.id = 'jsa-find-similar-btn';
    btn.type = 'button';
    btn.innerHTML =
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      '<circle cx="11" cy="11" r="8"></circle>' +
      '<line x1="21" y1="21" x2="16.65" y2="16.65"></line>' +
      '</svg>' +
      '<span>查找同单</span>';
    btn.addEventListener('click', handleFindSimilarClick);
    return btn;
  }
  function injectButton() {
    if (!isIssueDetailPage()) return;
    var opsbar = document.querySelector('#opsbar-opsbar-transitions');
    if (!opsbar) return;
    if (document.querySelector('#jsa-find-similar-btn')) return;
    injectStyles();
    var btn = createFindSimilarButton();
    if (opsbar.nextSibling) {
      opsbar.parentNode.insertBefore(btn, opsbar.nextSibling);
    } else {
      opsbar.parentNode.appendChild(btn);
    }
    console.log('[JSA] 查找同单按钮已注入');
    // 注意：不再自动后台预热缓存，搜索仅在用户点击"查找同单"按钮时触发，
    // 避免用户浏览工单时对未缓存单子无谓消耗 LLM token。
  }

  // ---- 4. 进度卡片 UI ----
  var _progressEl = null;
  function showProgressCard() {
    closeProgressCard();
    _progressEl = document.createElement('div');
    _progressEl.className = 'jsa-fsi-progress';
    _progressEl.innerHTML =
      '<div class="jsa-fsi-progress-text" id="jsaFsiProgressText">正在搜索相似工单...</div>' +
      '<div class="jsa-fsi-progress-bar"><div class="jsa-fsi-progress-fill" id="jsaFsiProgressFill"></div></div>' +
      '<div style="font-size:12px;color:#6B778C;margin-bottom:8px">正在检索相似工单，请稍候…</div>';
    document.body.appendChild(_progressEl);
  }
  function updateProgressCard(text) {
    if (!_progressEl) return;
    _progressEl.querySelector('#jsaFsiProgressText').textContent = text;
  }
  function closeProgressCard() {
    if (_progressEl) {
      _progressEl.remove();
      _progressEl = null;
    }
  }

  // ---- 5. 结果弹窗 UI ----
  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function formatComments(commentsJson) {
    // 头像首字母取色（按名字 hash 选色，稳定且多彩）
    var AVATAR_COLORS = ['#0052CC', '#36B37E', '#FF8B00', '#6554C0', '#00B8D9', '#FF5630', '#006644', '#7A869A'];
    function avatarHtml(name) {
      var ch = (name || '?').trim().charAt(0).toUpperCase() || '?';
      var h = 0;
      for (var i = 0; i < (name || '').length; i++) h = (h * 31 + (name || '').charCodeAt(i)) | 0;
      var color = AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
      return '<span class="jsa-fsi-comment-avatar" style="background:' + color + '">' + escapeHtml(ch) + '</span>';
    }
    function fmtTime(created) {
      // 2024-01-15T09:30:00.000+0800 → 2024-01-15 09:30
      var s = (created || '').replace('T', ' ').replace(/\.\d+.*/, '');
      return s.length > 16 ? s.substring(0, 16) : s;
    }

    if (!commentsJson) return '<div class="jsa-fsi-comment-empty">无评论</div>';
    try {
      var comments = typeof commentsJson === 'string' ? JSON.parse(commentsJson) : commentsJson;
      if (!Array.isArray(comments) || comments.length === 0) return '<div class="jsa-fsi-comment-empty">无评论</div>';

      function renderComment(c) {
        var author = c.author || '匿名';
        var body = (c.body || '').trim();
        var bodyHtml = escapeHtml(body);
        return '<div class="jsa-fsi-comment">' +
          '<div class="jsa-fsi-comment-head">' +
            avatarHtml(author) +
            '<span class="jsa-fsi-comment-author">' + escapeHtml(author) + '</span>' +
            '<span class="jsa-fsi-comment-time">' + escapeHtml(fmtTime(c.created)) + '</span>' +
          '</div>' +
          '<div class="jsa-fsi-comment-body">' + (bodyHtml || '<span class="jsa-fsi-comment-empty">（空）</span>') + '</div>' +
          '</div>';
      }

      var PREVIEW_COUNT = 3;
      var html = '';

      if (comments.length <= PREVIEW_COUNT) {
        for (var i = 0; i < comments.length; i++) {
          html += renderComment(comments[i]);
        }
      } else {
        // 前 3 条默认展示，其余折叠
        for (var i = 0; i < PREVIEW_COUNT; i++) {
          html += renderComment(comments[i]);
        }
        html += '<div class="jsa-fsi-comments-rest" style="display:none">';
        for (var i = PREVIEW_COUNT; i < comments.length; i++) {
          html += renderComment(comments[i]);
        }
        html += '</div>';
        html += '<div class="jsa-fsi-comments-toggle" ' +
          'onclick="var r=this.previousElementSibling;if(r.style.display===\'none\'){r.style.display=\'block\';this.textContent=\'▲ 收起\';}else{r.style.display=\'none\';this.textContent=\'▼ 展开剩余 ' + (comments.length - PREVIEW_COUNT) + ' 条评论\';}">' +
          '▼ 展开剩余 ' + (comments.length - PREVIEW_COUNT) + ' 条评论</div>';
      }

      return html;
    } catch (e) {
      return '<div class="jsa-fsi-comment-body">' + escapeHtml(String(commentsJson).substring(0, 500)) + '</div>';
    }
  }

  function getStatusClass(status) {
    if (!status) return 'jsa-fsi-status-other';
    var s = status.toLowerCase();
    if (s.indexOf('closed') >= 0 || s.indexOf('关闭') >= 0) return 'jsa-fsi-status-closed';
    if (s.indexOf('resolved') >= 0 || s.indexOf('解决') >= 0) return 'jsa-fsi-status-resolved';
    if (s.indexOf('open') >= 0 || s.indexOf('打开') >= 0) return 'jsa-fsi-status-open';
    return 'jsa-fsi-status-other';
  }

  // 当前弹窗的上下文（用于更新按钮刷新）
  var _currentModalContext = null;

  function showResultModal(data, currentIssueKey, projectKey) {
    var existing = document.querySelector('.jsa-fsi-overlay');
    if (existing) existing.remove();
    var overlay = document.createElement('div');
    overlay.className = 'jsa-fsi-overlay';

    var similar = (data && data.similar) || [];
    // 过滤掉当前单子
    similar = similar.filter(function (item) { return item.key !== currentIssueKey; });
    // 直接使用后端返回顺序（后端 result.similar 已按 similarity 降序排好，
    // 与 8080 网页前端一致，前端不再二次排序以免破坏同分项的稳定顺序）
    // 全部结果分页展示，每页 MAX_DISPLAY 条，不再截断
    var displayItems = similar;
    var error = data && data.error;
    var baseUrl = _getJiraBaseUrl();
    var cachedAt = data && data.cached_at;

    var rowsHtml = '';
    if (error) {
      rowsHtml = '<div class="jsa-fsi-empty" style="color:#DE350B">' +
        '⚠️ 搜索服务暂时不可用<br><br>' +
        '<span style="font-size:13px">' + escapeHtml(error) + '</span>' +
        '<div style="margin-top:12px">' +
        '<a href="' + BUG_SEARCH_HOME + '" target="_blank" rel="noopener noreferrer" ' +
        'style="display:inline-block;padding:6px 14px;background:#0052CC;color:#fff;' +
        'border-radius:3px;text-decoration:none;font-size:13px">🔗 前往 Bug 搜索系统手动搜索</a>' +
        '<div style="margin-top:6px;font-size:12px;color:#6B778C">语义搜索服务暂不可用，可在 Bug 搜索系统中使用关键词搜索</div>' +
        '</div>' +
        '</div>';
    } else if (displayItems.length === 0) {
      rowsHtml = '<div class="jsa-fsi-empty">✅ 未发现相似工单</div>';
    }

    var statsHtml = '';
    if (!error) {
      statsHtml =
        '<div class="jsa-fsi-stat">找到 <strong>' + similar.length + '</strong> 条相似工单' + '</div>' +
        (cachedAt ? '<div class="jsa-fsi-stat">📦 读取自缓存</div>' : (data && data.search_time_ms ? '<div class="jsa-fsi-stat">耗时 <strong>' + data.search_time_ms + 'ms</strong></div>' : ''));
    }

    // 缓存信息栏
    var cacheInfoHtml = '';
    if (!error) {
      var cacheTimeText = cachedAt ? ('📅 缓存于 ' + cachedAt) : '📅 实时搜索结果';
      cacheInfoHtml = '<div class="jsa-fsi-cache-info">' +
        '<span>' + cacheTimeText + '</span>' +
        '<span style="margin-left:8px;color:#6B778C">缓存保留15天，点击🔄可实时搜索并更新缓存</span>' +
        '</div>';
    }

    // error / 空结果直接展示提示；有数据时 body 留空，由 renderPage() 分页填充
    var bodyInitialHtml = (error || displayItems.length === 0) ? rowsHtml : '';

    overlay.innerHTML =
      '<div class="jsa-fsi-modal">' +
      '<div class="jsa-fsi-header">' +
      '<div class="jsa-fsi-title">🔍 查找同单结果</div>' +
      '<button class="jsa-fsi-refresh" id="jsaFsiRefreshBtn" title="实时搜索并更新缓存">🔄 更新</button>' +
      '<a class="jsa-fsi-bugsearch" href="' + BUG_SEARCH_HOME + '" target="_blank" rel="noopener noreferrer" title="前往 JIRA Bug 搜索系统手动搜索">🔗 Bug 搜索</a>' +
      '<button class="jsa-fsi-close" id="jsaFsiCloseBtn">&times;</button>' +
      '</div>' +
      cacheInfoHtml +
      '<div class="jsa-fsi-stats">' + statsHtml + '</div>' +
      '<div class="jsa-fsi-body" id="jsaFsiBody">' + bodyInitialHtml + '</div>' +
      '<div class="jsa-fsi-footer" id="jsaFsiFooter"></div>';
    document.body.appendChild(overlay);

    // 保存当前弹窗上下文（供更新按钮使用）
    _currentModalContext = { overlay: overlay, currentIssueKey: currentIssueKey, projectKey: projectKey };

    var closeModal = function () { overlay.remove(); _currentModalContext = null; };
    overlay.querySelector('#jsaFsiCloseBtn').addEventListener('click', closeModal);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) closeModal(); });

    // 分页渲染（每页 MAX_DISPLAY 条，展示全部数据）+ 行点击展开详情
    var detailCache = {};
    var currentPage = 1;

    function buildPagination(page, totalPages, total) {
      if (totalPages <= 1) return '';
      var html = '<div class="jsa-fsi-pagination"><span class="jsa-fsi-page-info">共 ' + total + ' 条 · 第 ' + page + '/' + totalPages + ' 页</span>';
      var addBtn = function (p, label, disabled, extraCls) {
        html += '<button class="jsa-fsi-page-num' + (extraCls || '') + '" data-page="' + p + '"' + (disabled ? ' disabled' : '') + '>' + label + '</button>';
      };
      addBtn('prev', '‹ 上一页', page <= 1, ' jsa-fsi-page-prev');
      var pages = [];
      if (totalPages <= 9) {
        for (var p = 1; p <= totalPages; p++) pages.push(p);
      } else {
        pages.push(1);
        if (page > 4) pages.push('...');
        var from = Math.max(2, page - 1), to = Math.min(totalPages - 1, page + 1);
        for (var p2 = from; p2 <= to; p2++) pages.push(p2);
        if (page < totalPages - 3) pages.push('...');
        pages.push(totalPages);
      }
      pages.forEach(function (pg) {
        if (pg === '...') html += '<span class="jsa-fsi-page-ellipsis">…</span>';
        else addBtn(pg, String(pg), pg === page, ' active');
      });
      addBtn('next', '下一页 ›', page >= totalPages, ' jsa-fsi-page-next');
      html += '</div>';
      return html;
    }

    var bodyEl = overlay.querySelector('#jsaFsiBody');
    var footerEl = overlay.querySelector('#jsaFsiFooter');

    function renderPage(page) {
      var totalPages = Math.ceil(displayItems.length / MAX_DISPLAY) || 1;
      if (page < 1) page = 1;
      if (page > totalPages) page = totalPages;
      currentPage = page;
      var start = (page - 1) * MAX_DISPLAY;
      var end = Math.min(start + MAX_DISPLAY, displayItems.length);
      var rowsHtml = '';
      for (var i = start; i < end; i++) {
        var item = displayItems[i];
        var statusCls = getStatusClass(item.status);
        var resolutionHtml = item.resolution ? ' / ' + escapeHtml(item.resolution) : '';
        rowsHtml +=
          '<tr class="jsa-fsi-row" data-detail-idx="' + i + '">' +
          '<td class="jsa-fsi-key" style="width:120px"><a href="' + baseUrl + '/browse/' + escapeHtml(item.key) + '" target="_blank" rel="noopener noreferrer" onclick="event.stopPropagation()">' + escapeHtml(item.key) + '</a></td>' +
          '<td class="jsa-fsi-summary" title="' + escapeHtml(item.summary) + '">' + escapeHtml(item.summary) + '</td>' +
          '<td style="width:120px"><span class="jsa-fsi-status ' + statusCls + '">' + escapeHtml(item.status || '未知') + resolutionHtml + '</span></td>' +
          '</tr>';
        rowsHtml +=
          '<tr class="jsa-fsi-detail" id="jsaFsiDetail' + i + '">' +
          '<td colspan="3" class="jsa-fsi-detail-cell">' +
            '<div class="jsa-fsi-detail-loading">点击加载详情...</div>' +
          '</td>' +
          '</tr>';
      }
      var paginationHtml = buildPagination(page, totalPages, displayItems.length);
      bodyEl.innerHTML = '<table class="jsa-fsi-table"><thead><tr>' +
        '<th>Issue Key</th>' +
        '<th>概要</th>' +
        '<th>状态</th>' +
        '</tr></thead><tbody>' + rowsHtml + '</tbody></table>';
      footerEl.innerHTML = paginationHtml;

      // 行点击展开/折叠详情
      bodyEl.querySelectorAll('.jsa-fsi-row').forEach(function (row) {
        row.addEventListener('click', function () {
          var idx = row.getAttribute('data-detail-idx');
          var detailRow = bodyEl.querySelector('#jsaFsiDetail' + idx);
          if (!detailRow) return;
          var isOpen = detailRow.classList.contains('open');
          if (isOpen) {
            detailRow.classList.remove('open');
            return;
          }
          detailRow.classList.add('open');
          var item = displayItems[idx];
          // 如果已有 comments 等数据，直接渲染
          if (item.comments || item.root_cause || item.solution || item.gerrit_id) {
            renderDetail(detailRow, item);
          } else {
            // 异步获取详情
            var loadingEl = detailRow.querySelector('.jsa-fsi-detail-loading');
            if (loadingEl) loadingEl.textContent = '正在加载详情...';
            if (detailCache[idx]) {
              renderDetail(detailRow, detailCache[idx]);
            } else {
              chrome.runtime.sendMessage(
                { type: 'JSA_ISSUE_DETAIL', key: item.key },
                function (resp) {
                  if (resp && resp.ok && resp.data) {
                    detailCache[idx] = resp.data;
                    renderDetail(detailRow, resp.data);
                  } else {
                    var el = detailRow.querySelector('.jsa-fsi-detail-loading');
                    if (el) {
                      el.textContent = '详情获取失败' + (resp && resp.error ? ': ' + String(resp.error).substring(0, 100) : '');
                      el.style.color = '#DE350B';
                    }
                  }
                }
              );
            }
          }
        });
      });

      // 分页按钮
      footerEl.querySelectorAll('.jsa-fsi-page-num').forEach(function (btn) {
        btn.addEventListener('click', function () {
          if (btn.disabled) return;
          var p = btn.getAttribute('data-page');
          if (p === 'prev') renderPage(currentPage - 1);
          else if (p === 'next') renderPage(currentPage + 1);
          else renderPage(parseInt(p, 10));
          bodyEl.scrollTop = 0;
        });
      });
    }

    function renderDetail(detailRow, d) {
      // 信息行：根因/方案/Gerrit 完整显示，标签左列固定宽 + 值右列自适应换行，紧凑省空间
      var infoCards = '';
      function infoCard(label, value) {
        if (!value) return '';
        return '<div class="jsa-fsi-info-card">' +
          '<div class="jsa-fsi-info-card-label">' + label + '</div>' +
          '<div class="jsa-fsi-info-card-value">' + escapeHtml(value) + '</div>' +
          '</div>';
      }
      var infoRows = infoCard('根因', d.root_cause) +
        infoCard('方案', d.solution) +
        infoCard('Gerrit', d.gerrit_id);
      // 三字段全空时不渲染容器，避免出现空行
      infoCards = infoRows ? '<div class="jsa-fsi-info-cards">' + infoRows + '</div>' : '';

      // 评论区：时间轴流
      var commentCount = 0;
      try {
        var cs = d.comments;
        if (typeof cs === 'string') cs = JSON.parse(cs);
        if (Array.isArray(cs)) commentCount = cs.length;
      } catch (e) {}

      var html = '<div class="jsa-fsi-detail-grid">' +
        infoCards +
        '<div class="jsa-fsi-detail-label">💬 评论 <span class="count">(' + commentCount + ')</span></div>' +
        '<div class="jsa-fsi-comments">' + formatComments(d.comments) + '</div>' +
        '</div>';
      detailRow.querySelector('.jsa-fsi-detail-cell').innerHTML = html;
    }

    // 有数据时渲染首页
    if (!error && displayItems.length > 0) {
      renderPage(1);
    }

    // 更新按钮事件
    var refreshBtn = overlay.querySelector('#jsaFsiRefreshBtn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function () {
        handleRefreshClick(refreshBtn, overlay, currentIssueKey, projectKey);
      });
    }
  }

  // ---- 6. 更新按钮逻辑 ----
  function handleRefreshClick(refreshBtn, overlay, currentIssueKey, projectKey) {
    if (refreshBtn.disabled) return;
    refreshBtn.disabled = true;
    refreshBtn.textContent = '🔄 更新中...';
    // 先关闭当前弹窗，避免进度卡被遮挡
    overlay.remove();
    _currentModalContext = null;
    showProgressCard();
    updateProgressCard('正在实时搜索并更新缓存...');

    chrome.runtime.sendMessage(
      { type: 'JSA_SIMILAR_SEARCH', key: currentIssueKey, force_refresh: true },
      function (resp) {
        closeProgressCard();

        if (!resp || !resp.ok) {
          // 搜索失败，重新显示旧弹窗并恢复按钮
          var data = (resp && resp.data) ? resp.data : { error: '搜索失败，请稍后重试' };
          showResultModal(data, currentIssueKey, projectKey);
          return;
        }
        // 成功 — 重新渲染弹窗
        var data = resp.data || {};
        showResultModal(data, currentIssueKey, projectKey);
        // 统计上报
        if (!data.error) {
          try {
            if (typeof UsageReporter !== 'undefined' && UsageReporter.report) {
              UsageReporter.report('find_similar', {
                project: projectKey,
                scanned: ((data.similar) || []).length,
                matches: ((data.similar) || []).length
              });
            }
          } catch (e) { /* 上报失败不影响主流程 */ }
        }
      }
    );
  }

  // ---- 7. 主流程编排 ----
  function handleFindSimilarClick() {
    if (typeof jsaRequireAuth === 'function' && !jsaRequireAuth()) {
      return;
    }
    var info = getCurrentIssueInfo();
    if (!info) {
      alert('无法获取当前工单信息，请确认在问题详情页操作');
      return;
    }
    showProgressCard();
    updateProgressCard('正在搜索相似工单...');

    chrome.runtime.sendMessage(
      { type: 'JSA_SIMILAR_SEARCH', key: info.issueKey },
      function (resp) {
        closeProgressCard();
        if (!resp) {
          showResultModal({ error: '未收到响应，扩展通信异常' }, info.issueKey, info.projectKey);
          return;
        }
        if (!resp.ok) {
          var errMsg = '搜索服务请求失败';
          if (resp.error) {
            errMsg += '：' + (typeof resp.error === 'string' ? resp.error.substring(0, 200) : '未知错误');
          } else if (resp.status) {
            errMsg += '（HTTP ' + resp.status + '）';
          }
          showResultModal({ error: errMsg }, info.issueKey, info.projectKey);
          return;
        }
        // 成功 — 渲染结果
        var data = resp.data || {};
        showResultModal(data, info.issueKey, info.projectKey);
        // 统计上报
        if (!data.error) {
          try {
            if (typeof UsageReporter !== 'undefined' && UsageReporter.report) {
              UsageReporter.report('find_similar', {
                project: info.projectKey,
                scanned: ((data.similar) || []).length,
                matches: ((data.similar) || []).length
              });
            }
          } catch (e) { /* 上报失败不影响主流程 */ }
        }
      }
    );
  }

  // ---- 启动 ----
  var fsiObserver = new MutationObserver(function () { injectButton(); });
  try {
    fsiObserver.observe(document.body, { childList: true, subtree: true });
  } catch (e) { /* ignore */ }
  setTimeout(injectButton, 1000);
  setTimeout(injectButton, 3000);
  console.log('[JSA] 查找同单模块已加载（JIRASearch API 集成版，按钮触发搜索）');
})();
// ---- 自动搜单工具：在内部搜单页面自动填入关键词并搜索 ----
  // 仅在 10.24.137.80:8080 上生效
  if (location.hostname === '10.24.137.80' && location.port === '8080') {
    (function autoSearchInit() {
      // 等待页面加载后检查是否有待搜索的关键词
      function tryAutoSearch(attempt) {
        attempt = attempt || 0;
        if (attempt > 30) return; // 最多尝试 30 次（约 15 秒）
        try {
          chrome.storage.local.get('jsa_ext_search_key', function (data) {
            var key = data && data.jsa_ext_search_key;
            if (!key) return;
            // 用完即删，避免重复触发
            chrome.storage.local.remove('jsa_ext_search_key');
            // 查找输入框
            var input = document.querySelector('.el-input__inner') ||
                        document.querySelector('input[placeholder*="搜索"]');
            if (!input) { setTimeout(function () { tryAutoSearch(attempt + 1); }, 500); return; }
            // 填入搜索词（模拟 Vue/Element UI 输入）
            var nativeInputValueSetter = Object.getOwnPropertyDescriptor(
              window.HTMLInputElement.prototype, 'value'
            ).set;
            nativeInputValueSetter.call(input, key);
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
            // 查找搜索按钮并点击
            setTimeout(function () {
              var searchBtn = document.querySelector('.el-input-group__append button') ||
                              document.querySelector('.el-button--primary');
              if (searchBtn) searchBtn.click();
            }, 300);
          });
        } catch (e) {
          setTimeout(function () { tryAutoSearch(attempt + 1); }, 500);
        }
      }
      // 页面加载后延迟启动
      setTimeout(function () { tryAutoSearch(0); }, 1000);
    })();
  }
// ===================== 查找同单（Find Similar Issues）END =====================
